"use strict";

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 *  Merged: ai.js + aihotro.js
 *  Lệnh th!ai — Chat AI, xử lý ảnh/video/file, tạo file, hẹn giờ
 *  Tác giả: Zay <@1187321862724800562>
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * ── TÍNH NĂNG ──────────────────────────────────────────────────────
 *
 *  [GIỮ NGUYÊN]
 *  • Chat AI (Gemini 2.5 Flash) — prefix th!ai / ask / chat / hoi / alo
 *  • Xem & phân tích ảnh qua Gemini Vision
 *  • Xem video (frame/gif → Gemini Vision, mp4 → mô tả)
 *  • Gửi DM / IB cho user theo yêu cầu
 *  • Tag / nhắc hẹn giờ (remind, tag @user sau X phút/giờ/ngày)
 *  • Lưu & liệt kê file tải về (src/Zay/Download/<guildId>/)
 *  • Chuyển đổi định dạng file (txt↔json, ảnh resize/convert, v.v.)
 *  • Gửi file cho người khác qua DM hoặc kênh
 *  • Chatbot AI tự động theo kênh (setchannel / removechannel)
 *  • Lịch sử chat AI theo kênh + guild (clearchat / clearall)
 *  • Message logger (log / info / stats)
 *
 *  [CẬP NHẬT / SỬA]
 *  • Xóa :v / :)) khỏi toàn bộ reply — tự nhiên hơn
 *  • SectionBuilder trong help menu: fix lỗi truyền 2 TextDisplay vào
 *    1 addTextDisplayComponents() → crash Components V2
 *  • Header help menu: gộp title + subtitle thành 1 TextDisplay duy nhất
 *  • Auto-clear download dir khi đạt 100 file/guild (tránh đầy disk)
 *  • th!ai log: fallback sang AI chat history khi msg logger chưa có data
 *  • th!ai clearchat: yêu cầu quyền Administrator thay vì ManageMessages
 *
 *  [THÊM MỚI]
 *  • th!ai makefile-AI <tên.ext> <yêu cầu>
 *    — AI tạo nội dung file theo yêu cầu, có comment giải thích
 *      đúng ký hiệu theo loại file (# / // / -- / html-comment / css-comment)
 *    — Đầu file có comment tóm tắt mục đích + cách chạy
 *    — Tự strip markdown fence nếu AI vẫn trả về
 */

require("dotenv").config();

// ===== IMPORTS =====
const { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } = require("@google/generative-ai");
const {
    EmbedBuilder, AttachmentBuilder,
    ContainerBuilder, TextDisplayBuilder, SeparatorBuilder,
    SectionBuilder, ThumbnailBuilder,
    ButtonBuilder, ActionRowBuilder,
    SeparatorSpacingSize, ButtonStyle, MessageFlags,
} = require("discord.js");
const { getAllKeys }   = require("../../Zay/doikey.js");
const axios  = require("axios");
const fetch  = require("node-fetch");
const fs     = require("fs");
const path   = require("path");
const sharp  = require("sharp").default || require("sharp"); // npm i sharp


// ═══════════════════════════════════════════════════════════════════
//  CONSTANTS & CONFIG
// ═══════════════════════════════════════════════════════════════════

const OWNER_ID = process.env.ADMIN_DISCORD_ID || "1187321862724800562";

// ── Paths — AI thường ────────────────────────────────────────────
const PERSONALITY_PATH = path.join(__dirname, "../../Zay/tinhcach.txt");
const HISTORY_DIR      = path.join(__dirname, "../../Zay/AI-Chat/Lich-su-AI");
const MSG_LOG_DIR      = path.join(__dirname, "../../Zay/AI-Chat/Message-Log");

// ── Paths — AI xác minh ──────────────────────────────────────────

// ── Path — Download/lưu file ─────────────────────────────────────
const DOWNLOAD_BASE_DIR  = path.join(__dirname, "../../Zay/Download");
const MAX_DOWNLOAD_FILES = 100; // Tối đa file lưu mỗi guild — tự xóa sạch khi đạt giới hạn

// ── Giới hạn AI history ──────────────────────────────────────────
const MAX_LOG_ENTRIES  = 10_000;
const MAX_GEMINI_TURNS = 80;

// ── Giới hạn Message Logger ──────────────────────────────────────
const MSG_MAX_PER_CHANNEL = 50_000;
const MSG_MAX_PER_GUILD   = 500_000;
const MSG_SAVE_DEBOUNCE   = 3_000;

// ── Embed config ─────────────────────────────────────────────────
const EMBED_COLOR     = 0x808080;
const EMBED_IMAGE_URL = "https://cdn.discordapp.com/attachments/1490373725093367968/1497611216732946553/file_000000003b4871faae360e351cfc183d.png?ex=69ee26a2&is=69ecd522&hm=dc6680aad58bbfeae65175a62e290c117b6628274fee0e8b2e4f0b69ab658732&";


const NSFW_KW = ["sex", "18+", "xxx", "nsfw", "hentai", "lồn", "địt", "nude", "cặc", "bướm"];

const safetySettings = [
    { category: HarmCategory.HARM_CATEGORY_HARASSMENT,        threshold: HarmBlockThreshold.BLOCK_NONE },
    { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,       threshold: HarmBlockThreshold.BLOCK_NONE },
    { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_NONE },
    { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_NONE },
];

// ── Scheduled tag store ──────────────────────────────────────────
// Map<timerId, { timeout, userId, channelId, guildId, message }>
const scheduledTags = new Map();
let _tagIdCounter   = 0;


// ═══════════════════════════════════════════════════════════════════
//  SHARED UTILITIES
// ═══════════════════════════════════════════════════════════════════

function ensureDir(dir) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function splitMessage(text, maxLen = 1900) {
    const parts = [];
    while (text.length > maxLen) {
        let chunk = text.slice(0, maxLen);
        const cut = Math.max(chunk.lastIndexOf("\n"), chunk.lastIndexOf(" "));
        if (cut > maxLen * 0.5) chunk = text.slice(0, cut);
        parts.push(chunk);
        text = text.slice(chunk.length).trimStart();
    }
    if (text.trim()) parts.push(text);
    return parts;
}

async function urlToBase64(url) {
    const res = await fetch(url);
    const buf = await res.buffer();
    return buf.toString("base64");
}

async function urlToBuffer(url) {
    const res = await fetch(url);
    return res.buffer();
}

function todayVN() {
    const now = new Date(Date.now() + 7 * 3600 * 1000);
    return now.toISOString().slice(0, 10);
}

function isNsfw(text) {
    const t = text.toLowerCase();
    return NSFW_KW.some(k => t.includes(k));
}

function makeEmbed(guild, imageUrl = EMBED_IMAGE_URL) {
    const embed = new EmbedBuilder().setColor(EMBED_COLOR);
    const icon  = guild?.icon
        ? guild.iconURL({ dynamic: true, size: 128 })
        : guild?.iconURL?.({ dynamic: true }) || null;
    if (icon)     embed.setThumbnail(icon);
    if (imageUrl) embed.setImage(imageUrl);
    return embed;
}

async function waitForImage(imageUrl, interval = 4000, maxTries = 15) {
    for (let i = 1; i <= maxTries; i++) {
        try {
            const res = await axios.get(imageUrl, { timeout: 10000, validateStatus: s => s === 200 });
            if (res.status === 200) return imageUrl;
        } catch { /* retry */ }
        if (i < maxTries) await new Promise(r => setTimeout(r, interval));
    }
    return null;
}

/**
 * Phân tích ms delay từ chuỗi kiểu "5 phút", "2 giờ", "1 ngày", "30 giây"
 * Trả về { ms, label } hoặc null nếu không parse được.
 */
function parseDelay(str) {
    if (!str) return null;
    str = str.toLowerCase().trim();
    const map = [
        { re: /(\d+)\s*(s|giây|giay|second)/,  mult: 1_000,          unit: "giây" },
        { re: /(\d+)\s*(m|phút|phut|minute)/,   mult: 60_000,         unit: "phút" },
        { re: /(\d+)\s*(h|giờ|gio|hour)/,        mult: 3_600_000,      unit: "giờ" },
        { re: /(\d+)\s*(d|ngày|ngay|day)/,        mult: 86_400_000,     unit: "ngày" },
    ];
    for (const { re, mult, unit } of map) {
        const m = str.match(re);
        if (m) {
            const n = parseInt(m[1]);
            return { ms: n * mult, label: `${n} ${unit}` };
        }
    }
    return null;
}

/**
 * Lấy thư mục download của guild, tạo nếu chưa có.
 */
function guildDownloadDir(guildId) {
    const dir = path.join(DOWNLOAD_BASE_DIR, guildId);
    ensureDir(dir);
    return dir;
}

/**
 * Tải file từ URL về thư mục Download của guild.
 * Trả về đường dẫn file đã lưu.
 */
async function downloadFile(url, filename, guildId) {
    const dir   = guildDownloadDir(guildId);

    // ── Giới hạn 100 file / guild — xóa sạch khi đầy ───────────
    const existing = fs.readdirSync(dir);
    if (existing.length >= MAX_DOWNLOAD_FILES) {
        for (const f of existing) {
            try { fs.unlinkSync(path.join(dir, f)); } catch (_) {}
        }
        console.log(`[AI] Download dir của guild ${guildId} đầy (${existing.length} file) — đã xóa sạch.`);
    }

    const filePath = path.join(dir, filename);
    const res      = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status} khi tải file`);
    const buf = await res.buffer();
    fs.writeFileSync(filePath, buf);
    return filePath;
}

/**
 * Chuyển đổi định dạng ảnh bằng sharp.
 * Các format hỗ trợ: jpeg, png, webp, gif, avif
 */
async function convertImage(inputPath, outputFormat) {
    const validFormats = ["jpeg", "jpg", "png", "webp", "gif", "avif"];
    const fmt = outputFormat.toLowerCase().replace("jpg", "jpeg");
    if (!validFormats.includes(fmt)) throw new Error(`Format không hỗ trợ: ${outputFormat}`);
    const ext        = fmt === "jpeg" ? "jpg" : fmt;
    const outputPath = inputPath.replace(/\.[^.]+$/, `.${ext}`);
    await sharp(inputPath).toFormat(fmt).toFile(outputPath);
    return outputPath;
}

/**
 * Chuyển đổi file text ↔ json, hoặc các thao tác text đơn giản.
 */
function convertTextFile(inputPath, outputFormat) {
    const content = fs.readFileSync(inputPath, "utf8");
    const ext     = outputFormat.toLowerCase();
    let outputPath, outputContent;

    if (ext === "json") {
        // txt → json: mỗi dòng là 1 phần tử mảng
        const lines = content.split("\n").filter(l => l.trim());
        outputContent = JSON.stringify(lines, null, 2);
        outputPath    = inputPath.replace(/\.[^.]+$/, ".json");
    } else if (ext === "txt") {
        // json → txt: mỗi phần tử/value thành 1 dòng
        try {
            const parsed = JSON.parse(content);
            outputContent = Array.isArray(parsed)
                ? parsed.join("\n")
                : Object.entries(parsed).map(([k, v]) => `${k}: ${v}`).join("\n");
        } catch {
            outputContent = content;
        }
        outputPath = inputPath.replace(/\.[^.]+$/, ".txt");
    } else {
        throw new Error(`Chuyển đổi text → ${outputFormat} chưa được hỗ trợ`);
    }

    fs.writeFileSync(outputPath, outputContent, "utf8");
    return outputPath;
}


// ═══════════════════════════════════════════════════════════════════
//  GEMINI CALLERS
// ═══════════════════════════════════════════════════════════════════

async function callGemini({ systemInstruction, history, userText }) {
    const keys = getAllKeys();
    if (!keys?.length) throw new Error("Không có API key khả dụng.");

    let lastErr = null;
    for (const key of keys) {
        try {
            const genAI  = new GoogleGenerativeAI(key);
            const model  = genAI.getGenerativeModel({ model: "gemini-2.5-flash", systemInstruction, safetySettings });
            const chat   = model.startChat({ history });
            const result = await chat.sendMessage(userText);
            return result.response.text()?.trim();
        } catch (err) {
            lastErr = err;
            console.warn(`[AI] Key lỗi (${key.slice(0, 8)}...): ${err.message}`);
        }
    }
    throw lastErr || new Error("Tất cả key đều thất bại.");
}

async function callGeminiVision({ systemInstruction, prompt, base64, mimeType }) {
    const keys = getAllKeys();
    if (!keys?.length) throw new Error("Không có API key khả dụng.");

    let lastErr = null;
    for (const key of keys) {
        try {
            const genAI  = new GoogleGenerativeAI(key);
            const model  = genAI.getGenerativeModel({ model: "gemini-2.5-flash", systemInstruction, safetySettings });
            const result = await model.generateContent([
                prompt,
                { inlineData: { data: base64, mimeType } },
            ]);
            return result.response.text()?.trim();
        } catch (err) {
            lastErr = err;
            console.warn(`[AI] Vision key lỗi: ${err.message}`);
        }
    }
    throw lastErr || new Error("Vision: tất cả key đều thất bại.");
}


// ═══════════════════════════════════════════════════════════════════
//  ===== FILE: ai.js =====
//  AI THƯỜNG — Personality, History, Message Logger
// ═══════════════════════════════════════════════════════════════════

function getPersonality() {
    try { return fs.readFileSync(PERSONALITY_PATH, "utf8"); }
    catch { return "Bạn là Th07, một AI trợ lý Discord thân thiện được tạo bởi Zay."; }
}

function buildSystemPrompt(channelId, message, extra = "") {
    const base    = getPersonality();
    const now     = new Date();
    const guildId = message.guild?.id || "DM";

    const timeInfo =
        `\n\n---\nTHỜI GIAN HIỆN TẠI\n` +
        `Năm: ${now.getFullYear()} | Tháng: ${now.getMonth() + 1} | Ngày: ${now.getDate()} ` +
        `| Giờ: ${now.getHours()} | Phút: ${now.getMinutes()}\n` +
        `Channel ID hiện tại: ${channelId}\n` +
        `Guild ID hiện tại: ${guildId}\n`;

    const nick     = message.member?.nickname || message.author.username;
    const userInfo = `\nNgười đang nhắn: ${nick} (ID: ${message.author.id})\n`;
    const guildCtx = buildGuildContextForAI(guildId, channelId);

    return base + timeInfo + userInfo + guildCtx + extra;
}

function buildGuildContextForAI(guildId, currentChannelId) {
    loadMsgGuild(guildId);
    const guildData = msgCache[guildId] || {};

    let allMsgs = [];
    for (const [chId, msgs] of Object.entries(guildData)) {
        for (const m of msgs) allMsgs.push({ ...m, _chId: chId });
    }
    allMsgs.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

    const curMsgs   = allMsgs.filter(m => m._chId === currentChannelId).slice(-60);
    const otherMsgs = allMsgs.filter(m => m._chId !== currentChannelId).slice(-40);
    const combined  = [...otherMsgs, ...curMsgs]
        .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

    if (!combined.length) return "";

    let ctx = `\n\n---\nLỊCH SỬ TIN NHẮN GUILD GẦN ĐÂY (bao gồm bot khác, embed, lỗi...)\n`;

    for (const m of combined) {
        const time    = m.timestamp.slice(11, 16);
        const chName  = m.channelName || m.channelId;
        const who     = m.author.isBot
            ? `<:robot:1497103028560461895> ${m.author.username} (botID:${m.author.botId})`
            : `<:who:1497106135247884431> ${m.author.username}${m.author.nickname ? ` / ${m.author.nickname}` : ""} (ID:${m.author.id})`;
        const deleted = m.deletedAt ? " [ĐÃ XÓA]" : "";
        const edited  = m.editedAt  ? " [ĐÃ SỬA]"  : "";

        let line = `[${time}] [#${chName}] ${who}${deleted}${edited}:\n`;
        if (m.content) line += `  <:chat:1496519744910528573> ${m.content.slice(0, 300)}\n`;

        for (const emb of (m.embeds || [])) {
            const parts = [];
            if (emb.title)        parts.push(`title="${emb.title}"`);
            if (emb.description)  parts.push(`desc="${emb.description.slice(0, 200)}"`);
            if (emb.fields?.length) {
                const fStr = emb.fields.map(f => `${f.name}: ${f.value}`).join(" | ").slice(0, 200);
                parts.push(`fields=[${fStr}]`);
            }
            if (emb.footer) parts.push(`footer="${emb.footer}"`);
            if (emb.image)  parts.push(`image=${emb.image}`);
            if (parts.length) line += `  <:record:1497103035200045076> EMBED(id:${emb.id || "?"}): ${parts.join(", ")}\n`;
        }

        for (const att of (m.attachments || [])) {
            line += `  <:gghim:1497108496414674974> FILE: ${att.name} (${att.contentType || "unknown"})\n`;
        }

        if (m.replyRef) line += `  <:rback:1497108246421307534> reply→msgID:${m.replyRef.messageId}\n`;
        ctx += line;
    }

    ctx += `---\nNếu thấy bot khác (<:robot:1497103028560461895>) lỗi hoặc không reply, hãy dựa vào context trên để trả lời thay. Giải thích rõ cho user nếu có lỗi từ bot khác.\n`;
    return ctx;
}

// ── AI Chat History ───────────────────────────────────────────────
let guildHistories = {};

function historyFilePath(guildId)       { return path.join(HISTORY_DIR, `${guildId}.json`); }

function loadGuildHistory(guildId) {
    if (guildHistories[guildId]) return;
    try {
        const fp = historyFilePath(guildId);
        if (fs.existsSync(fp)) {
            const raw = fs.readFileSync(fp, "utf8").trim();
            if (raw) { guildHistories[guildId] = JSON.parse(raw); return; }
        }
    } catch (e) { console.error(`[AI] Load history guild ${guildId} lỗi:`, e.message); }
    guildHistories[guildId] = {};
}

function saveGuildHistory(guildId) {
    try {
        ensureDir(HISTORY_DIR);
        fs.writeFileSync(historyFilePath(guildId), JSON.stringify(guildHistories[guildId], null, 2), "utf8");
    } catch (e) { console.error(`[AI] Save history guild ${guildId} lỗi:`, e.message); }
}

function getChannelLog(guildId, channelId) {
    loadGuildHistory(guildId);
    if (!guildHistories[guildId][channelId]) guildHistories[guildId][channelId] = [];
    return guildHistories[guildId][channelId];
}

function pushEntry(guildId, channelId, message, userMessage, botReply, hasImage = false) {
    const log   = getChannelLog(guildId, channelId);
    const entry = {
        timestamp:   new Date().toISOString(),
        user: {
            id:       message.author.id,
            name:     message.author.username,
            nickname: message.member?.nickname || message.author.username,
        },
        userMessage,
        botReply,
        hasImage,
    };
    log.push(entry);
    if (log.length > MAX_LOG_ENTRIES) log.splice(0, log.length - MAX_LOG_ENTRIES);
    saveGuildHistory(guildId);
}

function buildGeminiHistory(guildId) {
    loadGuildHistory(guildId);
    const guildData = guildHistories[guildId] || {};

    let allEntries = [];
    for (const [chId, entries] of Object.entries(guildData)) {
        for (const entry of entries) allEntries.push({ ...entry, _channelId: chId });
    }
    allEntries.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
    const recent  = allEntries.slice(-MAX_GEMINI_TURNS);
    const history = [];

    for (const entry of recent) {
        if (!entry.userMessage?.trim() || !entry.botReply?.trim()) continue;
        const userTag    = entry.user.id === OWNER_ID ? `{${entry.user.id}-admin}` : `{${entry.user.id}}`;
        const channelTag = entry._channelId ? `[ch:${entry._channelId}] ` : "";
        history.push({ role: "user",  parts: [{ text: `${channelTag}${userTag} ${entry.userMessage}` }] });
        history.push({ role: "model", parts: [{ text: entry.botReply }] });
    }

    while (history.length > 0 && history[0].role === "model") history.shift();
    return history;
}

function clearChannelHistory(guildId, channelId) {
    loadGuildHistory(guildId);
    if (guildHistories[guildId]) {
        guildHistories[guildId][channelId] = [];
        saveGuildHistory(guildId);
    }
}

function clearGuildHistory(guildId) {
    guildHistories[guildId] = {};
    saveGuildHistory(guildId);
}

// ── Message Logger ────────────────────────────────────────────────
const msgCache    = {};
const dirtyGuilds = new Set();
const saveTimers  = {};

function msgFilePath(guildId) { return path.join(MSG_LOG_DIR, `${guildId}.json`); }

function loadMsgGuild(guildId) {
    if (msgCache[guildId]) return;
    try {
        const fp = msgFilePath(guildId);
        if (fs.existsSync(fp)) {
            const raw = fs.readFileSync(fp, "utf8").trim();
            if (raw) { msgCache[guildId] = JSON.parse(raw); return; }
        }
    } catch (e) { console.error(`[Logger] Load guild ${guildId} lỗi:`, e.message); }
    msgCache[guildId] = {};
}

function scheduleMsgWrite(guildId) {
    dirtyGuilds.add(guildId);
    if (saveTimers[guildId]) clearTimeout(saveTimers[guildId]);
    saveTimers[guildId] = setTimeout(() => flushMsgGuild(guildId), MSG_SAVE_DEBOUNCE);
}

function flushMsgGuild(guildId) {
    if (!msgCache[guildId]) return;
    try {
        ensureDir(MSG_LOG_DIR);
        fs.writeFileSync(msgFilePath(guildId), JSON.stringify(msgCache[guildId], null, 2), "utf8");
        dirtyGuilds.delete(guildId);
    } catch (e) { console.error(`[Logger] Save guild ${guildId} lỗi:`, e.message); }
}

function flushAllMsg() {
    for (const guildId of dirtyGuilds) flushMsgGuild(guildId);
}

function buildMsgEntry(message) {
    const isBot = message.author.bot;
    const embeds = message.embeds.map(e => ({
        id: e.id || null, title: e.title || null, description: e.description || null,
        url: e.url || null, color: e.color || null, footer: e.footer?.text || null,
        image: e.image?.url || null, thumbnail: e.thumbnail?.url || null,
        fields: (e.fields || []).map(f => ({ name: f.name, value: f.value, inline: f.inline })),
        author: e.author ? { name: e.author.name, iconURL: e.author.iconURL, url: e.author.url } : null,
        timestamp: e.timestamp || null,
    }));
    const attachments = [...(message.attachments?.values() || [])].map(a => ({
        id: a.id, name: a.name, url: a.url, contentType: a.contentType || null, size: a.size,
    }));
    return {
        messageId:   message.id,
        timestamp:   message.createdAt.toISOString(),
        channelId:   message.channel.id,
        channelName: message.channel.name || null,
        author: {
            id:        message.author.id,
            username:  message.author.username,
            nickname:  message.member?.nickname || null,
            isBot,
            botId:     isBot ? message.author.id : null,
            avatarURL: message.author.displayAvatarURL?.() || null,
        },
        content:     message.content || null,
        embeds,
        attachments,
        replyRef: message.reference ? {
            messageId: message.reference.messageId,
            channelId: message.reference.channelId,
            guildId:   message.reference.guildId,
        } : null,
        stickers: [...(message.stickers?.values() || [])].map(s => ({ id: s.id, name: s.name })),
        mentions: {
            users:    [...(message.mentions.users?.values()  || [])].map(u => ({ id: u.id, username: u.username })),
            roles:    [...(message.mentions.roles?.values()  || [])].map(r => ({ id: r.id, name: r.name })),
            everyone: message.mentions.everyone || false,
        },
        editedAt:  null,
        deletedAt: null,
    };
}

function pushMsgEntry(message) {
    const guildId   = message.guild?.id;
    const channelId = message.channel?.id;
    if (!guildId || !channelId) return;
    loadMsgGuild(guildId);
    if (!msgCache[guildId][channelId]) msgCache[guildId][channelId] = [];
    const log = msgCache[guildId][channelId];
    if (log.some(e => e.messageId === message.id)) return;
    log.push(buildMsgEntry(message));
    if (log.length > MSG_MAX_PER_CHANNEL) log.splice(0, log.length - MSG_MAX_PER_CHANNEL);
    const total = Object.values(msgCache[guildId]).reduce((s, a) => s + a.length, 0);
    if (total > MSG_MAX_PER_GUILD) {
        const biggest = Object.entries(msgCache[guildId])
            .sort((a, b) => b[1].length - a[1].length)[0];
        if (biggest) biggest[1].shift();
    }
    scheduleMsgWrite(guildId);
}

function markMsgEdited(message) {
    const guildId = message.guild?.id;
    const chId    = message.channel?.id;
    if (!guildId || !chId) return;
    loadMsgGuild(guildId);
    const entry = (msgCache[guildId]?.[chId] || []).find(e => e.messageId === message.id);
    if (entry) {
        entry.content  = message.content || entry.content;
        entry.editedAt = new Date().toISOString();
        scheduleMsgWrite(guildId);
    }
}

function markMsgDeleted(messageId, channelId, guildId) {
    if (!guildId || !channelId) return;
    loadMsgGuild(guildId);
    const entry = (msgCache[guildId]?.[channelId] || []).find(e => e.messageId === messageId);
    if (entry) {
        entry.deletedAt = new Date().toISOString();
        scheduleMsgWrite(guildId);
    }
}

function getRecentMessages(guildId, channelId, limit = 50) {
    loadMsgGuild(guildId);
    return (msgCache[guildId]?.[channelId] || []).slice(-limit);
}

function getBotMessages(guildId, channelId, botId, limit = 20) {
    loadMsgGuild(guildId);
    return (msgCache[guildId]?.[channelId] || [])
        .filter(e => e.author.botId === botId).slice(-limit);
}

function getLastEmbedMessage(guildId, channelId, botId = null) {
    loadMsgGuild(guildId);
    const log = (msgCache[guildId]?.[channelId] || [])
        .filter(e => e.embeds.length > 0 && (!botId || e.author.botId === botId));
    return log[log.length - 1] || null;
}

function findMessage(guildId, channelId, messageId) {
    loadMsgGuild(guildId);
    return (msgCache[guildId]?.[channelId] || []).find(e => e.messageId === messageId) || null;
}

function getMsgStats(guildId) {
    loadMsgGuild(guildId);
    const data     = msgCache[guildId] || {};
    const channels = Object.entries(data)
        .map(([chId, arr]) => ({ channelId: chId, count: arr.length }))
        .sort((a, b) => b.count - a.count);
    return {
        guildId,
        totalMessages: channels.reduce((s, c) => s + c.count, 0),
        totalChannels: channels.length,
        channels,
    };
}

// ── Chatbot channel DB ────────────────────────────────────────────
async function getChatbotChannel(client, guildId) { return await client.db.get(`chatbot_channel_${guildId}`); }
async function setChatbotChannel(client, guildId, channelId) { await client.db.set(`chatbot_channel_${guildId}`, channelId); }
async function removeChatbotChannel(client, guildId) { await client.db.delete(`chatbot_channel_${guildId}`); }




// ── Bot failure watch ─────────────────────────────────────────────
const pendingReplies = new Map();

function cancelBotFailureWatch(message) {
    if (!message.author.bot) return;
    if (!message.reference?.messageId) return;
    const key   = `${message.guild?.id}-${message.channel?.id}-${message.reference.messageId}`;
    const timer = pendingReplies.get(key);
    if (timer) { clearTimeout(timer); pendingReplies.delete(key); }
}


// ═══════════════════════════════════════════════════════════════════
//  MEDIA & FILE HANDLERS (MỚI)
// ═══════════════════════════════════════════════════════════════════

/**
 * Xử lý ảnh đính kèm — phân tích qua Gemini Vision.
 * (Giữ nguyên logic cũ, refactor thành hàm riêng)
 */
async function handleImageAttachment(attach, query, systemPrompt, message, userTag) {
    const base64  = await urlToBase64(attach.url);
    const prompt  = query.length > 0 ? `${userTag} ${query}` : "Mô tả chi tiết hình ảnh này bằng tiếng Việt.";
    return callGeminiVision({ systemInstruction: systemPrompt, prompt, base64, mimeType: attach.contentType });
}

/**
 * Xử lý video đính kèm.
 * - Gemini 2.5 Flash hỗ trợ video qua File API (Google), nhưng chúng ta gọi inline.
 * - Với mp4/webm/mov: gửi mimeType video trực tiếp vào inlineData nếu < 20MB, còn không thì mô tả meta.
 */
async function handleVideoAttachment(attach, query, systemPrompt, message, userTag) {
    const MAX_INLINE_VIDEO = 20 * 1024 * 1024; // 20MB

    const prompt = query.length > 0
        ? `${userTag} ${query}`
        : "Mô tả chi tiết nội dung video này bằng tiếng Việt: nội dung, chủ đề, cảm xúc, bất cứ thứ gì bạn thấy.";

    if (attach.size <= MAX_INLINE_VIDEO) {
        try {
            const base64 = await urlToBase64(attach.url);
            return await callGeminiVision({
                systemInstruction: systemPrompt,
                prompt,
                base64,
                mimeType: attach.contentType,
            });
        } catch (err) {
            console.warn("[AI] Video inline lỗi, fallback meta:", err.message);
        }
    }

    // Fallback: mô tả dựa trên meta
    const sizeMB = (attach.size / 1024 / 1024).toFixed(1);
    const metaPrompt = `${userTag} Người dùng đã gửi một video tên "${attach.name}" (${sizeMB}MB, định dạng ${attach.contentType}). Video quá lớn để phân tích trực tiếp. Câu hỏi của người dùng: "${query || "Mô tả video này"}". Hãy giải thích rằng bạn không thể xem trực tiếp do kích thước, nhưng cố gắng gợi ý dựa trên tên file.`;
    return callGemini({ systemInstruction: systemPrompt, history: [], userText: metaPrompt });
}

/**
 * Xử lý file đính kèm không phải ảnh/video:
 * - Lưu về src/Zay/Download/<guildId>/
 * - Nếu là file text (txt/json/csv/md/js/py/...) → đọc nội dung, gửi Gemini phân tích
 * - Nếu là file khác → thông báo đã lưu + meta
 */
async function handleFileAttachment(attach, query, systemPrompt, message, userTag, guildId) {
    const filename = attach.name || `file_${Date.now()}`;
    let savedPath  = null;

    try {
        savedPath = await downloadFile(attach.url, filename, guildId);
    } catch (err) {
        console.error("[AI] Download file lỗi:", err.message);
    }

    const textExts = [".txt", ".json", ".csv", ".md", ".js", ".ts", ".py", ".html", ".css", ".yml", ".yaml", ".xml", ".log", ".env"];
    const ext      = path.extname(filename).toLowerCase();
    const isText   = textExts.includes(ext);

    if (isText && savedPath) {
        try {
            const content   = fs.readFileSync(savedPath, "utf8");
            const truncated = content.length > 8000 ? content.slice(0, 8000) + "\n...[cắt bớt]" : content;
            const filePrompt = `${userTag} Người dùng đã gửi file "${filename}". Nội dung:\n\`\`\`\n${truncated}\n\`\`\`\n\nYêu cầu: ${query || "Đọc và phân tích file này."}`;
            return await callGemini({ systemInstruction: systemPrompt, history: [], userText: filePrompt });
        } catch (readErr) {
            console.error("[AI] Đọc file text lỗi:", readErr.message);
        }
    }

    // File nhị phân hoặc không đọc được text
    const sizeMB    = (attach.size / 1024 / 1024).toFixed(2);
    const savedNote = savedPath ? `\n💾 Đã lưu vào: \`${path.relative(path.join(__dirname, "../.."), savedPath)}\`` : "";
    const metaText  = `${userTag} Người dùng gửi file "${filename}" (${sizeMB}MB, ${attach.contentType || "unknown"}). ${query || ""}`;
    const aiReply   = await callGemini({ systemInstruction: systemPrompt, history: [], userText: metaText });
    return (aiReply || "") + savedNote;
}

/**
 * Gửi IB (DM) cho user được chỉ định.
 * Target: mention hoặc ID.
 */
async function sendDM(client, targetUser, content, attachment = null) {
    const dm = await targetUser.createDM();
    if (attachment) {
        await dm.send({ content, files: [attachment] });
    } else {
        await dm.send(content);
    }
}

/**
 * Đăng ký tag hẹn giờ: sau `ms` ms, tag user trong kênh ban đầu với `tagMsg`.
 */
function scheduleTag(client, { userId, channelId, guildId, ms, tagMsg, label }) {
    const id      = ++_tagIdCounter;
    const timeout = setTimeout(async () => {
        scheduledTags.delete(id);
        try {
            const channel = client.channels.cache.get(channelId)
                ?? await client.channels.fetch(channelId).catch(() => null);
            if (!channel) return;
            await channel.send(`<@${userId}> ${tagMsg}`);
        } catch (err) {
            console.error("[AI] scheduleTag gửi lỗi:", err.message);
        }
    }, ms);
    scheduledTags.set(id, { timeout, userId, channelId, guildId, label });
    return id;
}


// ═══════════════════════════════════════════════════════════════════
//  ATTACHMENT DISPATCHER — phân loại và xử lý đúng loại file
// ═══════════════════════════════════════════════════════════════════

async function dispatchAttachment(attach, query, systemPrompt, message, userTag, guildId) {
    const ct = attach.contentType || "";

    if (ct.startsWith("image/")) {
        return handleImageAttachment(attach, query, systemPrompt, message, userTag);
    }
    if (ct.startsWith("video/")) {
        return handleVideoAttachment(attach, query, systemPrompt, message, userTag);
    }
    // audio, pdf, text, binary...
    return handleFileAttachment(attach, query, systemPrompt, message, userTag, guildId);
}


// ═══════════════════════════════════════════════════════════════════
//  FORMAT & SEND
// ═══════════════════════════════════════════════════════════════════

async function formatAndSend(text, message) {
    const drawMatch = text.match(/\{draw-image\}\[([^\]]+)\]/);
    if (drawMatch) {
        const prompt      = drawMatch[1];
        const cleanedText = text.replace(drawMatch[0], "").trim();
        const imageUrl    = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}`;

        if (cleanedText) {
            for (const p of splitMessage(cleanedText))
                await message.channel.send(`<@${message.author.id}> ${p}`);
        }

        await message.channel.sendTyping().catch(() => {});
        await message.react("<:art:1497112196713418864>").catch(() => {});

        const resultUrl = await waitForImage(imageUrl);
        if (resultUrl) await message.reply(resultUrl);
        else           await message.reply("<:disabled:1487783250452545616> Tạo ảnh thất bại, thử lại sau nhé.");
        return;
    }

    const parts = splitMessage(text);
    for (let i = 0; i < parts.length; i++) {
        const prefix = i === 0 ? `<@${message.author.id}> ` : "";
        await message.channel.send(prefix + parts[i]);
        if (parts.length > 1) await new Promise(r => setTimeout(r, 200));
    }
}


// ═══════════════════════════════════════════════════════════════════
//  INTENT DETECTION — phát hiện yêu cầu đặc biệt từ query
// ═══════════════════════════════════════════════════════════════════

/**
 * Phát hiện yêu cầu tag hẹn giờ từ query.
 * Ví dụ: "tag tao sau 5 phút", "nhắc tao sau 2 giờ", "tag mình sau 1 ngày"
 * Trả về { delay, tagMsg } hoặc null.
 */
function detectScheduledTagIntent(query) {
    // Patterns: "tag tao/mình/tôi sau X [đơn vị]" hoặc "nhắc tao sau X [đơn vị] [nội dung]"
    const patterns = [
        /(?:tag|nhắc|ping|remind)\s+(?:tao|tôi|mình|moi|t)\s+sau\s+(.+)/i,
        /(?:sau|after)\s+([\d]+\s*(?:giây|phút|giờ|ngày|s|m|h|d|second|minute|hour|day))\s*(?:thì\s*)?(?:tag|nhắc|ping)?\s*(.*)/i,
    ];

    for (const pat of patterns) {
        const m = query.match(pat);
        if (m) {
            const rawTime = m[1]?.trim() || "";
            const delay   = parseDelay(rawTime);
            if (delay) {
                // Nội dung nhắc nằm sau thời gian (nếu có)
                const afterTime = rawTime.length;
                const rawMsg    = (m[2] || query.replace(m[0], "")).trim();
                const tagMsg    = rawMsg || "Đây là nhắc nhở của bạn!";
                return { delay, tagMsg };
            }
        }
    }
    return null;
}

/**
 * Phát hiện yêu cầu gửi IB/DM.
 * Hỗ trợ: mention <@id>, hoặc tên user trong guild.
 * Ví dụ: "gửi ib cho @user nội dung..."
 *         "gửi dm cho Zay nội dung..."
 * Trả về { targetId, targetName, dmContent } hoặc null.
 */
function detectDMIntent(query, message) {
    // Dạng mention: gửi ib/dm cho <@id> nội dung
    const ibMentionPattern = /(?:gửi\s*(?:ib|dm|tin nhắn riêng|tin nhắn))\s+(?:cho\s+)?<@!?(\d+)>\s*(.*)/i;
    const m1 = query.match(ibMentionPattern);
    if (m1) return { targetId: m1[1], targetName: null, dmContent: m1[2]?.trim() || "" };

    // Dạng tên: gửi ib/dm cho <tên> nội dung
    const ibNamePattern = /(?:gửi\s*(?:ib|dm|tin nhắn riêng|tin nhắn))\s+(?:cho\s+)?([^\s<@][^\n,]{1,30}?)\s+(?:nội dung|rằng|là|với nội dung|:\s*)(.+)/i;
    const m2 = query.match(ibNamePattern);
    if (m2) return { targetId: null, targetName: m2[1].trim(), dmContent: m2[2]?.trim() || "" };

    // Dạng đơn giản: gửi ib/dm <tên> <nội dung> (tên 1-3 từ)
    const ibSimplePattern = /(?:gửi\s*(?:ib|dm|tin nhắn riêng|tin nhắn))\s+(?:cho\s+)?(\S+(?:\s\S+){0,2}?)\s{2,}(.+)/i;
    const m3 = query.match(ibSimplePattern);
    if (m3 && !m3[1].startsWith("<")) return { targetId: null, targetName: m3[1].trim(), dmContent: m3[2]?.trim() || "" };

    return null;
}

/**
 * Tìm member trong guild theo tên (username hoặc nickname).
 * Trả về member đầu tiên tìm được, hoặc null.
 */
async function findMemberByNameInGuild(guild, name) {
    if (!guild || !name) return null;
    const needle = name.toLowerCase().trim();
    try {
        // Thử fetch từ API Discord (tìm theo username prefix)
        const fetched = await guild.members.fetch({ query: needle, limit: 5 }).catch(() => null);
        if (fetched?.size) return fetched.first();
    } catch {}
    // Fallback: tìm trong cache
    return guild.members.cache.find(m =>
        m.user.username.toLowerCase().includes(needle) ||
        m.user.displayName?.toLowerCase().includes(needle) ||
        (m.nickname || "").toLowerCase().includes(needle)
    ) || null;
}

/**
 * Phát hiện yêu cầu tag/mention user theo tên trong guild.
 * Ví dụ: "tag Zay", "mention dzaycrazy"
 * Trả về { targetName } hoặc null.
 */
function detectTagByNameIntent(query) {
    const tagPattern = /(?:^|\s)(?:tag|mention|ping|gọi)\s+(?:user\s+)?(?:tên\s+)?([^\s<@][^\n,!?]{1,30}?)(?:\s+|$)/i;
    const m = query.match(tagPattern);
    if (m) return { targetName: m[1].trim() };
    return null;
}

/**
 * Phát hiện yêu cầu lưu/download file từ attachment.
 * Ví dụ: "lưu file này", "save cái này"
 */
function detectSaveIntent(query) {
    return /(?:lưu|save|download|tải về|tải xuống)/i.test(query);
}

/**
 * Phát hiện yêu cầu chuyển đổi định dạng.
 * Ví dụ: "chuyển sang png", "convert thành jpg", "đổi format thành json"
 */
function detectConvertIntent(query) {
    const m = query.match(/(?:chuyển|convert|đổi|xuất)\s+(?:sang|thành|to|ra|format)?\s*([a-zA-Z0-9]+)/i);
    if (m) return m[1].toLowerCase();
    return null;
}

/**
 * Phát hiện yêu cầu gửi file cho ai.
 * Ví dụ: "gửi file này cho @user", "gửi cái này cho @user qua dm"
 */
function detectSendFileIntent(query, message) {
    const m = query.match(/(?:gửi|send)\s+(?:file|cái này|nó)\s+(?:cho|to)\s+<@!?(\d+)>/i);
    if (!m) return null;
    const viaDM = /(?:dm|ib|riêng)/i.test(query);
    return { targetId: m[1], viaDM };
}


// ═══════════════════════════════════════════════════════════════════
//  CORE AI PROCESSOR (AI thường) — UPDATED
// ═══════════════════════════════════════════════════════════════════

async function _processAI(client, message, rawQuery, isCommand) {
    // Guard: empty query + no attachment → nhắc nhở thay vì crash
    const hasAttach = message.attachments?.size > 0;
    if ((!rawQuery || !rawQuery.trim()) && !hasAttach) {
        return message.reply(
            `<:ask:1496519737096798372> Ờ mày gọi t? Hỏi gì đi
` +
            `-# Gõ \`th!ai <câu hỏi>\` hoặc \`th!ai\` để xem menu lệnh.`
        );
    }
    rawQuery = rawQuery?.trim() || "";

    if (isNsfw(rawQuery) && !message.channel.nsfw)
        return message.reply("<:warning:1487783235286073465> Nội dung này cần kênh NSFW.");

    const guildId   = message.guild?.id || "DM";
    const channelId = message.channel.id;
    const isOwner   = message.author.id === OWNER_ID;
    const nick      = message.member?.nickname || message.author.username;
    const userTag   = isOwner ? `{${message.author.id}-admin}` : `{${message.author.id}}`;

    // ── 1. Tag hẹn giờ ────────────────────────────────────────────
    const tagIntent = detectScheduledTagIntent(rawQuery);
    if (tagIntent) {
        const { delay, tagMsg } = tagIntent;
        const tagId = scheduleTag(client, {
            userId:    message.author.id,
            channelId: message.channel.id,
            guildId,
            ms:        delay.ms,
            tagMsg,
            label:     delay.label,
        });
        return message.reply(
            `<:time_left:1497103031123312771> Ok, sẽ tag mày sau **${delay.label}** — ID nhắc: \`${tagId}\``
        );
    }

    // ── 2. Gửi DM / IB ────────────────────────────────────────────
    const dmIntent = detectDMIntent(rawQuery, message);
    if (dmIntent) {
        const { targetId, targetName, dmContent } = dmIntent;
        try {
            let targetUser = null;

            if (targetId) {
                // Có mention ID trực tiếp
                targetUser = await client.users.fetch(targetId).catch(() => null);
            } else if (targetName && message.guild) {
                // Tìm theo tên trong guild
                const member = await findMemberByNameInGuild(message.guild, targetName);
                if (member) targetUser = member.user;
            }

            if (!targetUser)
                return message.reply(
                    `<:warning:1487783235286073465> Không tìm thấy user **${targetName || targetId}** trong server này`
                );

            const content = dmContent || `*Tin nhắn từ ${nick} qua bot Th07*`;
            await sendDM(client, targetUser, content);
            return message.reply(
                `<:enable:1487783260565143614> Đã gửi IB cho <@${targetUser.id}> (**${targetUser.username}**) rồi`
            );
        } catch (err) {
            return message.reply(`<:disabled:1487783250452545616> Gửi DM thất bại: ${err.message}`);
        }
    }

    // ── 2b. Tag user theo tên ─────────────────────────────────────
    const tagByNameIntent = detectTagByNameIntent(rawQuery);
    if (tagByNameIntent && message.guild) {
        const member = await findMemberByNameInGuild(message.guild, tagByNameIntent.targetName);
        if (member) {
            // Thêm context về user vào query để AI xử lý tự nhiên
            const tagContext = `\n\n[Bot đã tìm thấy user "${tagByNameIntent.targetName}" trong guild: <@${member.user.id}> (${member.user.username}${member.nickname ? ` / ${member.nickname}` : ""}). Hãy tag họ trong câu trả lời.]`;
            rawQuery = rawQuery + tagContext;
        }
    }

    await message.channel.sendTyping().catch(() => {});

    const systemPrompt = buildSystemPrompt(channelId, message);
    const history      = buildGeminiHistory(guildId);

    // ── 3. Xử lý attachment ───────────────────────────────────────
    const attachments = [...(message.attachments?.values() || [])];
    if (attachments.length > 0) {
        const attach = attachments[0]; // xử lý file đầu tiên

        // 3a. Detect convert intent trước khi phân tích
        const convertTarget = detectConvertIntent(rawQuery);
        if (convertTarget && detectSaveIntent(rawQuery) === false) {
            // Có thể user muốn convert file đã lưu trước đó — skip, xử lý ở subcommand
        }

        // 3b. Detect send-file intent
        const sendFileIntent = detectSendFileIntent(rawQuery, message);
        if (sendFileIntent) {
            const { targetId, viaDM } = sendFileIntent;
            try {
                // Lưu file tạm
                const filename = attach.name || `file_${Date.now()}`;
                const savedPath = await downloadFile(attach.url, filename, guildId);
                const targetUser = await client.users.fetch(targetId);
                const attachment = new AttachmentBuilder(savedPath, { name: filename });

                if (viaDM) {
                    await sendDM(client, targetUser, `*${nick} gửi file cho bạn qua Th07:*`, attachment);
                    return message.reply(`<:enable:1487783260565143614> Đã gửi file cho <@${targetId}> qua DM`);
                } else {
                    const targetChannel = message.channel;
                    await targetChannel.send({ content: `<@${targetId}> Đây là file từ <@${message.author.id}>:`, files: [attachment] });
                    return message.reply(`<:enable:1487783260565143614> Đã gửi file cho <@${targetId}> trong kênh này.`);
                }
            } catch (err) {
                return message.reply(`<:disabled:1487783250452545616> Gửi file thất bại: ${err.message}`);
            }
        }

        // 3c. Detect save intent
        if (detectSaveIntent(rawQuery)) {
            try {
                const filename  = attach.name || `file_${Date.now()}`;
                const savedPath = await downloadFile(attach.url, filename, guildId);
                const rel       = path.relative(path.join(__dirname, "../.."), savedPath);
                return message.reply(
                    `<:enable:1487783260565143614> Đã lưu file **${filename}** vào \`${rel}\` rồi`
                );
            } catch (err) {
                return message.reply(`<:disabled:1487783250452545616> Lưu file thất bại: ${err.message}`);
            }
        }

        // 3d. Phân tích / xử lý file theo loại
        try {
            const reply = await dispatchAttachment(attach, rawQuery, systemPrompt, message, userTag, guildId);
            if (!reply) return message.reply("<:warning:1487783235286073465> AI không trả về nội dung.");

            const typeLabel = attach.contentType?.startsWith("video/") ? "[Phân tích video]"
                            : attach.contentType?.startsWith("image/") ? "[Phân tích ảnh]"
                            : "[Đọc file]";
            pushEntry(guildId, channelId, message, `${typeLabel} ${rawQuery}`, reply, true);
            await formatAndSend(reply, message);
        } catch (err) {
            console.error("[AI] Attachment error:", err);
            await message.reply(`<:disabled:1487783250452545616> Lỗi xử lý file: ${err.message}`).catch(() => {});
        }
        return;
    }

    // ── 4. Chat text thường ───────────────────────────────────────
    const userMessage = `[ch:${channelId}] ${userTag} ${rawQuery}`;
    try {
        const reply = await callGemini({ systemInstruction: systemPrompt, history, userText: userMessage });
        if (!reply) return message.reply("<:warning:1487783235286073465> AI không trả về nội dung.");
        pushEntry(guildId, channelId, message, rawQuery, reply, false);
        await formatAndSend(reply, message);
        console.log(`[AI] ✅ ${nick} (${message.author.id}) — ${rawQuery.slice(0, 60)}`);
    } catch (err) {
        console.error("[AI] callGemini error:", err);
        await message.reply(
            `<:disabled:1487783250452545616> Lỗi AI: ${err.message}\n` +
            (err.message?.includes("quota") || err.message?.includes("429")
                ? "*(Tất cả key đang bị rate limit, thử lại sau nhé)*" : "")
        ).catch(() => {});
    }
}


// ═══════════════════════════════════════════════════════════════════
//  REGISTER EVENTS (AI thường)
// ═══════════════════════════════════════════════════════════════════

function registerEvents(client) {
    if (client._aiEventsRegistered) return;
    client._aiEventsRegistered = true;

    client.on("messageCreate", async (msg) => {
        if (!msg.guild) return;

        pushMsgEntry(msg);

        if (msg.author.bot) return;
        if (msg.content.startsWith("th!")) return;

        const botMentioned = msg.mentions.users.has(client.user.id);
        if (botMentioned) {
            let query = msg.content
                .replace(/<@!?(\d+)>/g, (match, id) => id === client.user.id ? "" : match)
                .trim();

            async function fetchMemberInfo(member, user) {
                const nick    = member?.nickname || user.username;
                const roles   = member?.roles?.cache
                    ?.filter(r => r.id !== msg.guild.id)
                    ?.map(r => r.name)
                    ?.join(", ") || "Không có role";
                const joined  = member?.joinedAt
                    ? new Date(member.joinedAt).toLocaleDateString("vi-VN")
                    : "Không rõ";
                const created = new Date(user.createdAt).toLocaleDateString("vi-VN");
                const status  = member?.presence?.status || "offline";
                return (
                    `• Tên hiển thị: ${nick}\n` +
                    `• Username: ${user.username} (ID: ${user.id})\n` +
                    `• Roles: ${roles}\n` +
                    `• Vào server: ${joined}\n` +
                    `• Tạo tài khoản: ${created}\n` +
                    `• Trạng thái: ${status}`
                );
            }

            async function findMemberByName(name) {
                if (!name) return [];
                const needle = name.toLowerCase().trim();
                try {
                    const members = await msg.guild.members.fetch({ query: needle, limit: 5 }).catch(() => null);
                    if (members?.size) return [...members.values()];
                    return msg.guild.members.cache.filter(m =>
                        m.user.username.toLowerCase().includes(needle) ||
                        (m.nickname || "").toLowerCase().includes(needle)
                    ).first(5);
                } catch { return []; }
            }

            const mentionedUsers = msg.mentions.users.filter(u => u.id !== client.user.id);
            const infoParts      = [];

            if (mentionedUsers.size > 0) {
                for (const [uid, user] of mentionedUsers) {
                    const member = await msg.guild.members.fetch(uid).catch(() => null);
                    infoParts.push(await fetchMemberInfo(member, user));
                }
            }

            if (infoParts.length === 0 && query) {
                const namePatterns = [
                    /(?:ai là|là ai|info|tìm|xem|check|tra|hỏi về|về)\s+([^\s?.,!]+(?:\s[^\s?.,!]+)?)/i,
                    /^([^\s?.,!]+(?:\s[^\s?.,!]+)?)\s+(?:là ai|là gì|có role gì|có quyền gì)/i,
                ];
                let guessedName = null;
                for (const pat of namePatterns) {
                    const m = query.match(pat);
                    if (m?.[1]) { guessedName = m[1].trim(); break; }
                }
                if (!guessedName) {
                    const stopWords = new Set(["ai","là","gì","có","không","thế","nào","ơi","ê","hey","hỏi","cho","biết","về","tìm","xem"]);
                    const words = query.split(/\s+/).filter(w => !stopWords.has(w.toLowerCase()));
                    if (words.length) guessedName = words.slice(0, 2).join(" ");
                }
                if (guessedName) {
                    const found = await findMemberByName(guessedName);
                    for (const member of found) {
                        infoParts.push(await fetchMemberInfo(member, member.user));
                    }
                }
            }

            let mentionContext = "";
            if (infoParts.length > 0) {
                mentionContext = `\n\n[Thông tin thành viên tìm được trong guild]\n` + infoParts.join("\n\n---\n");
            }

            if (!query && infoParts.length === 0) query = "Chào!";
            else if (!query && infoParts.length > 0) query = "Cho tôi biết thông tin về người này trong server.";

            await _processAI(client, msg, query + mentionContext, false);
            return;
        }
    });

    client.on("messageUpdate", (_, newMsg) => {
        if (!newMsg.guild) return;
        const gId = newMsg.guild.id;
        const cId = newMsg.channel.id;
        loadMsgGuild(gId);
        const exists = (msgCache[gId]?.[cId] || []).some(e => e.messageId === newMsg.id);
        if (exists) markMsgEdited(newMsg);
        else pushMsgEntry(newMsg);
    });

    client.on("messageDelete", (msg) => {
        if (!msg.guild) return;
        markMsgDeleted(msg.id, msg.channel.id, msg.guild.id);
    });

    process.on("SIGINT",  () => { flushAllMsg(); process.exit(0); });
    process.on("SIGTERM", () => { flushAllMsg(); process.exit(0); });

    console.log("[AI] Message logger + events đã registered.");
}


// ═══════════════════════════════════════════════════════════════════
//  ===== FILE: aihotro.js =====
//  AI XÁC MINH — Personality, History, Message Logger riêng
// ═══════════════════════════════════════════════════════════════════

const helpDailyCache = {};


// ═══════════════════════════════════════════════════════════════════
//  AI COMMAND — run() handler với các subcommand mới
// ═══════════════════════════════════════════════════════════════════

const aiCommand = {
    name:        "ai",
    aliases:     ["ask", "chat", "giaidap", "hoi", "alo", "th"],
    description: "Chat với AI Gemini — hỗ trợ ảnh/video/file, tạo ảnh, gửi DM, tag hẹn giờ | th!ai ask <câu hỏi>",
    category:    "ai",
    cooldown:    3,
    premium:     true,

    registerEvents,
    getRecentMessages,
    getBotMessages,
    getLastEmbedMessage,
    findMessage,
    getMsgStats,
    flushAllMsg,

    handleChatbotMessage: async (client, message) => {
        if (message.author.bot) return;
        const channelId = await getChatbotChannel(client, message.guild.id);
        if (!channelId || message.channel.id !== channelId) return;
        await _processAI(client, message, message.content.trim(), false);
    },

    run: async (client, message, args) => {
        // Fix: args có thể là undefined khi gọi th!ai không có gì
        if (!args) args = [];
        const sub = args[0]?.toLowerCase();

        // ── th!ai ask <nội dung> ──────────────────────────────────
        if (sub === "ask") {
            const query = args.slice(1).join(" ").trim();
            if (!query)
                return message.reply("<:ask:1496519737096798372> Dùng: `th!ai ask <câu hỏi của bạn>`");
            return await _processAI(client, message, query, true);
        }

        // ── th!ai dm / ib <@user|tên> <nội dung> ─────────────────
        if (sub === "dm" || sub === "ib") {
            let targetUser = message.mentions.users.first() || null;
            let contentStartIdx = 2; // args[2...] là nội dung

            // Nếu không có mention → tìm theo tên (args[1] là tên)
            if (!targetUser && args[1]) {
                const nameArg = args[1];
                // Nếu args[1] trông như tên (không phải mention)
                if (!nameArg.startsWith("<@")) {
                    const member = await findMemberByNameInGuild(message.guild, nameArg);
                    if (member) {
                        targetUser = member.user;
                        contentStartIdx = 2;
                    } else {
                        // Thử tìm 2 từ (tên có khoảng cách)
                        if (args[2]) {
                            const twoWordName = `${args[1]} ${args[2]}`;
                            const member2 = await findMemberByNameInGuild(message.guild, twoWordName);
                            if (member2) { targetUser = member2.user; contentStartIdx = 3; }
                        }
                    }
                }
            }

            if (!targetUser)
                return message.reply(
                    "<:warning:1487783235286073465> Không tìm thấy user. Dùng: `th!ai dm @user <nội dung>` hoặc `th!ai dm tên <nội dung>`"
                );

            const content = args.slice(contentStartIdx).join(" ").trim();
            if (!content)
                return message.reply("<:warning:1487783235286073465> Nội dung tin nhắn trống rỗng");
            try {
                await sendDM(client, targetUser, content);
                return message.reply(
                    `<:enable:1487783260565143614> Đã gửi DM cho <@${targetUser.id}> (**${targetUser.username}**) rồi`
                );
            } catch (err) {
                return message.reply(`<:disabled:1487783250452545616> Gửi DM thất bại: ${err.message}`);
            }
        }

        // ── th!ai tag <@user|tên> sau <thời gian> <nội dung> ─────
        if (sub === "tag") {
            // th!ai tag @user sau 5 phút <nội dung>
            // th!ai tag dzaycrazy sau 5 phút <nội dung>
            let targetUser = message.mentions.users.first() || null;
            let rawRest;

            if (targetUser) {
                rawRest = args.slice(2).join(" ");
            } else if (args[1] && !args[1].startsWith("<@")) {
                // Tìm theo tên
                const member = await findMemberByNameInGuild(message.guild, args[1]);
                if (member) {
                    targetUser = member.user;
                    rawRest = args.slice(2).join(" ");
                } else {
                    rawRest = args.slice(1).join(" ");
                }
            } else {
                rawRest = args.slice(1).join(" ");
            }

            const delayMatch = rawRest.match(/sau\s+([\d]+\s*(?:giây|phút|giờ|ngày|s|m|h|d))/i);
            if (!delayMatch)
                return message.reply(
                    "<:warning:1487783235286073465> Dùng: `th!ai tag @user sau 5 phút <nội dung nhắc>` hoặc `th!ai tag tên sau 5 phút <nội dung>`"
                );
            const delay    = parseDelay(delayMatch[1]);
            const targetId = targetUser?.id || message.author.id;
            const afterDelay = rawRest.replace(delayMatch[0], "").trim();
            const tagMsg   = afterDelay || "Đây là nhắc nhở!";

            const tagId = scheduleTag(client, {
                userId:    targetId,
                channelId: message.channel.id,
                guildId:   message.guild?.id,
                ms:        delay.ms,
                tagMsg,
                label:     delay.label,
            });
            return message.reply(
                `<:time_left:1497103031123312771> Ok, t sẽ tag <@${targetId}>${targetUser && targetUser.id !== message.author.id ? ` (**${targetUser.username}**)` : ""} sau **${delay.label}** với nội dung: "${tagMsg}" — ID: \`${tagId}\``
            );
        }

        // ── th!ai remind <thời gian> <nội dung> ──────────────────
        if (sub === "remind" || sub === "nhắc") {
            const rawRest = args.slice(1).join(" ");
            const delay   = parseDelay(rawRest);
            if (!delay)
                return message.reply(
                    "<:warning:1487783235286073465> Dùng: `th!ai remind 10 phút đi uống nước`"
                );
            const afterTime = rawRest.replace(/^[\d]+\s*(?:giây|phút|giờ|ngày|s|m|h|d)/i, "").trim();
            const tagMsg    = afterTime || "Nhớ làm việc gì đó quan trọng rồi đó";

            const tagId = scheduleTag(client, {
                userId:    message.author.id,
                channelId: message.channel.id,
                guildId:   message.guild?.id,
                ms:        delay.ms,
                tagMsg,
                label:     delay.label,
            });
            return message.reply(
                `<:time_left:1497103031123312771> Nhắc **${delay.label}** sau: "${tagMsg}" — ID: \`${tagId}\``
            );
        }

        // ── th!ai canceltag <id> ──────────────────────────────────
        if (sub === "canceltag" || sub === "hủy") {
            const tagId = parseInt(args[1]);
            if (isNaN(tagId) || !scheduledTags.has(tagId))
                return message.reply("<:warning:1487783235286073465> ID nhắc không hợp lệ hoặc không tồn tại");
            const { timeout, label } = scheduledTags.get(tagId);
            clearTimeout(timeout);
            scheduledTags.delete(tagId);
            return message.reply(`<:enable:1487783260565143614> Đã hủy nhắc **${label}** (ID: \`${tagId}\`)`);
        }

        // ── th!ai savefile (reply hoặc attachment) ─────────────────
        if (sub === "savefile" || sub === "save") {
            const attachments = [...(message.attachments?.values() || [])];
            let attach        = attachments[0] || null;

            // Nếu không có attachment, check reply
            if (!attach && message.reference?.messageId) {
                try {
                    const refMsg = await message.channel.messages.fetch(message.reference.messageId);
                    attach = refMsg?.attachments?.first() || null;
                } catch {}
            }

            if (!attach)
                return message.reply("<:warning:1487783235286073465> Cần đính kèm file hoặc reply vào tin có file");

            try {
                const filename  = attach.name || `file_${Date.now()}`;
                const guildId   = message.guild?.id || "DM";
                const savedPath = await downloadFile(attach.url, filename, guildId);
                const rel       = path.relative(path.join(__dirname, "../.."), savedPath);
                return message.reply(
                    `<:enable:1487783260565143614> Đã lưu **${filename}** vào \`${rel}\``
                );
            } catch (err) {
                return message.reply(`<:disabled:1487783250452545616> Lưu file thất bại: ${err.message}`);
            }
        }

        // ── th!ai convert <format> ────────────────────────────────
        // Chuyển file đính kèm hoặc file trong reply sang format khác
        if (sub === "convert") {
            const outputFormat = args[1]?.toLowerCase();
            if (!outputFormat)
                return message.reply("<:warning:1487783235286073465> Dùng: `th!ai convert png` (kèm file đính kèm)");

            let attach = [...(message.attachments?.values() || [])][0] || null;
            if (!attach && message.reference?.messageId) {
                try {
                    const refMsg = await message.channel.messages.fetch(message.reference.messageId);
                    attach = refMsg?.attachments?.first() || null;
                } catch {}
            }
            if (!attach)
                return message.reply("<:warning:1487783235286073465> Cần đính kèm file hoặc reply vào tin có file");

            const guildId  = message.guild?.id || "DM";
            const filename = attach.name || `file_${Date.now()}`;

            try {
                const savedPath  = await downloadFile(attach.url, filename, guildId);
                const ct         = attach.contentType || "";
                const imgFormats = ["jpeg", "jpg", "png", "webp", "gif", "avif"];
                const txtFormats = ["json", "txt"];

                let outputPath;
                if (ct.startsWith("image/") && imgFormats.includes(outputFormat)) {
                    await message.channel.sendTyping().catch(() => {});
                    outputPath = await convertImage(savedPath, outputFormat);
                } else if (txtFormats.includes(outputFormat)) {
                    outputPath = convertTextFile(savedPath, outputFormat);
                } else {
                    return message.reply(`<:warning:1487783235286073465> Format \`${outputFormat}\` chưa được hỗ trợ cho file này`);
                }

                const outName   = path.basename(outputPath);
                const attachment = new AttachmentBuilder(outputPath, { name: outName });
                await message.reply({
                    content: `<:enable:1487783260565143614> Chuyển đổi xong! File: **${outName}**`,
                    files:   [attachment],
                });
            } catch (err) {
                return message.reply(`<:disabled:1487783250452545616> Chuyển đổi thất bại: ${err.message}`);
            }
            return;
        }

        // ── th!ai sendfile <@user|#kênh> [dm] ────────────────────
        // Gửi file cho @user qua DM, hoặc gửi vào #kênh chỉ định
        // Ví dụ: th!ai sendfile @user dm   → gửi DM
        //        th!ai sendfile @user       → gửi vào kênh hiện tại
        //        th!ai sendfile #kênh       → gửi vào kênh chỉ định
        if (sub === "sendfile") {
            const targetUser    = message.mentions.users.first();
            const targetChannel = message.mentions.channels.first();

            if (!targetUser && !targetChannel)
                return message.reply(
                    "<:warning:1487783235286073465> Dùng: `th!ai sendfile @user [dm]` hoặc `th!ai sendfile #kênh` (kèm file)\n" +
                    "• `dm` = gửi qua DM cho user\n" +
                    "• `#kênh` = gửi vào kênh chỉ định"
                );

            let attach = [...(message.attachments?.values() || [])][0] || null;
            if (!attach && message.reference?.messageId) {
                try {
                    const refMsg = await message.channel.messages.fetch(message.reference.messageId);
                    attach = refMsg?.attachments?.first() || null;
                } catch {}
            }
            if (!attach)
                return message.reply("<:warning:1487783235286073465> Cần đính kèm file hoặc reply vào tin có file");

            const viaDM    = args.includes("dm") || args.includes("ib");
            const guildId  = message.guild?.id || "DM";
            const filename = attach.name || `file_${Date.now()}`;
            const nick     = message.member?.nickname || message.author.username;

            try {
                const savedPath  = await downloadFile(attach.url, filename, guildId);
                const attachment = new AttachmentBuilder(savedPath, { name: filename });

                // Gửi vào kênh chỉ định (#kênh)
                if (targetChannel) {
                    await targetChannel.send({
                        content: `📁 File từ <@${message.author.id}>:`,
                        files:   [attachment],
                    });
                    return message.reply(`<:enable:1487783260565143614> Đã gửi file vào <#${targetChannel.id}>`);
                }

                // Gửi DM cho @user
                if (viaDM) {
                    await sendDM(client, targetUser, `*${nick} gửi file cho bạn qua Th07:*`, attachment);
                    return message.reply(`<:enable:1487783260565143614> Đã gửi file cho <@${targetUser.id}> qua DM`);
                }

                // Gửi tag @user trong kênh hiện tại
                await message.channel.send({
                    content: `<@${targetUser.id}> File từ <@${message.author.id}>:`,
                    files:   [attachment],
                });
                return message.reply(`<:enable:1487783260565143614> Đã gửi file cho <@${targetUser.id}> trong kênh này`);
            } catch (err) {
                return message.reply(`<:disabled:1487783250452545616> Gửi file thất bại: ${err.message}`);
            }
        }

        // ── th!ai makefile <tên.ext> <nội dung...> ───────────────
        // Hoặc th!ai makefile <tên.ext> (AI tự tạo nội dung từ query)
        // Ví dụ: th!ai makefile hello.py print("hello world")
        //        th!ai makefile config.json {"key": "value"}
        //        th!ai makefile readme.txt viết readme cho bot discord
        if (sub === "makefile" || sub === "createfile" || sub === "taofile") {
            const filename = args[1];
            if (!filename || !filename.includes("."))
                return message.reply(
                    "<:warning:1487783235286073465> Dùng: `th!ai makefile <tên.ext> <nội dung>`\n" +
                    "Ví dụ: `th!ai makefile test.txt zay dep trai`\n" +
                    "Hỗ trợ: `.txt .json .js .ts .py .java .yml .yaml .md .html .css .csv .xml .env .sh`"
                );

            const ALLOWED_EXTS = [".txt",".json",".js",".ts",".py",".java",".yml",".yaml",".md",".html",".css",".csv",".xml",".env",".sh",".bat",".rb",".go",".rs",".php",".sql",".kt",".swift",".c",".cpp",".h"];
            const ext = path.extname(filename).toLowerCase();
            if (!ALLOWED_EXTS.includes(ext))
                return message.reply(`<:warning:1487783235286073465> Định dạng \`${ext}\` chưa được hỗ trợ tạo file`);

            const rawContent = args.slice(2).join(" ").trim();
            const guildId    = message.guild?.id || "DM";
            const dir        = guildDownloadDir(guildId);
            const filePath   = path.join(dir, filename);

            let fileContent = rawContent;

            // Nếu không có nội dung → nhờ AI tạo
            if (!fileContent) {
                try {
                    await message.channel.sendTyping().catch(() => {});
                    const sysPrompt  = buildSystemPrompt(message.channel.id, message);
                    const aiGenPrompt = `Hãy tạo nội dung cho file \`${filename}\`. Chỉ trả về nội dung file thuần túy, không giải thích, không markdown fence (\`\`\`), không thêm gì khác.`;
                    fileContent = await callGemini({ systemInstruction: sysPrompt, history: [], userText: aiGenPrompt });
                    if (!fileContent) return message.reply("<:warning:1487783235286073465> AI không tạo được nội dung");
                } catch (err) {
                    return message.reply(`<:disabled:1487783250452545616> AI lỗi: ${err.message}`);
                }
            }

            try {
                fs.writeFileSync(filePath, fileContent, "utf8");
                const attachment = new AttachmentBuilder(filePath, { name: filename });
                return message.reply({
                    content: `<:enable:1487783260565143614> Đã tạo file **${filename}**`,
                    files:   [attachment],
                });
            } catch (err) {
                return message.reply(`<:disabled:1487783250452545616> Tạo file thất bại: ${err.message}`);
            }
        }

        // ── th!ai makefile-AI <tên.ext> <yêu cầu> ───────────────
        // AI tạo nội dung theo yêu cầu, có comment giải thích theo loại file
        // Ví dụ: th!ai makefile-AI bot.py bot online
        //        th!ai makefile-AI index.js express server cơ bản
        if (sub === "makefile-ai" || sub === "makefileai" || sub === "aifile") {
            const filename = args[1];
            if (!filename || !filename.includes("."))
                return message.reply(
                    "<:warning:1487783235286073465> Dùng: `th!ai makefile-AI <tên.ext> <yêu cầu>`\n" +
                    "Ví dụ: `th!ai makefile-AI bot.py bot online` hoặc `th!ai makefile-AI index.js express server`\n" +
                    "AI sẽ tạo nội dung đầy đủ có comment giải thích từng phần."
                );

            const ALLOWED_EXTS = [".txt",".json",".js",".ts",".py",".java",".yml",".yaml",".md",".html",".css",".csv",".xml",".env",".sh",".bat",".rb",".go",".rs",".php",".sql",".kt",".swift",".c",".cpp",".h"];
            const ext = path.extname(filename).toLowerCase();
            if (!ALLOWED_EXTS.includes(ext))
                return message.reply(`<:warning:1487783235286073465> Định dạng \`${ext}\` chưa được hỗ trợ.`);

            const userRequest = args.slice(2).join(" ").trim();
            if (!userRequest)
                return message.reply("<:warning:1487783235286073465> Cần nêu yêu cầu — ví dụ: `th!ai makefile-AI bot.py bot online`");

            const guildId  = message.guild?.id || "DM";
            const dir      = guildDownloadDir(guildId);
            const filePath = path.join(dir, filename);

            // ── Xác định ký hiệu comment theo loại file ──────────
            const pyLike   = [".py", ".rb", ".sh", ".bash", ".yml", ".yaml"];
            const jsLike   = [".js", ".ts", ".java", ".c", ".cpp", ".h", ".go", ".kt", ".swift", ".rs", ".php"];
            const sqlLike  = [".sql"];
            const htmlLike = [".html", ".xml"];
            const mdLike   = [".md"];
            const cssLike  = [".css"];

            let commentHint;
            if (pyLike.includes(ext))        commentHint = "Dùng ký hiệu # để viết comment giải thích từng khối code.";
            else if (jsLike.includes(ext))   commentHint = "Dùng ký hiệu // để viết comment giải thích từng khối code. Với khối lớn dùng /* ... */.";
            else if (sqlLike.includes(ext))  commentHint = "Dùng ký hiệu -- để viết comment giải thích từng câu query.";
            else if (htmlLike.includes(ext)) commentHint = "Dùng <!-- --> để viết comment giải thích từng section HTML.";
            else if (cssLike.includes(ext))  commentHint = "Dùng /* */ để viết comment giải thích từng block CSS.";
            else if (mdLike.includes(ext))   commentHint = "Dùng heading ## và **bold** để phân chia và giải thích các phần.";
            else                             commentHint = "Thêm comment giải thích ngắn gọn cho từng phần quan trọng.";

            try {
                await message.channel.sendTyping().catch(() => {});

                const aiPrompt =
                    `Tạo nội dung hoàn chỉnh cho file \`${filename}\` với yêu cầu: "${userRequest}".\n\n` +
                    `Quy tắc bắt buộc:\n` +
                    `1. Chỉ trả về nội dung file thuần túy — không có markdown fence (\`\`\`), không có giải thích bên ngoài file.\n` +
                    `2. ${commentHint}\n` +
                    `3. Mỗi hàm / khối logic quan trọng PHẢI có ít nhất 1 dòng comment ngắn giải thích mục đích.\n` +
                    `4. Đầu file thêm comment tóm tắt: tên file, mục đích, cách chạy (nếu có).\n` +
                    `5. Code phải chạy được ngay, đầy đủ, không placeholder kiểu "TODO" hay "your code here".`;

                const fileContent = await callGemini({ systemInstruction: null, history: [], userText: aiPrompt });
                if (!fileContent)
                    return message.reply("<:disabled:1487783250452545616> AI không tạo được nội dung cho file này.");

                // Xóa markdown fence nếu AI vẫn trả về dù đã nhắc
                const cleaned = fileContent
                    .replace(/^\s*\`\`\`[\w]*\n?/m, "")
                    .replace(/\n?\`\`\`\s*$/m, "")
                    .trim();

                fs.writeFileSync(filePath, cleaned, "utf8");
                const attachment = new AttachmentBuilder(filePath, { name: filename });
                const shortReq = userRequest.length > 5 ? userRequest.slice(0, 5) + "..." : userRequest;
                return message.reply({
                    content: `<:enable:1487783260565143614> AI đã tạo **${filename}** — _${shortReq}_`,
                    files:   [attachment],
                });
            } catch (err) {
                return message.reply(`<:disabled:1487783250452545616> Lỗi khi tạo file: ${err.message}`);
            }
        }

        // ── th!ai listdownloads ───────────────────────────────────
        if (sub === "listdownloads" || sub === "files") {
            const guildId = message.guild?.id;
            if (!guildId) return message.reply("Chỉ dùng được trong server");
            const dir = guildDownloadDir(guildId);
            const files = fs.readdirSync(dir);
            if (!files.length)
                return message.reply("<:letters_mail:1497103026404720661> Chưa có file nào được lưu");
            const list = files.map((f, i) => {
                const stat = fs.statSync(path.join(dir, f));
                const mb   = (stat.size / 1024 / 1024).toFixed(2);
                return `\`${i + 1}.\` **${f}** (${mb}MB)`;
            }).join("\n");
            const embed = makeEmbed(message.guild, null)
                .setTitle("<:gghim:1497108496414674974> File đã lưu của server")
                .setDescription(list.slice(0, 4000));
            return message.reply({ embeds: [embed] });
        }


        // ── th!ai setchannel / set ────────────────────────────────
        if (sub === "setchannel" || sub === "set") {
            if (!message.member.permissions.has("ManageChannels") && message.author.id !== OWNER_ID)
                return message.reply("<:disabled:1487783250452545616> Bạn cần quyền **Quản lý kênh** để dùng lệnh này.");
            const target = message.mentions.channels.first() || message.channel;
            await setChatbotChannel(client, message.guild.id, target.id);
            const embed = makeEmbed(message.guild)
                .setTitle("<:enable:1487783260565143614> Kênh chatbot AI đã được đặt!")
                .setDescription(
                    `Đã đặt <#${target.id}> làm **kênh chatbot AI**!\n` +
                    `Bot sẽ tự động trả lời **mọi tin nhắn** trong kênh đó.`
                );
            return message.reply({ embeds: [embed] });
        }

        // ── th!ai removechannel / remove / delchannel ─────────────
        if (sub === "removechannel" || sub === "remove" || sub === "delchannel") {
            if (!message.member.permissions.has("ManageChannels") && message.author.id !== OWNER_ID)
                return message.reply("<:disabled:1487783250452545616> Bạn cần quyền **Quản lý kênh** để dùng lệnh này.");
            await removeChatbotChannel(client, message.guild.id);
            const embed = makeEmbed(message.guild)
                .setTitle("<:enable:1487783260565143614> Kênh chatbot AI đã tắt")
                .setDescription("Đã **tắt** kênh chatbot AI. Bot sẽ không tự động trả lời nữa.");
            return message.reply({ embeds: [embed] });
        }

        // ── th!ai clearchat / clearchannel ───────────────────────
        if (sub === "clearchannel" || sub === "clearchat") {
            if (!message.member.permissions.has("Administrator") && message.author.id !== OWNER_ID)
                return message.reply("<:disabled:1487783250452545616> Bạn cần quyền **Administrator** để dùng lệnh này.");
            clearChannelHistory(message.guild.id, message.channel.id);
            const embed = makeEmbed(message.guild)
                .setTitle("<:barrel:1496519734722822245> Đã xóa lịch sử kênh")
                .setDescription("Đã xóa toàn bộ lịch sử chat AI của kênh này.");
            return message.reply({ embeds: [embed] });
        }

        // ── th!ai clearall / clearguild ───────────────────────────
        if (sub === "clearguild" || sub === "clearall") {
            if (message.author.id !== OWNER_ID && !message.member.permissions.has("Administrator"))
                return message.reply("<:disabled:1487783250452545616> Chỉ **Admin** mới có thể xóa toàn bộ lịch sử guild.");
            clearGuildHistory(message.guild.id);
            const embed = makeEmbed(message.guild)
                .setTitle("<:barrel:1496519734722822245> Đã xóa lịch sử toàn server")
                .setDescription("Đã xóa toàn bộ lịch sử chat AI của **toàn server**.");
            return message.reply({ embeds: [embed] });
        }

        // ── th!ai info / status ───────────────────────────────────
        if (sub === "info" || sub === "status") {
            const chId      = await getChatbotChannel(client, message.guild.id);
            loadGuildHistory(message.guild.id);
            const guildData  = guildHistories[message.guild.id] || {};
            const totalMsgs  = Object.values(guildData).reduce((s, arr) => s + arr.length, 0);
            const totalChans = Object.keys(guildData).length;
            const chanLog    = getChannelLog(message.guild.id, message.channel.id);
            const msgStats   = getMsgStats(message.guild.id);
            const pendingTagsList = [...scheduledTags.values()]
                .filter(t => t.guildId === message.guild.id);

            const embed = makeEmbed(message.guild)
                .setTitle("<:robot:1497103028560461895> Trạng thái AI")
                .addFields(
                    { name: "📡 Kênh chatbot AI",              value: chId ? `<#${chId}>` : "<:disabled:1487783250452545616> Chưa đặt", inline: true },
                    { name: "<:ram:1496519742628827307> Bộ nhớ AI guild", value: `**${totalMsgs}** tin / **${totalChans}** kênh`, inline: true },
                    { name: "<:chat:1496519744910528573> Kênh hiện tại", value: `**${chanLog.length}** tin`, inline: true },
                    { name: "<:record:1497103035200045076> Message Logger",  value: `**${msgStats.totalMessages}** tin / **${msgStats.totalChannels}** kênh`, inline: true },
                    { name: "<:time_left:1497103031123312771> Tag hẹn giờ đang chạy", value: pendingTagsList.length > 0
                        ? pendingTagsList.map(t => `• <@${t.userId}> sau **${t.label}**`).join("\n")
                        : "Không có", inline: false },
                );
            return message.reply({ embeds: [embed] });
        }

        // ── th!ai log [số] ────────────────────────────────────────
        if (sub === "log") {
            const limit = Math.min(parseInt(args[1]) || 10, 30);
            const gId   = message.guild.id;
            const cId   = message.channel.id;

            // Ưu tiên msg logger (toàn bộ tin nhắn trong kênh)
            loadMsgGuild(gId);
            let logs = getRecentMessages(gId, cId, limit);

            // Fallback: nếu msg logger chưa có → đọc từ AI chat history
            if (!logs.length) {
                loadGuildHistory(gId);
                const aiHistory = (guildHistories[gId]?.[cId] || []).slice(-limit);
                if (aiHistory.length) {
                    const lines = aiHistory.map(e =>
                        `[${e.timestamp.slice(11, 19)}] **${e.user?.name || "?"}**: ${(e.userMessage || "").slice(0, 80)}\n` +
                        `↳ **Bot**: ${(e.botReply || "").slice(0, 80)}`
                    ).join("\n");
                    const embed = makeEmbed(message.guild)
                        .setTitle(`<:record:1497103035200045076> ${aiHistory.length} lượt chat AI gần nhất`)
                        .setDescription(lines.slice(0, 4000));
                    return message.reply({ embeds: [embed] });
                }
                return message.reply("<:letters_mail:1497103026404720661> Chưa có tin nhắn nào được log trong kênh này.");
            }

            const lines = logs.map(e =>
                `[${e.timestamp.slice(11, 19)}] **${e.author.username}**${e.author.isBot ? " <:robot:1497103028560461895>" : ""}: ${(e.content || "[embed/file]").slice(0, 80)}`
            ).join("\n");
            const embed = makeEmbed(message.guild)
                .setTitle(`<:record:1497103035200045076> ${logs.length} tin nhắn gần nhất`)
                .setDescription(lines.slice(0, 4000));
            return message.reply({ embeds: [embed] });
        }


        // ── Không có sub → help menu Components V2 ───────────────
        const realQuery = args?.join(" ").trim();
        if (!realQuery) {
            const botAvatar = client.user.displayAvatarURL({ extension: "png", size: 256 });
            const sep  = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
            const thin = () => new SeparatorBuilder().setDivider(false).setSpacing(SeparatorSpacingSize.Small);

            const container = new ContainerBuilder().setAccentColor(EMBED_COLOR);

            // ── Header: avatar bot bên phải, text bên trái ────────
            // ── Header: title + thumbnail ─────────────────────────
            container.addSectionComponents(
                new SectionBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `# <:ask:1496519737096798372> ${client.user.username} — AI\n` +
                            `-# Prefix: \`th!\`  •  alias: \`ask\` · \`chat\` · \`hoi\` · \`alo\`\n` +
                            `-# Model: **gemini-2.5-flash**  •  Tác giả: <@${OWNER_ID}>`
                        )
                    )
                    .setThumbnailAccessory(
                        new ThumbnailBuilder().setURL(botAvatar)
                    )
            );

            container.addSeparatorComponents(sep());

            // ── 💬 Chat AI ────────────────────────────────────────
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `**💬 Chat AI**\n` +
                `\`th!ai <câu hỏi>\` — Hỏi AI trực tiếp\n` +
                `\`th!ai ask <câu hỏi>\` — Alias hỏi AI\n` +
                `-# 📎 Đính kèm ảnh · video · file để AI phân tích`
            ));

            container.addSeparatorComponents(thin());

            // ── 📁 File & Convert ─────────────────────────────────
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `**📁 File & Convert**\n` +
                `\`th!ai makefile <tên.ext> [nội dung]\` — Tạo & upload file\n` +
                `\`th!ai makefile-AI <tên.ext> <yêu cầu>\` — AI tự viết nội dung rồi tạo file\n` +
                `\`th!ai save\` — Lưu file đính kèm xuống server\n` +
                `\`th!ai convert <format>\` — Chuyển định dạng (png/jpg/json/txt...)\n` +
                `\`th!ai sendfile @user [dm]\` — Gửi file cho @user / qua DM\n` +
                `\`th!ai sendfile #kênh\` — Gửi file vào kênh chỉ định\n` +
                `\`th!ai files\` — Xem danh sách file đã lưu`
            ));

            container.addSeparatorComponents(thin());

            // ── 📩 DM / IB ───────────────────────────────────────
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `**📩 Gửi DM / IB**\n` +
                `\`th!ai dm @user <nội dung>\` — Gửi DM cho user\n` +
                `\`th!ai ib @user <nội dung>\` — Alias của dm`
            ));

            container.addSeparatorComponents(thin());

            // ── ⏰ Tag / Nhắc hẹn giờ ────────────────────────────
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `**⏰ Tag / Nhắc hẹn giờ**\n` +
                `\`th!ai remind 10 phút <nội dung>\` — Nhắc bản thân\n` +
                `\`th!ai tag @user sau 5 phút <nd>\` — Tag người khác\n` +
                `\`th!ai canceltag <id>\` — Hủy nhắc\n` +
                `-# Đơn vị: giây · phút · giờ · ngày`
            ));

            container.addSeparatorComponents(thin());

            // ── 🤖 Chatbot ────────────────────────────────────────
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `**🤖 Kênh Chatbot AI**\n` +
                `\`th!ai setchannel [#kênh]\` — Đặt kênh chatbot\n` +
                `\`th!ai removechannel\` — Tắt kênh chatbot`
            ));

            container.addSeparatorComponents(thin());

            // ── 🧹 Xóa lịch sử ───────────────────────────────────
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `**🧹 Xóa lịch sử**\n` +
                `\`th!ai clearchat\` — Xóa lịch sử kênh hiện tại *(Admin)*\n` +
                `\`th!ai clearall\` — Xóa toàn server *(Admin)*`
            ));

            container.addSeparatorComponents(thin());

            // ── 📋 Log & Thống kê ─────────────────────────────────
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `**📋 Log & Thống kê**\n` +
                `\`th!ai log [số]\` — Xem tin nhắn gần nhất\n` +
                `\`th!ai info\` — Trạng thái bot & bộ nhớ`
            ));


            // ── Footer ────────────────────────────────────────────
            container.addSeparatorComponents(sep());
            container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                `-# <:idea:1492084965494751313> Gõ \`th!ai <câu hỏi>\` để bắt đầu ngay!  •  <:robot:1497103028560461895> Th07 AI`
            ));

            return message.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        await _processAI(client, message, realQuery, true);
    },
};


// ═══════════════════════════════════════════════════════════════════
//  MODULE EXPORTS
// ═══════════════════════════════════════════════════════════════════

module.exports = {
    ...aiCommand,
};
