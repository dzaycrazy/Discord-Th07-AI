const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} = require("discord.js");

module.exports = {
  name: "purge",
  aliases: ["clear"],
  description: "Xóa hàng loạt tin nhắn trong một kênh",
  category: "moderation",
  cooldown: 3,
  run: async (client, message, args) => {
    const color = client.color || "#5865F2";
    const emoji = client.emoji || { cross: "<:cross:1488403197893541898>", tick: "<:Tick:1488402363394818170>" };

    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages))
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(`${emoji.cross} | Bạn cần quyền **Quản lý Tin nhắn**.`),
        ],
      });

    if (
      !message.guild.members.me.permissions.has([
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ])
    )
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(
              `${emoji.cross} | Tôi cần quyền **Quản lý Tin nhắn** và **Đọc Lịch sử Tin nhắn**.`
            ),
        ],
      });

    const type = args[0]?.toLowerCase();
    const input = args.slice(1).join(" ");
    const amountArg = parseInt(args.find((a) => /^\d+$/.test(a))) || null;

    if (!type)
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(
              [
                "### <:cleaner:1488410427531591790> **Cách dùng Lệnh dọn dẹp**",
                "`purge <số_lượng>` — Xóa N tin nhắn gần nhất ngay lập tức",
                "`purge user @người_dùng [số_lượng]` — Xóa tin nhắn của một người dùng (hỏi xác nhận nếu không có số lượng)",
                "`purge attachments [số_lượng]` — Xóa tin nhắn có tệp đính kèm (hỏi xác nhận nếu không có số lượng)",
                "`purge contains <từ_khóa>` — Xóa tất cả tin nhắn chứa một từ (tối đa 100)",
              ].join("\n")
            ),
        ],
      });

    const fetchLimit = 100;
    const messages = await message.channel.messages.fetch({ limit: fetchLimit });
    let filtered = [];

    if (/^\d+$/.test(type)) {
      const amount = Math.min(parseInt(type) + 1, 100);
      const deleted = await message.channel.bulkDelete(amount, true).catch(() => null);
      const actualDeleted = deleted ? deleted.size - 1 : 0;
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(
              deleted
                ? `${emoji.tick} | Đã xóa **${actualDeleted}** tin nhắn.`
                : `${emoji.cross} | Không thể xóa tin nhắn.`
            ),
        ],
      }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 3000));
    }

    switch (type) {
      case "user": {
        const user =
          message.mentions.users.first() ||
          (input ? await client.users.fetch(input).catch(() => null) : null);
        if (!user)
          return message.reply({
            embeds: [
              new EmbedBuilder()
                .setColor(color)
                .setDescription(`${emoji.cross} | Đề cập hoặc chỉ định một người dùng hợp lệ.`),
            ],
          });

        const amount = Math.min(amountArg || 10, 100);
        filtered = messages.filter((m) => m.author.id === user.id).first(amount);

        if (!filtered.length)
          return message.reply({
            embeds: [
              new EmbedBuilder()
                .setColor(color)
                .setDescription(`${emoji.cross} | Không tìm thấy tin nhắn gần đây nào từ người dùng đó.`),
            ],
          });

        if (!amountArg) {
          const confirmEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle("⚠️ Xác nhận Xóa")
            .setDescription(
              `Xóa **${filtered.length}** tin nhắn gần nhất từ **${user.tag}**?`
            );

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("confirm_purge")
              .setLabel("✅ Xác nhận")
              .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
              .setCustomId("cancel_purge")
              .setLabel("❌ Hủy")
              .setStyle(ButtonStyle.Danger)
          );

          const msg = await message.reply({ embeds: [confirmEmbed], components: [row] });
          const collector = msg.createMessageComponentCollector({
            filter: (i) => i.user.id === message.author.id,
            time: 15000,
          });

          collector.on("collect", async (i) => {
            await i.deferUpdate();
            if (i.customId === "cancel_purge") {
              collector.stop("cancelled");
              return msg.edit({
                embeds: [
                  new EmbedBuilder()
                    .setColor(color)
                    .setDescription(`${emoji.cross} | Đã hủy.`),
                ],
                components: [],
              });
            }

            if (i.customId === "confirm_purge") {
              const deleted = await message.channel.bulkDelete(filtered, true).catch(() => null);
              collector.stop("confirmed");
              return msg.edit({
                embeds: [
                  new EmbedBuilder()
                    .setColor(color)
                    .setDescription(
                      deleted
                        ? `${emoji.tick} | Đã xóa **${deleted.size}** tin nhắn từ ${user.tag}.`
                        : `${emoji.cross} | Không thể xóa tin nhắn.`
                    ),
                ],
                components: [],
              });
            }
          });

          collector.on("end", async (_, reason) => {
            if (reason !== "confirmed" && reason !== "cancelled")
              await msg.edit({
                embeds: [
                  new EmbedBuilder()
                    .setColor(color)
                    .setDescription(`${emoji.cross} | Hết thời gian chờ xóa.`),
                ],
                components: [],
              });
          });
          return;
        }

        const deleted = await message.channel.bulkDelete(filtered, true).catch(() => null);
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(color)
              .setDescription(
                deleted
                  ? `${emoji.tick} | Đã xóa **${deleted.size}** tin nhắn từ ${user.tag}.`
                  : `${emoji.cross} | Không thể xóa tin nhắn.`
              ),
          ],
        });
      }

      case "attachments": {
        const amount = Math.min(amountArg || 10, 100);
        filtered = messages.filter((m) => m.attachments.size > 0).first(amount);

        if (!filtered.length)
          return message.reply({
            embeds: [
              new EmbedBuilder()
                .setColor(color)
                .setDescription(`${emoji.cross} | Không tìm thấy tin nhắn đính kèm gần đây nào.`),
            ],
          });

        if (!amountArg) {
          const confirmEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle("⚠️ Xác nhận Xóa")
            .setDescription(`Xóa **${filtered.length}** tin nhắn gần nhất có tệp đính kèm?`);

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("confirm_purge")
              .setLabel("✅ Xác nhận")
              .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
              .setCustomId("cancel_purge")
              .setLabel("❌ Hủy")
              .setStyle(ButtonStyle.Danger)
          );

          const msg = await message.reply({ embeds: [confirmEmbed], components: [row] });
          const collector = msg.createMessageComponentCollector({
            filter: (i) => i.user.id === message.author.id,
            time: 15000,
          });

          collector.on("collect", async (i) => {
            await i.deferUpdate();
            if (i.customId === "cancel_purge") {
              collector.stop("cancelled");
              return msg.edit({
                embeds: [
                  new EmbedBuilder()
                    .setColor(color)
                    .setDescription(`${emoji.cross} | Đã hủy.`),
                ],
                components: [],
              });
            }

            if (i.customId === "confirm_purge") {
              const deleted = await message.channel.bulkDelete(filtered, true).catch(() => null);
              collector.stop("confirmed");
              return msg.edit({
                embeds: [
                  new EmbedBuilder()
                    .setColor(color)
                    .setDescription(
                      deleted
                        ? `${emoji.tick} | Đã xóa **${deleted.size}** tin nhắn có tệp đính kèm.`
                        : `${emoji.cross} | Không thể xóa tin nhắn.`
                    ),
                ],
                components: [],
              });
            }
          });

          collector.on("end", async (_, reason) => {
            if (reason !== "confirmed" && reason !== "cancelled")
              await msg.edit({
                embeds: [
                  new EmbedBuilder()
                    .setColor(color)
                    .setDescription(`${emoji.cross} | Hết thời gian chờ xóa.`),
                ],
                components: [],
              });
          });
          return;
        }

        const deleted = await message.channel.bulkDelete(filtered, true).catch(() => null);
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(color)
              .setDescription(
                deleted
                  ? `${emoji.tick} | Đã xóa **${deleted.size}** tin nhắn có tệp đính kèm.`
                  : `${emoji.cross} | Không thể xóa tin nhắn.`
              ),
          ],
        });
      }

      case "contains": {
        const keyword = input || args[1];
        if (!keyword)
          return message.reply({
            embeds: [
              new EmbedBuilder()
                .setColor(color)
                .setDescription(`${emoji.cross} | Cung cấp một từ khóa để tìm kiếm.`),
            ],
          });

        filtered = messages.filter((m) =>
          m.content.toLowerCase().includes(keyword.toLowerCase())
        );

        if (!filtered.size)
          return message.reply({
            embeds: [
              new EmbedBuilder()
                .setColor(color)
                .setDescription(`${emoji.cross} | Không tìm thấy tin nhắn nào chứa "${keyword}".`),
            ],
          });

        const deleted = await message.channel.bulkDelete(filtered, true).catch(() => null);
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(color)
              .setDescription(
                deleted
                  ? `${emoji.tick} | Đã xóa **${deleted.size}** tin nhắn chứa "${keyword}".`
                  : `${emoji.cross} | Không thể xóa tin nhắn.`
              ),
          ],
        });
      }

      default:
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(color)
              .setDescription(`${emoji.cross} | Loại xóa không hợp lệ.`),
          ],
        });
    }
  },
};
