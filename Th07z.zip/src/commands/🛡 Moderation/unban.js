const { PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require("discord.js");

module.exports = {
    name: "unban",
    aliases: [],
    description: "Bỏ cấm một người dùng khỏi máy chủ",
    category: "moderation",
    cooldown: 3,
    run: async (client, message, args, prefix) => {

        const errorContainer = (text) => {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không có quyền **`BAN_MEMBERS`** cần thiết để thực hiện lệnh này."));
        }

        const input = args[0]?.replace(/[<@!>]/g, "");
        const reason = args.slice(1).join(" ") || "Không có lý do.";

        if (!input) {
            return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | **Sử dụng sai** — \`${prefix}unban @người_dùng/tên_người_dùng/ID [lý_do]\``));
        }

        const banList = await message.guild.bans.fetch().catch(() => null);

        if (!banList) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Không thể lấy danh sách cấm. Vui lòng kiểm tra quyền của tôi."));
        }

        let banEntry = banList.get(input)
            || banList.find(b =>
                b.user.username.toLowerCase() === input.toLowerCase() ||
                b.user.tag?.toLowerCase() === input.toLowerCase()
            );

        if (!banEntry) {
            const fetchedUser = await client.users.fetch(input).catch(() => null);
            if (fetchedUser) {
                banEntry = banList.get(fetchedUser.id);
            }
        }

        if (!banEntry) {
            return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | Không tìm thấy người dùng bị cấm nào khớp với **${input}**.`));
        }

        const user = banEntry.user;

        await message.guild.members.unban(user.id, `${reason} | Đã bỏ cấm bởi ${message.author.tag}`);

        const successContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`<:enable:1487783260565143614> | **[${user.username}](http://discord.com/users/${user.id})** [\`${user.id}\`] đã được bỏ cấm khỏi máy chủ.\n**Lý do:** ${reason}`)
            );

        await message.channel.send({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });

        const dmContainer = new ContainerBuilder()
            .addTextDisplayComponents(new TextDisplayBuilder().setContent("### <:enable:1487783260565143614> Bạn Đã Được Bỏ Cấm"))
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Máy chủ » ** ${message.guild.name}\n` +
                    `**Người điều hành » ** [${message.author.username}](http://discord.com/users/${message.author.id})\n` +
                    `**<:lydo:1489896447099801642> » ** ${reason}`
                )
            );

        try {
            await user.send({ components: [dmContainer], flags: MessageFlags.IsComponentsV2 });
        } catch (err) {}
    }
};
