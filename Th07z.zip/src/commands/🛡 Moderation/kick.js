const { PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require("discord.js");

module.exports = {
    name: "kick",
    aliases: [],
    description: "Kick một thành viên khỏi máy chủ",
    category: "kiểm duyệt",
    cooldown: 3,
    run: async (client, message, args, prefix) => {

        const errorContainer = (text) => {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không có quyền **`KICK_MEMBERS`** cần thiết để thực hiện lệnh này."));
        }

        const input = args[0]?.replace(/[<@!>]/g, "");
        const reason = args.slice(1).join(" ") || "Không có lý do nào được cung cấp.";

        if (!input) {
            return message.channel.send(errorContainer(`<:cross:1488403197893541898> | **Sử dụng sai** — \`${prefix}kick @người_dùng/tên_người_dùng/ID [lý_do]\``));
        }

        let member = message.guild.members.cache.get(input)
            || message.guild.members.cache.find(m =>
                m.user.username.toLowerCase() === input.toLowerCase() ||
                m.user.tag?.toLowerCase() === input.toLowerCase() ||
                m.displayName.toLowerCase() === input.toLowerCase()
            );

        let user = member?.user || await client.users.fetch(input).catch(() => null);

        if (!user) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Không tìm thấy người dùng nào với thông tin nhập đó. Hãy thử sử dụng ID, tên người dùng hoặc nhắc đến họ."));
        }

        if (!member) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Người dùng đó không phải là thành viên của máy chủ này."));
        }

        if (user.id === message.author.id) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không thể tự kick mình."));
        }

        if (user.id === client.user.id) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Tôi không thể bị kick."));
        }

        if (message.author.id !== message.guild.ownerId) {
            if (member.id === message.guild.ownerId) {
                return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không thể kick chủ sở hữu máy chủ."));
            }

            if (message.member.roles.highest.position <= member.roles.highest.position) {
                return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | Bạn không thể kick **${user.username}** — vai trò cao nhất của họ bằng hoặc cao hơn của bạn.`));
            }
        }

        if (!member.kickable) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Tôi không thể kick thành viên này. Vai trò cao nhất của họ bằng hoặc cao hơn của tôi."));
        }

        const dmContainer = new ContainerBuilder()
            .addTextDisplayComponents(new TextDisplayBuilder().setContent("### <:anti:1487786661143384065> Bạn Đã Bị Kick"))
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Máy chủ » ** ${message.guild.name}\n` +
                    `**Người kiểm duyệt » ** [${message.author.username}](http://discord.com/users/${message.author.id})\n` +
                    `**<:lydo:1489896447099801642> » ** ${reason}`
                )
            );

        try {
            await user.send({ components: [dmContainer], flags: MessageFlags.IsComponentsV2 });
        } catch (err) {}

        await member.kick(`${reason} | Bị kick bởi ${message.author.tag}`);

        const successContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`<:Tick:1488402363394818170> | **[${user.username}](http://discord.com/users/${user.id})** [\`${user.id}\`] đã bị kick khỏi máy chủ.\n**<:lydo:1489896447099801642> » ** ${reason}`)
            );

        await message.channel.send({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
    }
};
