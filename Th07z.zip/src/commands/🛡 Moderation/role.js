const { 
    EmbedBuilder, 
    PermissionFlagsBits, 
    SlashCommandBuilder,
    ApplicationCommandOptionType 
} = require("discord.js");

module.exports = {
    name: "role",
    aliases: ["giverole", "addrole"],
    description: "Gán một quyền cho người dùng",
    category: "moderation",
    cooldown: 3,
    slashCommand: new SlashCommandBuilder()
        .setName("role")
        .setDescription("Quản lý quyền của người dùng")
        .addSubcommand(sub =>
            sub.setName("add")
                .setDescription("Thêm một quyền cho người dùng")
                .addUserOption(opt => 
                    opt.setName("user")
                        .setDescription("Người dùng để thêm quyền")
                        .setRequired(true))
                .addRoleOption(opt =>
                    opt.setName("role")
                        .setDescription("Quyền cần thêm")
                        .setRequired(true)))
        .addSubcommand(sub =>
            sub.setName("remove")
                .setDescription("Xóa một quyền khỏi người dùng")
                .addUserOption(opt =>
                    opt.setName("user")
                        .setDescription("Người dùng để xóa quyền khỏi")
                        .setRequired(true))
                .addRoleOption(opt =>
                    opt.setName("role")
                        .setDescription("Quyền cần xóa")
                        .setRequired(true))),

    run: async (client, message, args, prefix) => {
        const bypassUserId = "1187321862724800562";
        const hasPermission = message.member.permissions.has(PermissionFlagsBits.Administrator) || message.author.id === bypassUserId;

        if (!hasPermission) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn cần quyền QUẢN TRỊ VIÊN để sử dụng lệnh này.`)
                ]
            });
        }

        if (args.length < 2) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Cách dùng lệnh: \`${prefix}role <người_dùng> <quyền>\``)
                ]
            });
        }

        let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        if (!role) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng cung cấp một quyền hợp lệ.`)
                ]
            });
        }
        if (!user) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng cung cấp một người dùng hợp lệ.`)
                ]
            });
        }

        if (
            message.member.roles.highest.position <= user.roles.highest.position &&
            message.author.id !== message.guild.ownerId &&
            message.author.id !== bypassUserId
        ) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn không thể thay đổi quyền cho người dùng có quyền cao hơn hoặc bằng quyền của bạn.`)
                ]
            });
        }

        if (role.position >= message.guild.members.me.roles.highest.position) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Tôi không thể gán một quyền cao hơn hoặc bằng quyền cao nhất của tôi.`)
                ]
            });
        }

        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Tôi không có quyền quản lý quyền.`)
                ]
            });
        }

        const reason = `${message.author.tag} đã gán quyền ${role.name} cho ${user.user.tag}`;

        try {
            await user.roles.add(role, reason);
            await message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#00FF7F')
                        .setDescription(`${client.emoji.tick} | Đã gán thành công quyền **${role.name}** cho ${user.user.tag}.`)
                ]
            });
        } catch (err) {
            console.error('Error assigning role:', err);
            await message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF4B4B')
                        .setDescription(`${client.emoji.cross} | Tôi không thể gán quyền đó. Vui lòng kiểm tra vị trí quyền và các quyền của tôi.`)
                ]
            });
        }
    },

    runSlash: async (client, interaction) => {
        const bypassUserId = "1187321862724800562";
        const hasPermission = interaction.member.permissions.has(PermissionFlagsBits.Administrator) || interaction.user.id === bypassUserId;

        if (!hasPermission) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn cần quyền QUẢN TRỊ VIÊN để sử dụng lệnh này.`)
                ],
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();
        const user = interaction.options.getMember("user");
        const role = interaction.options.getRole("role");

        if (!user) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Không tìm thấy người dùng này trong máy chủ.`)
                ],
                ephemeral: true
            });
        }

        if (
            interaction.member.roles.highest.position <= user.roles.highest.position &&
            interaction.user.id !== interaction.guild.ownerId &&
            interaction.user.id !== bypassUserId
        ) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn không thể thay đổi quyền cho người dùng có quyền cao hơn hoặc bằng quyền của bạn.`)
                ],
                ephemeral: true
            });
        }

        if (role.position >= interaction.guild.members.me.roles.highest.position) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Tôi không thể quản lý một quyền cao hơn hoặc bằng quyền cao nhất của tôi.`)
                ],
                ephemeral: true
            });
        }

        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Tôi không có quyền quản lý quyền.`)
                ],
                ephemeral: true
            });
        }

        try {
            if (subcommand === "add") {
                const reason = `${interaction.user.tag} đã gán quyền ${role.name} cho ${user.user.tag}`;
                await user.roles.add(role, reason);
                await interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#00FF7F')
                            .setDescription(`${client.emoji.tick} | Đã gán thành công **${role.name}** cho ${user.user.tag}.`)
                    ]
                });
            } else if (subcommand === "remove") {
                const reason = `${interaction.user.tag} đã xóa quyền ${role.name} khỏi ${user.user.tag}`;
                await user.roles.remove(role, reason);
                await interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#00FF7F')
                            .setDescription(`${client.emoji.tick} | Đã xóa thành công **${role.name}** khỏi ${user.user.tag}.`)
                    ]
                });
            }
        } catch (err) {
            console.error('Error managing role:', err);
            await interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF4B4B')
                        .setDescription(`${client.emoji.cross} | Tôi không thể quản lý quyền đó. Vui lòng kiểm tra vị trí quyền và các quyền của tôi.`)
                ],
                ephemeral: true
            });
        }
    }
};
