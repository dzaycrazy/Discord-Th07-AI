const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
    name: "lock",
    aliases: [],
    description: "Khóa một kênh để ngăn @everyone gửi tin nhắn",
    category: "kiểm duyệt",
    cooldown: 3,
    run: async (client, message, args) => {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn cần quyền \`Quản lý Kênh\` để sử dụng lệnh này.`)]
            });
        }

        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Tôi cần quyền \`Quản lý Kênh\` để khóa kênh.`)]
            });
        }

        const channel = message.mentions.channels.first() || message.channel;

        try {
            await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: false
            });

            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Đã khóa ${channel} thành công.`)]
            });
        } catch (error) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Không thể khóa kênh.`)]
            });
        }
    }
};
