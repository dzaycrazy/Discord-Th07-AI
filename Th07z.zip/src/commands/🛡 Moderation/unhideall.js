const { EmbedBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");

module.exports = {
    name: "unhideall",
    aliases: [],
    description: "Bỏ ẩn tất cả các kênh văn bản cho @everyone",
    category: "moderation",
    cooldown: 10,
    run: async (client, message, args) => {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn cần quyền \`Administrator\` để sử dụng lệnh này.`)]
            });
        }

        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Tôi cần quyền \`Manage Channels\` để bỏ ẩn các kênh.`)]
            });
        }

        const loadingMsg = await message.channel.send({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`<:loading:1488406665467531294> Đang bỏ ẩn tất cả các kênh...`)]
        });

        const channels = message.guild.channels.cache.filter(
            c => c.type === ChannelType.GuildText || c.type === ChannelType.GuildVoice
        );

        let success = 0;
        let failed = 0;

        for (const [, channel] of channels) {
            try {
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    ViewChannel: null
                });
                success++;
            } catch {
                failed++;
            }
        }

        return loadingMsg.edit({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`${client.emoji.tick} | Đã bỏ ẩn **${success}** kênh. Thất bại: **${failed}**`)]
        });
    }
};
