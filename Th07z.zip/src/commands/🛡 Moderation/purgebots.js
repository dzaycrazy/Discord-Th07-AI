const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "purgebots",
  aliases: ["pb"],
  category: "mod",
  cat: "admin",

  run: async (client, message) => {
    const color = client.color || "#5865F2";
    const emoji = client.emoji || { tick: "<:Tick:1488402363394818170>", cross: "<:cross:1488403197893541898>" };

    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages))
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(`${emoji.cross} | Bạn cần quyền **Quản lý Tin nhắn**.`),
        ],
      });

    if (
      !message.guild.members.me.permissions.has([
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ])
    )
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(
              `${emoji.cross} | Tôi cần quyền **Quản lý Tin nhắn** và **Đọc Lịch sử Tin nhắn**.`
            ),
        ],
      });

    const messages = await message.channel.messages.fetch({ limit: 100 });
    const botMessages = messages.filter((m) => m.author.bot);

    if (!botMessages.size)
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(`${emoji.cross} | Không tìm thấy tin nhắn bot nào để xóa.`),
        ],
      });

    const deleted = await message.channel.bulkDelete(botMessages, true).catch(() => null);
    if (!deleted || !deleted.size)
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(`${emoji.cross} | Không thể xóa tin nhắn bot.`),
        ],
      });

    const msg = await message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(color)
          .setDescription(`${emoji.tick} | Đã xóa **${deleted.size}** tin nhắn bot.`),
      ],
    });

    setTimeout(() => msg.delete().catch(() => {}), 3000);
  },
};
