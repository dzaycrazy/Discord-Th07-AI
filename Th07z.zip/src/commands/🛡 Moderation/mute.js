const { PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require("discord.js");
const ms = require("ms");

module.exports = {
    name: "timeout",
    aliases: ["mute"],
    description: "Tạm thời cấm một thành viên trong một khoảng thời gian cụ thể",
    category: "kiểm duyệt",
    cooldown: 3,
    run: async (client, message, args, prefix) => {

        const errorContainer = (text) => {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không có quyền **`MODERATE_MEMBERS`** cần thiết để thực hiện lệnh này."));
        }

        const input = args[0]?.replace(/[<@!>]/g, "");
        const duration = args[1];
        const reason = args.slice(2).join(" ") || "Không có lý do được cung cấp.";

        if (!input) {
            return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | **Sử dụng sai** — \`${prefix}mute @người_dùng/tên_người_dùng/ID [thời_lượng] [lý_do]\`\n> Thời lượng mặc định là **2 giờ** nếu không được chỉ định.`));
        }

        let member = message.guild.members.cache.get(input)
            || message.guild.members.cache.find(m =>
                m.user.username.toLowerCase() === input.toLowerCase() ||
                m.user.tag?.toLowerCase() === input.toLowerCase() ||
                m.displayName.toLowerCase() === input.toLowerCase()
            );

        let user = member?.user || await client.users.fetch(input).catch(() => null);

        if (!user) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Không tìm thấy người dùng nào với thông tin đã nhập. Hãy thử sử dụng ID, tên người dùng hoặc nhắc đến họ."));
        }

        if (!member) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Người dùng đó không phải là thành viên của máy chủ này."));
        }

        if (user.id === message.author.id) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không thể tự cấm mình."));
        }

        if (user.id === client.user.id) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Tôi không thể bị cấm."));
        }

        if (member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | Không thể cấm **${user.username}** — họ có quyền **Quản trị viên**.`));
        }

        if (message.author.id !== message.guild.ownerId) {
            if (member.id === message.guild.ownerId) {
                return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không thể cấm chủ sở hữu máy chủ."));
            }

            if (message.member.roles.highest.position <= member.roles.highest.position) {
                return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | Bạn không thể cấm **${user.username}** — vai trò cao nhất của họ bằng hoặc cao hơn của bạn.`));
            }
        }

        if (!member.moderatable) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Tôi không thể cấm thành viên này. Vai trò cao nhất của họ bằng hoặc cao hơn của tôi."));
        }

        const durationMs = duration ? ms(duration) : ms("2h");

        if (!durationMs || durationMs > 2419200000) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Vui lòng cung cấp thời lượng hợp lệ không quá **28 ngày** (ví dụ: `10m`, `1h`, `7d`)."));
        }

        const dmContainer = new ContainerBuilder()
            .addTextDisplayComponents(new TextDisplayBuilder().setContent("### 🔇 Bạn Đã Bị Cấm"))
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Máy chủ » ** ${message.guild.name}\n` +
                    `**Người kiểm duyệt » ** [${message.author.username}](http://discord.com/users/${message.author.id})\n` +
                    `**Thời lượng » ** ${ms(durationMs, { long: true })}\n` +
                    `**<:lydo:1489896447099801642> » ** ${reason}`
                )
            );

        try {
            await user.send({ components: [dmContainer], flags: MessageFlags.IsComponentsV2 });
        } catch (err) {}

        await member.timeout(durationMs, `${reason} | Bị cấm bởi ${message.author.tag}`);

        const successContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`<:Tick:1488402363394818170> | **[${user.username}](http://discord.com/users/${user.id})** [\`${user.id}\`] đã bị cấm trong **${ms(durationMs, { long: true })}**.\n**Lý do:** ${reason}`)
            );

        await message.channel.send({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
    }
};
