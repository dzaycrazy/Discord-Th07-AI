const { EmbedBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");

module.exports = {
    name: "unlockall",
    aliases: [],
    description: "Mở khóa tất cả các kênh văn bản để cho phép @everyone gửi tin nhắn",
    category: "moderation",
    cooldown: 10,
    run: async (client, message, args) => {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn cần quyền \`Quản trị viên\` để sử dụng lệnh này.`)]
            });
        }

        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Tôi cần quyền \`Quản lý Kênh\` để mở khóa các kênh.`)]
            });
        }

        const loadingMsg = await message.channel.send({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`<:loading:1488406665467531294> Đang mở khóa tất cả các kênh...`)]
        });

        const channels = message.guild.channels.cache.filter(
            c => c.type === ChannelType.GuildText
        );

        let success = 0;
        let failed = 0;

        for (const [, channel] of channels) {
            try {
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    SendMessages: null
                });
                success++;
            } catch {
                failed++;
            }
        }

        return loadingMsg.edit({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`${client.emoji.tick} | Đã mở khóa **${success}** kênh. Thất bại: **${failed}**`)]
        });
    }
};
