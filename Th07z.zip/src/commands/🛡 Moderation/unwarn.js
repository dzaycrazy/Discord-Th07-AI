const { 
    PermissionFlagsBits, 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require("discord.js");

module.exports = {
    name: "unwarn",
    aliases: ["uw"],
    description: "Gỡ cảnh cáo của thành viên",
    category: "moderation",
    cooldown: 3,

    run: async (client, message, args, prefix) => {

        const db = client.db;

        const MAX_WARN = 6; // 🔥 đổi ở đây

        const time = new Date().toLocaleString("vi-VN", {
            timeZone: "Asia/Ho_Chi_Minh"
        });

        const errorContainer = (text) => ({
            components: [
                new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`### <:disabled:1487783250452545616> Lỗi\n${text}`)
                    )
            ],
            flags: MessageFlags.IsComponentsV2
        });

        if (!message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return message.channel.send(errorContainer("Bạn không có quyền **`KICK_MEMBERS`**."));
        }

        const input = args[0]?.replace(/[<@!>]/g, "");

        if (!input) {
            return message.channel.send(
                errorContainer(`Sai cú pháp — \`${prefix}unwarn @user\``)
            );
        }

        let member = message.guild.members.cache.get(input)
            || message.guild.members.cache.find(m =>
                m.user.username.toLowerCase() === input.toLowerCase() ||
                m.displayName.toLowerCase() === input.toLowerCase()
            );

        if (!member) return message.channel.send(errorContainer("Không tìm thấy người dùng."));

        const key = `warn_${message.guild.id}_${member.id}`;
        let warns = await db.get(key) || 0;

        if (warns <= 0) {
            return message.channel.send(errorContainer("Người này không có cảnh cáo nào."));
        }

        warns--;

        if (warns <= 0) {
            await db.delete(key);
            warns = 0;
        } else {
            await db.set(key, warns);
        }

        const bar = "▰".repeat(warns) + "▱".repeat(MAX_WARN - warns);

        // DM USER
        const dmUnwarn = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## <:enable:1487783260565143614> Cảnh cáo đã được gỡ`)
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**<:discordnole:1438114578830725201> Máy chủ**\n> ${message.guild.name}\n\n` +
                    `**<:automod:1487785352612548638> Người gỡ**\n> ${message.author.tag}\n\n` +
                    `**<:warning:1487783235286073465> Cảnh cáo còn lại**\n> ${bar} (**${warns}/${MAX_WARN}**)\n\n` +
                    `**<:clock:1489894867122262036> Thời gian**\n> ${time}`
                )
            );

        try {
            await member.send({ components: [dmUnwarn], flags: MessageFlags.IsComponentsV2 });
        } catch {}

        // SERVER LOG
        const unwarnContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## <:enable:1487783260565143614> Gỡ Cảnh cáo`)
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**<:dzaycrazy:1435253900734238800> Người được gỡ**\n> <@${member.id}> (${member.user.tag})\n\n` +
                    `**<:automod:1487785352612548638> Người thực hiện**\n> <@${message.author.id}> (${message.author.tag})\n\n` +
                    `**<:warning:1487783235286073465> Cảnh cáo còn lại**\n> ${bar} (**${warns}/${MAX_WARN}**)\n\n` +
                    `**<:clock:1489894867122262036> Thời gian**\n> ${time}`
                )
            );

        await message.channel.send({ components: [unwarnContainer], flags: MessageFlags.IsComponentsV2 });
    }
};