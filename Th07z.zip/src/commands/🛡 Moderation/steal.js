const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} = require('discord.js');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

module.exports = {
  name: 'steal',
  description: 'Thêm biểu tượng cảm xúc hoặc nhãn dán vào máy chủ này',
  aliases: ['eadd', 'grab'],
  category: 'util',
  cooldown: 6,
  premium: true,
  run: async (client, message, args) => {
    const prefix = message.guild?.prefix || 'th!';

    if (!message.member.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription('<:disabled:1487783250452545616> Bạn cần quyền `Quản lý Biểu tượng cảm xúc và Nhãn dán`.')
            .setColor('#FF4444'),
        ],
      });
    }

    let inputs = [];

    if (message.reference) {
      try {
        const refMsg = await message.channel.messages.fetch(message.reference.messageId);
        const attachments = [...refMsg.attachments.values()].map(a => a.url);
        const stickers = [...refMsg.stickers.values()].map(s => s.url);
        const emojis = (refMsg.content.match(/<a?:\w+:\d+>/g) || []).map(parseEmoteToUrl).filter(Boolean);
        inputs = [...attachments, ...stickers, ...emojis];
      } catch (e) {
        console.error(e);
      }
    }

    if (args.length) {
      for (const arg of args) {
        if (arg.startsWith('<')) {
          const url = parseEmoteToUrl(arg);
          if (url) inputs.push(url);
        } else if (arg.startsWith('http')) {
          inputs.push(arg);
        }
      }
    }

    if (!inputs.length) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription(`<:disabled:1487783250452545616> Không tìm thấy biểu tượng cảm xúc, nhãn dán hoặc hình ảnh hợp lệ!\n\n**Cách dùng:** \`${prefix}steal <biểu_tượng_cảm_xúc|url>\`\n**Hoặc:** Trả lời một tin nhắn chứa biểu tượng cảm xúc/nhãn dán`)
            .setColor('#FF4444')
            .setFooter({ text: 'Mẹo: Bạn cũng có thể đính kèm hình ảnh trực tiếp!' }),
        ],
      });
    }

    await createPagedSelector(message, inputs);
  },
};

function parseEmoteToUrl(emote) {
  try {
    const match = emote.match(/<?(a)?:\w+:(\d+)>?/);
    if (!match) return null;
    const animated = Boolean(match[1]);
    const id = match[2];
    return `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}`;
  } catch {
    return null;
  }
}

function generateRandomName(prefix = 'item') {
  const randomNum = Math.floor(Math.random() * 999999) + 100000;
  return `${prefix}_${randomNum}`;
}

async function addEmoji(message, url) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Không thể tải hình ảnh (${response.status})`);
    const buffer = Buffer.from(await response.arrayBuffer());

    const name = generateRandomName('emoji');
    const emoji = await message.guild.emojis.create({
      attachment: buffer,
      name: name,
    });

    await message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setDescription(`<:enable:1487783260565143614> Đã thêm biểu tượng cảm xúc ${emoji} (\`${name}\`) thành công`)
          .setThumbnail(url)
          .setColor('#00FF88')
          .setFooter({ text: `Tổng số biểu tượng cảm xúc: ${message.guild.emojis.cache.size}` }),
      ],
    });
  } catch (e) {
    await message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setDescription(`<:disabled:1487783250452545616> Không thể thêm biểu tượng cảm xúc: ${e.message}`)
          .setColor('#FF4444'),
      ],
    });
  }
}

async function addSticker(message, url) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Không thể tải nhãn dán (${response.status})`);
    const buffer = Buffer.from(await response.arrayBuffer());

    const name = generateRandomName('sticker');
    const file = { attachment: buffer, name: 'sticker.png' };

    const sticker = await message.guild.stickers.create({
      file,
      name: name,
      tags: '⭐',
    });

    const totalStickers = message.guild.stickers.cache.size;

    await message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setDescription(`<:enable:1487783260565143614> Đã thêm nhãn dán **${name}** thành công`)
          .setThumbnail(url)
          .setColor('#00FF88')
          .setFooter({ text: `Tổng số nhãn dán: ${totalStickers}` }),
      ],
    });
  } catch (e) {
    await message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setDescription(`<:disabled:1487783250452545616> Không thể thêm nhãn dán: ${e.message}`)
          .setColor('#FF4444'),
      ],
    });
  }
}

async function createPagedSelector(message, urls) {
  let index = 0;

  const embed = new EmbedBuilder()
    .setTitle('Trình Trộm Biểu Tượng Cảm Xúc/Nhãn Dán')
    .setDescription(`Xem trước **${index + 1}** trên tổng số **${urls.length}**\nChọn thứ muốn trộm:`)
    .setImage(urls[index])
    .setColor('#5865F2')
    .setFooter({ text: 'Menu này sẽ hết hạn sau 2 phút' });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('prev')
      .setLabel('Trước')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(urls.length === 1),
    new ButtonBuilder()
      .setCustomId('steal_emoji')
      .setLabel('Trộm làm Biểu tượng cảm xúc')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('steal_sticker')
      .setLabel('Trộm làm Nhãn dán')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('next')
      .setLabel('Tiếp')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(urls.length === 1),
  );

  const msg = await message.reply({ embeds: [embed], components: [row] });
  const filter = i => i.user.id === message.author.id;
  const collector = msg.createMessageComponentCollector({ filter, time: 120000 });

  collector.on('collect', async interaction => {
    await interaction.deferUpdate();

    if (interaction.customId === 'prev') {
      index = (index - 1 + urls.length) % urls.length;
    } else if (interaction.customId === 'next') {
      index = (index + 1) % urls.length;
    } else if (interaction.customId === 'steal_emoji') {
      await addEmoji(message, urls[index]);
    } else if (interaction.customId === 'steal_sticker') {
      await addSticker(message, urls[index]);
    }

    embed
      .setDescription(`Xem trước **${index + 1}** trên tổng số **${urls.length}**\nChọn thứ muốn trộm:`)
      .setImage(urls[index]);

    await msg.edit({ embeds: [embed], components: [row] });
  });

  collector.on('end', async () => {
    row.components.forEach(b => b.setDisabled(true));
    embed.setFooter({ text: 'Menu này đã hết hạn' });
    await msg.edit({ embeds: [embed], components: [row] }).catch(() => {});
  });
}
