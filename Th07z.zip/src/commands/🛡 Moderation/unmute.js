const { PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require("discord.js");

module.exports = {
    name: "untimeout",
    aliases: ["unmute"],
    description: "Gỡ bỏ thời gian chờ khỏi một thành viên",
    category: "moderation",
    cooldown: 3,
    run: async (client, message, args, prefix) => {

        const errorContainer = (text) => {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không có quyền **`MODERATE_MEMBERS`** cần thiết để thực hiện lệnh này."));
        }

        const input = args[0]?.replace(/[<@!>]/g, "");
        const reason = args.slice(1).join(" ") || "Không có lý do được cung cấp.";

        if (!input) {
            return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | **Sử dụng sai** — \`${prefix}unmute @người_dùng/tên_người_dùng/ID [lý_do]\``));
        }

        let member = message.guild.members.cache.get(input)
            || message.guild.members.cache.find(m =>
                m.user.username.toLowerCase() === input.toLowerCase() ||
                m.user.tag?.toLowerCase() === input.toLowerCase() ||
                m.displayName.toLowerCase() === input.toLowerCase()
            );

        let user = member?.user || await client.users.fetch(input).catch(() => null);

        if (!user) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Không tìm thấy người dùng nào với thông tin đã nhập. Hãy thử sử dụng ID, tên người dùng hoặc nhắc đến họ."));
        }

        if (!member) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Người dùng đó không phải là thành viên của máy chủ này."));
        }

        if (user.id === message.author.id) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không thể tự gỡ thời gian chờ cho mình."));
        }

        if (user.id === client.user.id) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Tôi không thể bị gỡ thời gian chờ."));
        }

        if (!member.isCommunicationDisabled()) {
            return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | **${user.username}** hiện không bị đặt thời gian chờ.`));
        }

        if (message.author.id !== message.guild.ownerId) {
            if (message.member.roles.highest.position <= member.roles.highest.position) {
                return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | Bạn không thể gỡ thời gian chờ cho **${user.username}** — vai trò cao nhất của họ bằng hoặc cao hơn của bạn.`));
            }
        }

        if (!member.moderatable) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Tôi không thể gỡ thời gian chờ cho thành viên này. Vai trò cao nhất của họ bằng hoặc cao hơn của tôi."));
        }

        await member.timeout(null, `${reason} | Timeout removed by ${message.author.tag}`);

        const successContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`<:Tick:1488402363394818170> | **[${user.username}](http://discord.com/users/${user.id})** [\`${user.id}\`] đã được gỡ thời gian chờ.\n**Lý do:** ${reason}`)
            );

        await message.channel.send({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });

        const dmContainer = new ContainerBuilder()
            .addTextDisplayComponents(new TextDisplayBuilder().setContent("### 🔊 Thời Gian Chờ Của Bạn Đã Được Gỡ Bỏ"))
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Máy chủ » ** ${message.guild.name}\n` +
                    `**Người điều hành » ** [${message.author.username}](http://discord.com/users/${message.author.id})\n` +
                    `**<:lydo:1489896447099801642> » ** ${reason}`
                )
            );

        try {
            await user.send({ components: [dmContainer], flags: MessageFlags.IsComponentsV2 });
        } catch (err) {}
    }
};
