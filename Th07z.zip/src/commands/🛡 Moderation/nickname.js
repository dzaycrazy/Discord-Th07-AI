const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
    name: "nickname",
    aliases: ["nick"],
    description: "Thay đổi hoặc đặt lại biệt danh của người dùng",
    category: "moderation",
    cooldown: 3,
    run: async (client, message, args, prefix) => {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageNicknames)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription("<:cross:1488403197893541898> | Bạn cần quyền `MANAGE_NICKNAMES` để sử dụng lệnh này.")]
            });
        }

        if (!args[0]) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`<:cross:1488403197893541898> | Cách dùng: \`${prefix}nick @người_dùng <tên>\``)]
            });
        }

        const actualMentions = message.mentions.users.filter(user => {
            if (message.reference && message.reference.messageId) {
                return !message.mentions.repliedUser || user.id !== message.mentions.repliedUser.id;
            }
            return true;
        });

        let target = actualMentions.first();
        if (!target) target = await client.users.fetch(args[0]).catch(() => null);

        if (!target) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription("<:cross:1488403197893541898> | Không tìm thấy người dùng nào từ lượt nhắc hoặc ID.")]
            });
        }

        if (target.id === client.user.id) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription("<:cross:1488403197893541898> | Tôi không thể thay đổi biệt danh của chính mình.")]
            });
        }

        const member = await message.guild.members.fetch(target.id).catch(() => null);

        if (!member) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription("<:cross:1488403197893541898> | Người dùng này không có trong máy chủ.")]
            });
        }

        if (!member.manageable) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription("<:cross:1488403197893541898> | Tôi không thể thay đổi biệt danh của người dùng này. Vai trò của họ có thể cao hơn hoặc tôi thiếu quyền.")]
            });
        }

        if (message.member.roles.highest.position <= member.roles.highest.position && message.author.id !== message.guild.ownerId) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`<:cross:1488403197893541898> | Bạn không thể thay đổi biệt danh của ${target.username}. Vai trò của họ bằng hoặc cao hơn vai trò của bạn.`)]
            });
        }

        const newNick = args.slice(1).join(" ");

        if (!newNick) {
            await member.setNickname(null).catch(() => {});
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`<:cross:1488403197893541898> | Biệt danh của **[${target.username}](http://discord.com/users/${target.id})** đã được đặt lại.`)]
            });
        }

        if (newNick.length > 32) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription("<:cross:1488403197893541898> | Biệt danh không được dài quá 32 ký tự.")]
            });
        }

        await member.setNickname(newNick).catch(() => {});

        return message.channel.send({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`<:Tick:1488402363394818170> | Biệt danh của **[${target.username}](http://discord.com/users/${target.id})** đã được thay đổi thành **${newNick}**.`)]
        });
    }
};
