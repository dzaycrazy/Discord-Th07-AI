const { PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require("discord.js");

module.exports = {
    name: "ban",
    aliases: [],
    description: "Cấm một thành viên khỏi máy chủ",
    category: "moderation",
    cooldown: 3,
    run: async (client, message, args, prefix) => {

        const errorContainer = (text) => {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return message.channel.send(errorContainer("<:cross:1488403197893541898> | Bạn không có quyền **`BAN_MEMBERS`** cần thiết để thực hiện lệnh này."));
        }

        const input = args[0]?.replace(/[<@!>]/g, "");
        const reason = args.slice(1).join(" ") || "Không có lý do nào được cung cấp.";

        if (!input) {
            return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | **Sử dụng sai** — \`${prefix}ban @người_dùng/tên_người_dùng/ID [lý_do]\``));
        }

        let member = message.guild.members.cache.get(input)
            || message.guild.members.cache.find(m =>
                m.user.username.toLowerCase() === input.toLowerCase() ||
                m.user.tag?.toLowerCase() === input.toLowerCase() ||
                m.displayName.toLowerCase() === input.toLowerCase()
            );

        let user = member?.user || await client.users.fetch(input).catch(() => null);

        if (!user) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Không tìm thấy người dùng nào với thông tin đã nhập. Hãy thử sử dụng ID, tên người dùng hoặc nhắc đến họ."));
        }

        if (user.id === message.author.id) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không thể tự cấm mình."));
        }

        if (user.id === client.user.id) {
            return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Tôi không thể bị cấm."));
        }

        if (member) {
            if (message.author.id !== message.guild.ownerId) {
                if (member.id === message.guild.ownerId) {
                    return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Bạn không thể cấm chủ sở hữu máy chủ."));
                }

                if (message.member.roles.highest.position <= member.roles.highest.position) {
                    return message.channel.send(errorContainer(`<:disabled:1487783250452545616> | Bạn không thể cấm **${user.username}** — vai trò cao nhất của họ bằng hoặc cao hơn của bạn.`));
                }
            }

            if (!member.bannable) {
                return message.channel.send(errorContainer("<:disabled:1487783250452545616> | Tôi không thể cấm thành viên này. Vai trò cao nhất của họ bằng hoặc cao hơn của tôi."));
            }

            const dmContainer = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent("### <:cross:1488403197893541898> Bạn Đã Bị Cấm"))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**Máy chủ » ** ${message.guild.name}\n` +
                        `**Người kiểm duyệt » ** [${message.author.username}](http://discord.com/users/${message.author.id})\n` +
                        `**<:lydo:1489896447099801642> » ** ${reason}`
                    )
                );

            try {
                await user.send({ components: [dmContainer], flags: MessageFlags.IsComponentsV2 });
            } catch (err) {}
        }

        await message.guild.members.ban(user.id, { reason: `${reason} | Bị cấm bởi ${message.author.tag}` });

        const successContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`<:Tick:1488402363394818170> | **[${user.username}](http://discord.com/users/${user.id})** [\`${user.id}\`] đã bị cấm khỏi máy chủ.\n**<:lydo:1489896447099801642> » ** ${reason}`)
            );

        await message.channel.send({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
    }
};
