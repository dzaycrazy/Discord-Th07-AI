const { 
    PermissionFlagsBits, 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require("discord.js");

module.exports = {
    name: "warn",
    aliases: ["w"],
    description: "Cảnh cáo thành viên",
    category: "moderation",
    cooldown: 3,

    run: async (client, message, args, prefix) => {

        const db = client.db;

        const MAX_WARN = 6;
        const KICK_AT = 7;

        const time = new Date().toLocaleString("vi-VN", {
            timeZone: "Asia/Ho_Chi_Minh"
        });

        const errorContainer = (text) => ({
            components: [
                new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`### <:disabled:1487783250452545616> Lỗi\n${text}`)
                    )
            ],
            flags: MessageFlags.IsComponentsV2
        });

        if (!message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return message.channel.send(errorContainer("Bạn không có quyền **`KICK_MEMBERS`**."));
        }

        const input = args[0]?.replace(/[<@!>]/g, "");
        const reason = args.slice(1).join(" ") || "Không có lý do.";

        if (!input) {
            return message.channel.send(errorContainer(`Sai cú pháp — \`${prefix}warn @user [lý_do]\``));
        }

        let member = message.guild.members.cache.get(input)
            || message.guild.members.cache.find(m =>
                m.user.username.toLowerCase() === input.toLowerCase() ||
                m.displayName.toLowerCase() === input.toLowerCase()
            );

        if (!member) return message.channel.send(errorContainer("Không tìm thấy người dùng."));
        if (member.id === message.author.id) return message.channel.send(errorContainer("Không thể tự warn mình."));
        if (member.id === message.guild.ownerId) return message.channel.send(errorContainer("Không thể warn chủ server."));

        const key = `warn_${message.guild.id}_${member.id}`;
        let warns = await db.get(key) || 0;
        warns++;

        await db.set(key, warns);

        const displayWarns = Math.min(warns, MAX_WARN);
        const bar = "▰".repeat(displayWarns) + "▱".repeat(MAX_WARN - displayWarns);

        // ⏳ timeout config
        let timeoutDuration = null;
        let timeoutText = "";

        if (warns === 3) {
            timeoutDuration = 2 * 60 * 60 * 1000; // 2h
            timeoutText = "2 giờ";
        } else if (warns === 5) {
            timeoutDuration = 10 * 60 * 60 * 1000; // 10h
            timeoutText = "10 giờ";
        } else if (warns === 6) {
            timeoutDuration = 24 * 60 * 60 * 1000; // 1 ngày
            timeoutText = "1 ngày";
        }

        // 🚨 cảnh báo cuối
        const isLastWarning = warns === MAX_WARN;

        // 📩 DM WARN
        const dmWarn = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## <:warning:1487783235286073465> Bạn đã bị cảnh cáo${isLastWarning ? " (CẢNH BÁO CUỐI)" : ""}`
                )
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**<:discordnole:1438114578830725201> Máy chủ**\n> ${message.guild.name}\n\n` +
                    `**<:automod:1487785352612548638> Người cảnh cáo**\n> <@${message.author.id}> (${message.author.tag})\n\n` +
                    `**<:lydo:1489896447099801642> Lý do**\n> ${reason}\n\n` +
                    `**<:warning:1487783235286073465> Số lần**\n> ${bar} (**${displayWarns}/${MAX_WARN}**)\n\n` +
                    `${timeoutDuration ? `<:clock:1489894867122262036> **Bạn đã bị timeout ${timeoutText}**\n\n` : ""}` +
                    `${isLastWarning ? "<:warning:1487783235286073465> **Lần tiếp theo sẽ bị kick!**\n\n" : ""}` +
                    `**<:clock:1489894867122262036> Thời gian**\n> ${time}`
                )
            );

        try {
            await member.send({ components: [dmWarn], flags: MessageFlags.IsComponentsV2 });
        } catch {}

        // ⏳ APPLY TIMEOUT
        if (timeoutDuration && member.moderatable) {
            try {
                await member.timeout(timeoutDuration, `Warn ${warns} | ${message.author.tag}`);
            } catch {}
        }

        // 📢 SERVER LOG
        const warnContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## <:warning:1487783235286073465> Hệ Thống Cảnh Báo ${isLastWarning ? " (CẢNH BÁO CUỐI)" : ""}`
                )
            )
            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**<:anti:1487786661143384065> Người vi phạm**\n> <@${member.id}> (${member.user.tag})\n\n` +
                    `**<:automod:1487785352612548638> Người cảnh cáo**\n> <@${message.author.id}> (${message.author.tag})\n\n` +
                    `**<:lydo:1489896447099801642> Lý do**\n> ${reason}\n\n` +
                    `**<:warning:1487783235286073465> Warn**\n> ${bar} (**${displayWarns}/${MAX_WARN}**)\n\n` +
                    `${timeoutDuration ? `<:clock:1489894867122262036> **Timeout: ${timeoutText}**\n\n` : ""}` +
                    `${isLastWarning ? "<:warning:1487783235286073465> **Lần tiếp theo sẽ bị kick!**\n\n" : ""}` +
                    `**<:clock:1489894867122262036> Thời gian**\n> ${time}`
                )
            );

        await message.channel.send({ components: [warnContainer], flags: MessageFlags.IsComponentsV2 });

        // 💀 KICK
        if (warns >= KICK_AT) {

            if (!member.kickable) {
                return message.channel.send(errorContainer("Không thể kick người này."));
            }

            try {
                await member.send({
                    components: [
                        new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`## <:anti:1487786661143384065> Bạn đã bị kick`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `<:discordnole:1438114578830725201> Máy chủ: ${message.guild.name}\n` +
                                    `<:lydo:1489896447099801642> Lý do: Vượt quá ${MAX_WARN} cảnh cáo\n` +
                                    `<:clock:1489894867122262036> Thời gian: ${time}`
                                )
                            )
                    ],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch {}

            await member.kick(`Quá warn | ${message.author.tag}`);
            await db.delete(key);

            await message.channel.send({
                components: [
                    new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`<:anti:1487786661143384065> <@${member.id}> đã bị kick (quá warn)`)
                        )
                ],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};