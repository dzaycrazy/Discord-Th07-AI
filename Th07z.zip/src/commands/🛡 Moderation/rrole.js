const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
    name: "rrole",
    aliases: ["removerole"],
    description: "Xóa một quyền khỏi người dùng",
    category: "moderation",
    cooldown: 3,
    run: async (client, message, args, prefix) => {
        const bypassUserId = "1187321862724800562";
        const hasPermission = message.member.permissions.has(PermissionFlagsBits.Administrator) || message.author.id === bypassUserId;

        if (!hasPermission) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn cần quyền QUẢN TRỊ VIÊN để sử dụng lệnh này.`)
                ]
            });
        }

        if (args.length < 2) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Cách dùng lệnh: \`${prefix}rrole <người_dùng> <quyền>\``)
                ]
            });
        }

        let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        if (!role) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng cung cấp một quyền hợp lệ.`)
                ]
            });
        }
        if (!user) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng cung cấp một người dùng hợp lệ.`)
                ]
            });
        }

        if (
            message.member.roles.highest.position <= user.roles.highest.position &&
            message.author.id !== message.guild.ownerId &&
            message.author.id !== bypassUserId
        ) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn không thể thay đổi quyền cho những người dùng có quyền cao hơn hoặc bằng quyền của bạn.`)
                ]
            });
        }

        if (role.position >= message.guild.members.me.roles.highest.position) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Tôi không thể xóa một quyền cao hơn hoặc bằng quyền cao nhất của tôi.`)
                ]
            });
        }

        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Tôi không có quyền quản lý quyền.`)
                ]
            });
        }

        const reason = `${message.author.tag} đã xóa quyền ${role.name} khỏi ${user.user.tag}`;

        try {
            await user.roles.remove(role, reason);
            await message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#00FF7F')
                        .setDescription(`${client.emoji.tick} | Đã xóa thành công quyền **${role.name}** khỏi ${user.user.tag}.`)
                ]
            });
        } catch (err) {
            console.error('Error removing role:', err);
            await message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FF4B4B')
                        .setDescription(`${client.emoji.cross} | Tôi không thể xóa quyền đó. Vui lòng kiểm tra vị trí quyền và các quyền của tôi.`)
                ]
            });
        }
    }
};
