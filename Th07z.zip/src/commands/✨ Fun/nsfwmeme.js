const { EmbedBuilder } = require("discord.js");
const axios = require("axios");

function formatNumber(num) {
  if (!num || isNaN(num)) return "0";
  return num.toLocaleString("vi-VN");
}

module.exports = {
  name: "nsfwmeme",
  description: "Meme nsfw",
  cooldown: 5,
  premium: true,

  async run(client, message) {
    try {
      if (!message.channel.nsfw) {
        return message.reply("<:disabled:1487783250452545616> Lệnh này chỉ dùng trong kênh xác minh độ tuổi !");
      }

      const subs = [
  "nsfwmemes",
  "dirtymemes",
  "funnyNSFW",
  "hornyjail",
  "cursedcomments",
  "shitposting",
  "offensivememes"
];
      let data;

      for (let i = 0; i < 5; i++) {
        const randomSub = subs[Math.floor(Math.random() * subs.length)];

        try {
          const res = await axios.get(`https://meme-api.com/gimme/${randomSub}`);
          if (res.data?.url) {
            data = res.data;
            break;
          }
        } catch {}
      }

      if (!data) {
        return message.reply("<:disabled:1487783250452545616> Không lấy được meme...");
      }

      const embed = new EmbedBuilder()
        .setColor(0x1a1a1a)
        .setTitle(`<:nsfw:1491794522441515109> ${data.author || "Unknown"}`)
        .setImage(data.url)
        .setDescription(
          `<:search:1492132251608158338> [xᴇᴍ ʙàɪ đăɴɢ](${data.postLink || "https://reddit.com"})`
        )
.setFooter({
  text: `${message.author.username} • 👍 ${formatNumber(data.ups)} • 💬 ${formatNumber(data.num_comments)}`,
  iconURL: message.author.displayAvatarURL({ dynamic: true })
})
        .setTimestamp();

      return message.reply({ embeds: [embed] });

    } catch (err) {
      console.error(err);
      return message.reply("<:disabled:1487783250452545616> API lỗi...");
    }
  }
};