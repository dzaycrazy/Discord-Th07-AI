const { EmbedBuilder } = require("discord.js");
const axios = require("axios");

function formatNumber(num) {
  if (!num || isNaN(num)) return "0";
  return num.toLocaleString("vi-VN");
}

module.exports = {
  name: "meme",
  description: "Meme + info Reddit",
  cooldown: 4,

  async run(client, message) {
    try {
      const res = await axios.get("https://meme-api.com/gimme");
      const data = res.data;

      if (!data?.url) {
        return message.reply("<:disabled:1487783250452545616> Không lấy được meme...");
      }

      const embed = new EmbedBuilder()
        .setColor(0x2f3136)
        .setTitle(`<:tags:1492084967965069322> ${data.author || "Unknown"}`)
        .setImage(data.url)
        .setDescription(
          `<:search:1492132251608158338> [xᴇᴍ ʙàɪ đăɴɢ](${data.postLink || "https://reddit.com"})`
        )
        .setFooter({
  text: `${message.author.username} • 👍 ${formatNumber(data.ups)} • 💬 ${formatNumber(data.num_comments)}`,
  iconURL: message.author.displayAvatarURL({ dynamic: true })
})
        .setTimestamp(); // thời gian bot gửi

      return message.reply({ embeds: [embed] });

    } catch (err) {
      console.error(err);
      return message.reply("<:disabled:1487783250452545616> API meme lỗi...");
    }
  }
};