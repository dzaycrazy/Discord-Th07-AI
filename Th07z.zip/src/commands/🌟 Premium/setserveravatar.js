const { EmbedBuilder, PermissionFlagsBits, REST, Routes } = require("discord.js");
const https = require("https");
const http = require("http");

module.exports = {
    name: "setserveravatar",
    aliases: ["ssa", "serveravatar", "setguildavatar"],
    description: "Đặt ảnh đại diện của bot chỉ cho máy chủ này (Premium)",
    category: "premium",
    cooldown: 5,
    premium: true,

    async run(client, message, args) {
        if (!message.guild) {
            return message.reply("Lệnh này chỉ có thể được sử dụng trong một máy chủ.");
        }

        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor("#FF0000")
                        .setDescription(`${client.emoji.cross || "<:warning:1487783235286073465>"} Bạn cần quyền **Quản trị viên** để sử dụng lệnh này.`)
                ]
            });
        }

        const attachment = message.attachments.first();
        const imageUrl = args[0] || (attachment ? attachment.url : null);

        if (!imageUrl) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor("#26272F")
                        .setTitle("Đặt Ảnh Đại Diện Máy Chủ")
                        .setDescription("Đặt ảnh đại diện tùy chỉnh cho bot trong máy chủ này.")
                        .addFields(
                            { name: "Cách dùng", value: `\`${client.config.prefix}setserveravatar <image_url>\`\nHoặc đính kèm một hình ảnh vào tin nhắn.`, inline: false },
                            { name: "Bí danh", value: "`ssa`, `serveravatar`, `setguildavatar`", inline: false },
                            { name: "Đặt lại", value: `Sử dụng \`${client.config.prefix}resetserveravatar\` để đặt lại.`, inline: false }
                        )
                ]
            });
        }

        if (!isValidUrl(imageUrl)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor("#FF0000")
                        .setDescription(`${client.emoji.cross || "<:disabled:1487783250452545616>"} Vui lòng cung cấp một URL hình ảnh hợp lệ.`)
                ]
            });
        }

        const statusMsg = await message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor("#26272F")
                    .setDescription("<:warning:1487783235286073465> Đang cập nhật ảnh đại diện máy chủ...")
            ]
        });

        try {
            const avatarData = await downloadImage(imageUrl);

            if (!avatarData) {
                return statusMsg.edit({
                    embeds: [
                        new EmbedBuilder()
                            .setColor("#FF0000")
                            .setDescription(`${client.emoji.cross || "<:disabled:1487783250452545616>"} Không thể tải xuống hình ảnh. Vui lòng kiểm tra URL.`)
                    ]
                });
            }

            const rest = new REST({ version: "10" }).setToken(client.token);
            
            await rest.patch(Routes.guildMember(message.guild.id, "@me"), {
                body: { avatar: avatarData }
            });

            await statusMsg.edit({
                embeds: [
                    new EmbedBuilder()
                        .setColor("#00FF00")
                        .setDescription(`${client.emoji.tick || "<:enable:1487783260565143614>"} Ảnh đại diện máy chủ đã được cập nhật thành công!`)
                        .setThumbnail(imageUrl)
                ]
            });

        } catch (error) {
            console.error("Lỗi Ảnh Đại Diện Máy Chủ:", error.message);
            await statusMsg.edit({
                embeds: [
                    new EmbedBuilder()
                        .setColor("#FF0000")
                        .setDescription(`${client.emoji.cross || "<:disabled:1487783250452545616>"} Không thể cập nhật ảnh đại diện: ${error.message}`)
                ]
            });
        }
    }
};

function isValidUrl(str) {
    return str.startsWith("http://") || str.startsWith("https://");
}

function downloadImage(url) {
    return new Promise((resolve) => {
        const protocol = url.startsWith("https") ? https : http;

        protocol.get(url, (response) => {
            if (response.statusCode === 301 || response.statusCode === 302) {
                downloadImage(response.headers.location).then(resolve);
                return;
            }
            
            if (response.statusCode !== 200) {
                resolve(null);
                return;
            }

            const chunks = [];
            response.on("data", (chunk) => chunks.push(chunk));
            response.on("end", () => {
                try {
                    const buffer = Buffer.concat(chunks);
                    const ext = url.split(".").pop().split("?")[0].toLowerCase();
                    const mimeTypes = {
                        png: "image/png",
                        jpg: "image/jpeg",
                        jpeg: "image/jpeg",
                        gif: "image/gif",
                        webp: "image/webp"
                    };
                    const mimeType = mimeTypes[ext] || "image/png";
                    resolve(`data:${mimeType};base64,${buffer.toString("base64")}`);
                } catch {
                    resolve(null);
                }
            });
        }).on("error", () => resolve(null));
    });
}
