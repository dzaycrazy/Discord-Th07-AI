const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'antialt',
    aliases: ['altdetect'],
    description: 'Chặn tài khoản mới/tài khoản phụ tham gia (Phiên bản Premium)',
    category: 'premium',
    cooldown: 5,
    premium: true,
    run: async (client, message, args, prefix) => {
        if (!message.member.permissions.has('ManageGuild')) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn cần \`MANAGE_GUILD\` quyền sử dụng lệnh này.`)]
            });
        }

        const subCommand = args[0]?.toLowerCase();
        const currentSetting = await client.db.get(`antialt_${message.guild.id}`);

        if (!subCommand) {
            const embed = new EmbedBuilder()
                .setColor('#26272F')
                .setTitle('💎 Anti-Alt System')
                .setDescription(
                    `**Tình trạng hiện tại:** ${currentSetting?.enabled ? '<:enable:1487783260565143614> Đã bật' : '<:disabled:1487783250452545616> Đã tắt'}\n` +
                    `**Tuổi tối thiểu để mở tài khoản:** ${currentSetting?.minAge || 7} ngày\n` +
                    `**Hoạt động:** ${currentSetting?.action || 'kick'}\n\n` +
                    `**Lệnh:**\n` +
                    `\`${prefix}antialt enable <days>\` - Kích hoạt theo độ tuổi tối thiểu\n` +
                    `\`${prefix}antialt disable\` - Tắt anti-alt\n` +
                    `\`${prefix}antialt action <kick/ban>\` - Thiết lập hành động cho tài khoản phụ`
                )
                .setFooter({ text: 'Tính năng cao cấp', iconURL: client.user.displayAvatarURL() });

            return message.channel.send({ embeds: [embed] });
        }

        if (subCommand === 'enable') {
            const days = parseInt(args[1]) || 7;
            if (days < 1 || days > 365) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Số ngày phải nằm trong khoảng từ 1 đến 365..`)]
                });
            }

            await client.db.set(`antialt_${message.guild.id}`, {
                enabled: true,
                minAge: days,
                action: currentSetting?.action || 'kick'
            });

            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Anti-Alt đã bật <:enable:1487783260565143614> ! Các tài khoản nhỏ hơn **${days} ngày** sẽ bị chặn.`)]
            });
        }

        if (subCommand === 'disable') {
            await client.db.set(`antialt_${message.guild.id}`, { enabled: false });
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Anti-Alt đã bị vô hiệu hóa.`)]
            });
        }

        if (subCommand === 'action') {
            const action = args[1]?.toLowerCase();
            if (!['kick', 'ban'].includes(action)) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Cần phải hành động \`kick\` or \`ban\`.`)]
                });
            }

            await client.db.set(`antialt_${message.guild.id}`, {
                ...currentSetting,
                action: action
            });

            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Các tài khoản phụ sẽ được **${action}ed**.`)]
            });
        }
    }
};

