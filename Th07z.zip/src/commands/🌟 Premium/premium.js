const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ms = require('ms');

const OWNER_ID = ('1187321862724800562')
module.exports = {
    name: 'premium',
    aliases: ['prem'],
    description: 'Quản lý gói đăng ký premium',
    category: 'premium',
    cooldown: 3,
    run: async (client, message, args, prefix) => {
        const subCommand = args[0]?.toLowerCase();
        
        if (!subCommand) {
            const embed = new EmbedBuilder()
                .setColor('#26272F')
                .setAuthor({ name: 'Hệ thống Premium', iconURL: client.user.displayAvatarURL() })
                .setDescription(
                    `**Các Lệnh Khả Dụng:**\n\n` +
                    `\`${prefix}premium add <@user> <Thời gian duy trì> <Số lượng dùng Premium>\` - Thêm premium cho người dùng\n` +
                    `\`${prefix}premium remove <@user>\` - Xóa premium khỏi người dùng\n` +
                    `\`${prefix}premium status [người dùng/máy chủ]\` - Kiểm tra trạng thái premium\n` +
                    `\`${prefix}premium activate\` - Kích hoạt premium trên máy chủ này\n` +
                    `\`${prefix}premium deactivate\` - Hủy kích hoạt premium khỏi máy chủ này\n\n` +
                    `**Lưu ý:** Premium cấp quyền truy cập vào các tính năng độc quyền!`
                )
                .setFooter({ text: 'Hệ thống Premium', iconURL: client.user.displayAvatarURL() })
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        }

        if (subCommand === 'add') {
            if (message.author.id !== OWNER_ID) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Chỉ chủ sở hữu bot mới có thể thêm premium cho người dùng.`)]
                });
            }

            const user = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);
            const durationStr = args[2];
            const count = parseInt(args[3]) || 1;

            if (!user) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng đề cập một người dùng hợp lệ.\n**Cách dùng:** \`${prefix}premium add <@user> <duration> <count>\``)]
                });
            }

            if (!durationStr) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng cung cấp thời lượng (ví dụ: 30d, 7d, 1h).\n**Cách dùng:** \`${prefix}premium add <@user> <Thời gian duy trì> <Số lượng dùng Premium>\``)]
                });
            }

            const duration = ms(durationStr);
            if (!duration || duration < 60000) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Thời lượng không hợp lệ. Sử dụng định dạng như: 1d, 7d, 30d, 1h`)]
                });
            }

            const expiresAt = Date.now() + duration;

            await client.db.set(`premium_user_${user.id}`, {
                expiresAt: expiresAt,
                count: count,
                addedBy: message.author.id,
                addedAt: Date.now()
            });

            const embed = new EmbedBuilder()
                .setColor('#26272F')
                .setTitle('Đã thêm Premium')
                .setDescription(`${client.emoji.tick} | Đã thêm premium thành công cho **${user.tag}** <:enable:1487783260565143614>`)
                .addFields(
                    { name: 'Thời lượng', value: durationStr, inline: true },
                    { name: 'Số lượng máy chủ', value: `${count}`, inline: true },
                    { name: 'Hết hạn', value: `<t:${Math.floor(expiresAt / 1000)}:R>`, inline: true }
                )
                .setFooter({ text: `Được thêm bởi ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        }

        if (subCommand === 'remove') {
            if (message.author.id !== OWNER_ID) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Chỉ chủ sở hữu bot mới có thể xóa premium khỏi người dùng.`)]
                });
            }

            const user = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);

            if (!user) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng đề cập một người dùng hợp lệ.\n**Cách dùng:** \`${prefix}premium remove <@user>\``)]
                });
            }

            const premiumData = await client.db.get(`premium_user_${user.id}`);
            if (!premiumData) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | **${user.tag}** không có premium.`)]
                });
            }

            const activatedGuilds = await client.db.get(`premium_activated_${user.id}`) || [];
            for (const guildId of activatedGuilds) {
                await client.db.delete(`premium_guild_${guildId}`);
            }
            await client.db.delete(`premium_activated_${user.id}`);
            await client.db.delete(`premium_user_${user.id}`);

            const embed = new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`${client.emoji.tick} | Đã xóa premium thành công khỏi **${user.tag}**\nCũng đã hủy kích hoạt ${activatedGuilds.length} máy chủ.`)
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        }

        if (subCommand === 'status') {
            const target = args[1]?.toLowerCase();
            
            if (target === 'guild' || target === 'server') {
                const guildPremium = await client.db.get(`premium_guild_${message.guild.id}`);
                
                if (!guildPremium) {
                    return message.channel.send({
                        embeds: [new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} | Máy chủ này chưa kích hoạt premium.`)]
                    });
                }

                const activator = await client.users.fetch(guildPremium.activatedBy).catch(() => null);
                
                const embed = new EmbedBuilder()
                    .setColor('#26272F')
                    .setTitle('Trạng thái Premium của Máy chủ')
                    .setThumbnail(message.guild.iconURL({ dynamic: true }))
                    .addFields(
                        { name: 'Trạng thái', value: '<:enable:1487783260565143614> Hoạt động', inline: true },
                        { name: 'Hết hạn', value: `<t:${Math.floor(guildPremium.expiresAt / 1000)}:R>`, inline: true },
                        { name: 'Được kích hoạt bởi', value: activator ? activator.tag : 'Không xác định', inline: true }
                    )
                    .setTimestamp();

                return message.channel.send({ embeds: [embed] });
            }

            const user = message.mentions.users.first() || message.author;
            const premiumData = await client.db.get(`premium_user_${user.id}`);
            
            if (!premiumData) {
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setLabel('Nhận Premium')
                            .setStyle(ButtonStyle.Link)
                            .setURL(client.config.support_server_link || 'https://discord.gg/BW6NbrKdyF')
                            .setEmoji('💎')
                    );

                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | **${user.tag}** không có premium.`)],
                    components: [row]
                });
            }

            const isExpired = Date.now() > premiumData.expiresAt;
            const activatedGuilds = await client.db.get(`premium_activated_${user.id}`) || [];

            const embed = new EmbedBuilder()
                .setColor(isExpired ? '#FF0000' : '#FFD700')
                .setTitle('Trạng thái Premium của Người dùng')
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: 'Trạng thái', value: isExpired ? '<:disabled:1487783250452545616> Đã hết hạn' : '<:enable:1487783260565143614> Hoạt động', inline: true },
                    { name: 'Hết hạn', value: `<t:${Math.floor(premiumData.expiresAt / 1000)}:R>`, inline: true },
                    { name: 'Số lượng máy chủ', value: `${activatedGuilds.length}/${premiumData.count}`, inline: true },
                    { name: 'Máy chủ đã kích hoạt', value: activatedGuilds.length > 0 ? activatedGuilds.map(id => `\`${id}\``).join(', ').slice(0, 1000) : 'Không có', inline: false }
                )
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        }

        if (subCommand === 'activate') {
            const premiumData = await client.db.get(`premium_user_${message.author.id}`);
            
            if (!premiumData) {
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setLabel('Nhận Premium')
                            .setStyle(ButtonStyle.Link)
                            .setURL(client.config.support_server_link || 'https://discord.gg/BW6NbrKdyF')
                            .setEmoji('💎')
                    );

                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setTitle('Yêu cầu Premium')
                        .setDescription(`${client.emoji.cross} | Bạn không có premium!\n\nHãy tham gia máy chủ hỗ trợ của chúng tôi để mua premium.`)],
                    components: [row]
                });
            }

            if (Date.now() > premiumData.expiresAt) {
                const activatedGuilds = await client.db.get(`premium_activated_${message.author.id}`) || [];
                for (const guildId of activatedGuilds) {
                    await client.db.delete(`premium_guild_${guildId}`);
                }
                await client.db.set(`premium_activated_${message.author.id}`, []);
                
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Premium của bạn đã hết hạn! Tất cả các máy chủ đã kích hoạt đã bị hủy kích hoạt. Vui lòng gia hạn để tiếp tục sử dụng các tính năng premium.`)]
                });
            }

            const existingGuildPremium = await client.db.get(`premium_guild_${message.guild.id}`);
            if (existingGuildPremium && existingGuildPremium.activatedBy !== message.author.id) {
                if (Date.now() > existingGuildPremium.expiresAt) {
                    await client.db.delete(`premium_guild_${message.guild.id}`);
                } else {
                    return message.channel.send({
                        embeds: [new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} | Máy chủ này đã có premium được kích hoạt bởi người dùng khác.`)]
                    });
                }
            }

            if (existingGuildPremium && existingGuildPremium.activatedBy === message.author.id && Date.now() < existingGuildPremium.expiresAt) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn đã kích hoạt premium trên máy chủ này rồi.`)]
                });
            }

            let activatedGuilds = await client.db.get(`premium_activated_${message.author.id}`) || [];
            
            const validGuilds = [];
            for (const guildId of activatedGuilds) {
                const guildPrem = await client.db.get(`premium_guild_${guildId}`);
                if (guildPrem && Date.now() < guildPrem.expiresAt) {
                    validGuilds.push(guildId);
                } else if (guildPrem) {
                    await client.db.delete(`premium_guild_${guildId}`);
                }
            }
            activatedGuilds = validGuilds;
            await client.db.set(`premium_activated_${message.author.id}`, activatedGuilds);
            
            if (activatedGuilds.length >= premiumData.count) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn đã sử dụng hết tất cả các vị trí máy chủ của mình (${activatedGuilds.length}/${premiumData.count}).\n\nHãy hủy kích hoạt premium khỏi một máy chủ khác hoặc nâng cấp gói của bạn.`)]
                });
            }

            activatedGuilds.push(message.guild.id);
            await client.db.set(`premium_activated_${message.author.id}`, activatedGuilds);
            await client.db.set(`premium_guild_${message.guild.id}`, {
                activatedBy: message.author.id,
                expiresAt: premiumData.expiresAt,
                activatedAt: Date.now()
            });

            const embed = new EmbedBuilder()
                .setColor('#26272F')
                .setTitle('Premium đã được kích hoạt!')
                .setDescription(`${client.emoji.tick} | Đã kích hoạt premium thành công trên **${message.guild.name}**!`)
                .addFields(
                    { name: 'Hết hạn', value: `<t:${Math.floor(premiumData.expiresAt / 1000)}:R>`, inline: true },
                    { name: 'Số vị trí đã dùng', value: `${activatedGuilds.length}/${premiumData.count}`, inline: true }
                )
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        }

        if (subCommand === 'deactivate') {
            const guildPremium = await client.db.get(`premium_guild_${message.guild.id}`);
            
            if (!guildPremium) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Máy chủ này chưa kích hoạt premium.`)]
                });
            }

            if (guildPremium.activatedBy !== message.author.id && message.author.id !== OWNER_ID) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Chỉ người đã kích hoạt premium hoặc chủ sở hữu bot mới có thể hủy kích hoạt.`)]
                });
            }

            const activatedGuilds = await client.db.get(`premium_activated_${guildPremium.activatedBy}`) || [];
            const newActivatedGuilds = activatedGuilds.filter(id => id !== message.guild.id);
            await client.db.set(`premium_activated_${guildPremium.activatedBy}`, newActivatedGuilds);
            await client.db.delete(`premium_guild_${message.guild.id}`);

            const embed = new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`${client.emoji.tick} | Đã hủy kích hoạt premium thành công khỏi **${message.guild.name}**.`)
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        }

        return message.channel.send({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`${client.emoji.cross} | Lệnh phụ không hợp lệ. Sử dụng \`${prefix}premium\` để xem các lệnh khả dụng.`)]
        });
    }
};
