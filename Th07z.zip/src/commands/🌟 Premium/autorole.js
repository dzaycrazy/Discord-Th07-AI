const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const DANGEROUS_PERMISSIONS = [
    PermissionFlagsBits.Administrator,
    PermissionFlagsBits.BanMembers,
    PermissionFlagsBits.KickMembers,
    PermissionFlagsBits.ManageGuild,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.ManageRoles,
    PermissionFlagsBits.ManageWebhooks,
    PermissionFlagsBits.MentionEveryone,
];

module.exports = {
    name: 'autorole',
    aliases: ['ar'],
    description: 'Tự động gán vai trò cho thành viên mới (Premium)',
    category: 'premium',
    cooldown: 5,
    premium: true,
    run: async (client, message, args, prefix) => {
        if (!message.member.permissions.has('ManageRoles')) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn cần quyền \`QUẢN LÝ VAI TRÒ\` để sử dụng lệnh này.`)]
            });
        }

        const subCommand = args[0]?.toLowerCase();
        const currentSettings = await client.db.get(`autorole_${message.guild.id}`) || { enabled: false, roles: [], botRoles: [] };

        if (!subCommand) {
            const humanRoles = currentSettings.roles?.map(id => `<@&${id}>`).join(', ') || 'Không có';
            const botRoles = currentSettings.botRoles?.map(id => `<@&${id}>`).join(', ') || 'Không có';

            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setTitle('💎 Hệ thống Tự động Gán Vai trò')
                    .setDescription(
                        `**Trạng thái:** ${currentSettings.enabled ? '<:enable:1487783260565143614> Đã bật' : '<:disabled:1487783250452545616> Đã tắt'}\n\n` +
                        `**Vai trò cho người dùng:** ${humanRoles}\n` +
                        `**Vai trò cho bot:** ${botRoles}\n\n` +
                        `**Lệnh:**\n` +
                        `\`${prefix}autorole enable\` - Bật tự động gán vai trò\n` +
                        `\`${prefix}autorole disable\` - Tắt tự động gán vai trò\n` +
                        `\`${prefix}autorole add <human/bot> @role\` - Thêm một vai trò\n` +
                        `\`${prefix}autorole remove <human/bot> @role\` - Xóa một vai trò\n` +
                        `\`${prefix}autorole clear\` - Xóa tất cả vai trò`
                    )
                    .setFooter({ text: 'Tính năng Premium', iconURL: client.user.displayAvatarURL() })]
            });
        }

        if (subCommand === 'enable') {
            currentSettings.enabled = true;
            await client.db.set(`autorole_${message.guild.id}`, currentSettings);
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Tự động gán vai trò đã được bật.`)]
            });
        }

        if (subCommand === 'disable') {
            currentSettings.enabled = false;
            await client.db.set(`autorole_${message.guild.id}`, currentSettings);
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Tự động gán vai trò đã bị tắt.`)]
            });
        }

        if (subCommand === 'add') {
            const type = args[1]?.toLowerCase();
            const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2]);

            if (!['human', 'bot'].includes(type)) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Loại phải là \`human\` (người dùng) hoặc \`bot\`.`)]
                });
            }

            if (!role) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng đề cập một vai trò hợp lệ.`)]
                });
            }

            // Check for dangerous permissions
            if (DANGEROUS_PERMISSIONS.some(p => role.permissions.has(p))) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Tôi không thể thêm vai trò này vì nó có các quyền nguy hiểm.`)]
                });
            }

            if (role.position >= message.guild.members.me.roles.highest.position) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Tôi không thể gán vai trò này vì nó có cấp bậc cao hơn vai trò cao nhất của tôi.`)]
                });
            }

            const roleArray = type === 'human' ? 'roles' : 'botRoles';
            if (!currentSettings[roleArray]) currentSettings[roleArray] = [];
            
            if (currentSettings[roleArray].includes(role.id)) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vai trò này đã có trong danh sách tự động gán vai trò cho ${type} rồi.`)]
                });
            }

            currentSettings[roleArray].push(role.id);
            await client.db.set(`autorole_${message.guild.id}`, currentSettings);

            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Đã thêm ${role} vào danh sách tự động gán vai trò cho ${type}.`)]
            });
        }

        if (subCommand === 'remove') {
            const type = args[1]?.toLowerCase();
            const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2]);

            if (!['human', 'bot'].includes(type)) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Loại phải là \`human\` (người dùng) hoặc \`bot\`.`)]
                });
            }

            if (!role) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vui lòng đề cập một vai trò hợp lệ.`)]
                });
            }

            const roleArray = type === 'human' ? 'roles' : 'botRoles';
            if (!currentSettings[roleArray]?.includes(role.id)) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Vai trò này không có trong danh sách tự động gán vai trò cho ${type}.`)]
                });
            }

            currentSettings[roleArray] = currentSettings[roleArray].filter(id => id !== role.id);
            await client.db.set(`autorole_${message.guild.id}`, currentSettings);

            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Đã xóa ${role} khỏi danh sách tự động gán vai trò cho ${type}.`)]
            });
        }

        if (subCommand === 'clear') {
            await client.db.set(`autorole_${message.guild.id}`, { enabled: false, roles: [], botRoles: [] });
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Đã xóa tất cả cài đặt tự động gán vai trò.`)]
            });
        }
    }
};
