const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const DANGEROUS_PERMISSIONS = [
    PermissionFlagsBits.Administrator,
    PermissionFlagsBits.BanMembers,
    PermissionFlagsBits.KickMembers,
    PermissionFlagsBits.ManageGuild,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.ManageRoles,
    PermissionFlagsBits.ManageWebhooks,
    PermissionFlagsBits.MentionEveryone,
];

module.exports = {
    name: 'massrole',
    aliases: ['mrole'],
    description: 'Thêm hoặc xóa quyền khỏi tất cả thành viên (Premium)',
    category: 'premium',
    cooldown: 30,
    premium: true,
    run: async (client, message, args, prefix) => {
        if (!message.member.permissions.has('ManageRoles')) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn cần quyền \`MANAGE_ROLES\` để sử dụng lệnh này.`)]
            });
        }

        const subCommand = args[0]?.toLowerCase();
        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);

        if (!subCommand || !['add', 'remove', 'humans', 'bots'].includes(subCommand)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setTitle('💎 Gán Quyền Hàng Loạt')
                    .setDescription(
                        `**Cách dùng:**\n` +
                        `\`${prefix}massrole add @role\` - Thêm quyền cho tất cả thành viên\n` +
                        `\`${prefix}massrole remove @role\` - Xóa quyền khỏi tất cả thành viên\n` +
                        `\`${prefix}massrole humans @role\` - Thêm quyền cho tất cả người dùng (không phải bot)\n` +
                        `\`${prefix}massrole bots @role\` - Thêm quyền cho tất cả bot`
                    )
                    .setFooter({ text: 'Tính năng Premium', iconURL: client.user.displayAvatarURL() })]
            });
        }

        if (!role) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Vui lòng đề cập một quyền hợp lệ.`)]
            });
        }

        // Check for dangerous permissions
        if (DANGEROUS_PERMISSIONS.some(p => role.permissions.has(p))) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Tôi không thể quản lý quyền này vì nó có các quyền nguy hiểm (Quản trị viên, Cấm, v.v.).`)]
            });
        }

        if (role.position >= message.guild.members.me.roles.highest.position) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Tôi không thể quản lý quyền này vì nó cao hơn quyền cao nhất của tôi.`)]
            });
        }

        const statusMsg = await message.channel.send({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`⏳ Đang xử lý thao tác gán quyền hàng loạt... Việc này có thể mất một lúc.`)]
        });

        let members = await message.guild.members.fetch();
        let successCount = 0;
        let failCount = 0;

        if (subCommand === 'humans') {
            members = members.filter(m => !m.user.bot);
        } else if (subCommand === 'bots') {
            members = members.filter(m => m.user.bot);
        }

        const isAdding = subCommand === 'add' || subCommand === 'humans' || subCommand === 'bots';
        const reason = `Gán Quyền Hàng Loạt ${isAdding ? 'Thêm' : 'Xóa'} bởi ${message.author.tag} (${message.author.id})`;

        for (const [, member] of members) {
            try {
                if (isAdding && !member.roles.cache.has(role.id)) {
                    await member.roles.add(role, reason);
                    successCount++;
                } else if (subCommand === 'remove' && member.roles.cache.has(role.id)) {
                    await member.roles.remove(role, reason);
                    successCount++;
                }
                await new Promise(r => setTimeout(r, 100));
            } catch {
                failCount++;
            }
        }

        await statusMsg.edit({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setTitle('Gán Quyền Hàng Loạt Hoàn Tất')
                .setDescription(
                    `${client.emoji.tick} | Thao tác đã hoàn tất!\n\n` +
                    `**Quyền:** ${role}\n` +
                    `**Hành động:** ${isAdding ? 'Đã thêm' : 'Đã xóa'}\n` +
                    `**Thành công:** \`${successCount}\`\n` +
                    `**Thất bại:** \`${failCount}\``
                )]
        });
    }
};
