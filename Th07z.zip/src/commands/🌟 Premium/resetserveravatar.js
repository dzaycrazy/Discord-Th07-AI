const { EmbedBuilder, PermissionFlagsBits, REST, Routes } = require("discord.js");

module.exports = {
    name: "resetserveravatar",
    aliases: ["rsa", "clearserveravatar"],
    description: "Đặt lại ảnh đại diện của bot dành riêng cho máy chủ về mặc định (Premium)",
    category: "premium",
    cooldown: 5,
    premium: true,

    async run(client, message) {
        if (!message.guild) {
            return message.reply("Lệnh này chỉ có thể được sử dụng trong một máy chủ.");
        }

        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor("#FF0000")
                        .setDescription(`${client.emoji.cross || "<:disabled:1487783250452545616>"} Bạn cần quyền **Quản trị viên** để sử dụng lệnh này.`)
                ]
            });
        }

        const statusMsg = await message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor("#26272F")
                    .setDescription("<:warning:1487783235286073465> Đang đặt lại ảnh đại diện máy chủ...")
            ]
        });

        try {
            const rest = new REST({ version: "10" }).setToken(client.token);
            
            await rest.patch(Routes.guildMember(message.guild.id, "@me"), {
                body: { avatar: null }
            });

            await statusMsg.edit({
                embeds: [
                    new EmbedBuilder()
                        .setColor("#00FF00")
                        .setDescription(`${client.emoji.tick || "<:enable:1487783260565143614>"} Ảnh đại diện máy chủ đã được đặt lại về mặc định!`)
                ]
            });

        } catch (error) {
            console.error("Reset Avatar Error:", error.message);
            await statusMsg.edit({
                embeds: [
                    new EmbedBuilder()
                        .setColor("#FF0000")
                        .setDescription(`${client.emoji.cross || "<:disabled:1487783250452545616>"} Không thể đặt lại ảnh đại diện: ${error.message}`)
                ]
            });
        }
    }
};
