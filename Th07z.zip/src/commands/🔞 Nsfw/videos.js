const { getRule34 } = require("../../Zay/nsfwApi.js");

// =========================
// CUSTOM ICONS
// =========================
const ICON = {
  arrow: "<:arror:1487785740673745096>",
  video: "<:video:1491794083776299241>",
  nsfw: "<:nsfw:1491794522441515109>",
  disabled: "<:disabled:1487783250452545616>"
};

// =========================
// RANDOM TAGS
// =========================
const RANDOM_TAGS = [
  "anime",
  "hentai",
  "animation",
  "futanari",
  "maid",
  "elf",
  "milf",
  "furry",
  "femboy",
  "schoolgirl",
  "succubus",
  "fantasy"
];

function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function isVideo(url = "") {
  return /\.(mp4|webm)$/i.test(url);
}

module.exports = {
  name: "videos",
  aliases: ["vid"],
  category: "nsfw",
  subCategory: "Nội dung video",
  cooldown: 3,
  premium: true,

  async execute(client, message, args) {
    try {
      if (!message.channel.nsfw) {
        return message.reply(`${ICON.disabled} Chỉ dùng trong kênh NSFW!`);
      }

      const now = Math.floor(Date.now() / 1000);

      // =========================
      // DEFAULT
      // =========================
      let count = 1; // 🔥 default 1 video
      let tags = [];

      const last = args[args.length - 1];

      // =========================
      // HANDLE ARGS
      // =========================
      if (!args.length) {
        tags = [random(RANDOM_TAGS)];
      } else {
        if (!isNaN(last)) {
          count = Math.min(Math.max(parseInt(last), 1), 10);
          tags = args.slice(0, -1);
        } else {
          tags = args;
        }

        if (!tags.length) {
          tags = [random(RANDOM_TAGS)];
        }
      }

      const query = tags.join(" ");

      const results = await getRule34(query, 500);

      if (!results?.length) {
        return message.reply(`${ICON.disabled} Không tìm thấy video!`);
      }

      let sent = 0;

      for (const post of results) {
        const url = typeof post === "string" ? post : post?.file_url;
        if (!url || !isVideo(url)) continue;

        const postId =
          typeof post === "object"
            ? post.id
            : (url.match(/id=(\d+)/)?.[1] || null);

        const sourceUrl = postId
          ? `https://rule34.xxx/index.php?page=post&s=view&id=${postId}`
          : "https://rule34.xxx/";

        // =========================
        // TEXT ONLY (NO EMBED)
        // =========================
        const text =
          `${ICON.arrow} ᴛᴀɢꜱ: ${tags.map(t => `\`${t}\``).join(", ")}\n` +
          `${ICON.arrow} ʏêᴜ ᴄầᴜ: <@${message.author.id}>\n` +
          `${ICON.arrow} ᴛʜờɪ ɢɪᴀɴ: <t:${now}:R>\n\n` +
          `<:content:1492082065699508414> [ɴộɪ ᴅᴜɴɢ](${url}) | <:content:1492082065699508414> [ɴɢᴜồɴ](${sourceUrl})\n\n` +
          `<:idea:1492084965494751313> Tip <:arror:1487785740673745096> dùng \`th!video <tag>\` để tìm nội dung bạn muốn xem`;

        await message.channel.send(text);

        sent++;
        await new Promise(r => setTimeout(r, 300));

        if (sent >= count) break;
      }

      if (!sent) {
        return message.reply(`${ICON.disabled} Không có video hợp lệ.`);
      }

    } catch (err) {
      console.error("VIDEOS ERROR:", err);
      return message.reply(`${ICON.disabled} Lỗi khi lấy video.`);
    }
  }
};