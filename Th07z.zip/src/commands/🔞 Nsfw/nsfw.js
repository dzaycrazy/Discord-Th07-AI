const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "nsfw",
  description: "Danh mục lệnh NSFW",
  aliases: ["notsafeforwork", "18+"],
  usage: "nsfw",
  category: "nsfw",
  cooldown: 3,

  async execute(client, message) {
    try {
      const nsfwCommands = Array.from(client.commands.values()).filter(
        cmd => cmd.category === "nsfw" && cmd.name !== "nsfw"
      );

      if (!nsfwCommands.length) {
        return message.reply(
          "<:disabled:1487783250452545616> Không thể tìm thấy lệnh trong thư mục Nsfw này..."
        );
      }

      const prefix = client.config?.prefix || "!";

// =========================
// CLEAN COMMAND LIST (GROUP)
// =========================
const PREMIUM_ICON = "<:Premium:1492870966664233021>";

const groups = {};

nsfwCommands.forEach(cmd => {
  const group = cmd.subCategory || "📦 Khác";

  if (!groups[group]) groups[group] = [];

  groups[group].push(
    `• \`${prefix}${cmd.name}\`${cmd.premium ? ` ${PREMIUM_ICON}` : ""}`
  );
});

// build text
let commandText = "";

for (const group in groups) {
  commandText += `**# ${group}**\n${groups[group].join("\n")}\n\n`;
}

      const mainImageUrl =
        "https://cdn.discordapp.com/attachments/1490373725093367968/1491808546298269796/image0.jpg";

      const thumbnailUrl =
        "https://cdn.discordapp.com/attachments/1490373725093367968/1491806886691864706/image0.gif";

      const embed = new EmbedBuilder()
        .setColor(0x808080)
        .setTitle("<:nsfw:1491794522441515109> ɴꜱꜰᴡ ᴍᴇɴᴜ")
        .setDescription(
          `-# Bạn có thể tùy chọn chỉ định một số cho bất kỳ lệnh NSFW nào , tương ứng với số lượng tệp mà bot hiển thị sau đó. \n(ví dụ: \`${prefix}hentai 10\`)\n\n` +
          `${commandText}\n\n` +
          `-# <:Premium:1492870966664233021> = Bắt đầu đăng ký [ᴍᴜᴀ ᴘʀᴇᴍɪᴜᴍ](https://discord.gg/JJGYbKskUa) để sử dụng lệnh này\n\n` +
          `${message.author.username}｜Sử dụng các lệnh bên trên để sử dụng Nsfw`
        )
        .setImage(mainImageUrl)
        .setThumbnail(thumbnailUrl)
        .setFooter({
          text: "Zay's Family • Dùng lệnh một cách thông minh"
        });

      return message.reply({ embeds: [embed] });

    } catch (err) {
      console.error(err);
      return message.reply(
        "<:disabled:1487783250452545616> Lỗi khi hiển thị menu lệnh...."
      );
    }
  },
};