const { EmbedBuilder } = require("discord.js");
const { getRule34 } = require("../../Zay/nsfwApi.js");

const TAG_MAP = {
  neko: ["neko"],
  catgirl: ["catgirl"],
  nekomimi: ["nekomimi"]
};

function expandTags(tags = []) {
  const all = [];

  for (const t of tags) {
    if (!t) continue;

    const lower = t.toLowerCase();

    if (TAG_MAP[lower]) {
      all.push(...TAG_MAP[lower]);
    } else {
      all.push(lower);
    }
  }

  return [...new Set(all)];
}

module.exports = {
  name: "neko",
  description: "Lấy media neko / catgirl",
  aliases: ["catgirl"],
  usage: "neko [1-30]",
  subCategory: "Nội dung hentai",
  category: "nsfw",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    try {
      if (!message.channel.nsfw) {
        return message.reply(
          "<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi !"
        );
      }

      let count = Math.min(Math.max(parseInt(args?.[0]) || 1, 1), 30);

      // bỏ số nếu có
      let tagArgs = [...args];
      if (!isNaN(tagArgs[tagArgs.length - 1])) {
        tagArgs.pop();
      }

      if (!tagArgs.length) tagArgs = ["neko"];

      const expandedTags = expandTags(tagArgs);
      const tagSearch = expandedTags.join(" ");

      const results = await getRule34(tagSearch, count);

      if (!results || !results.length) {
        return message.reply(
          "<:disabled:1487783250452545616> Không có dữ liệu neko..."
        );
      }

      const now = Math.floor(Date.now() / 1000);

      for (const post of results) {
        const rawUrl = typeof post === "string" ? post : post?.file_url;
        if (!rawUrl) continue;

        const postId =
          typeof post === "object"
            ? post.id
            : (rawUrl.match(/id=(\d+)/)?.[1] || null);

        const sourceUrl = postId
          ? `https://rule34.xxx/index.php?page=post&s=view&id=${postId}`
          : "https://rule34.xxx/";

        const isVideo = /\.(mp4|webm)$/i.test(rawUrl);

        const textBlock =
          `<:arror:1487785740673745096> ᴛᴀɢꜱ: ${expandedTags
            .map(t => `\`${t}\``)
            .join(", ")}\n` +
          `<:arror:1487785740673745096> ʏêᴜ ᴄầᴜ: <@${message.author.id}>\n` +
          `<:arror:1487785740673745096> ᴛʜờɪ ɢɪᴀɴ: <t:${now}:R>\n\n` +
          `<:content:1492082065699508414> [ɴộɪ ᴅᴜɴɢ](${rawUrl}) | <:content:1492082065699508414> [ɴɢᴜồɴ](${sourceUrl})`;

        // 🎥 VIDEO
        if (isVideo) {
          await message.reply({
            content:
              `<:video:1491794083776299241> **Neko Video** <:nsfw:1491794522441515109>\n` +
              textBlock
          });
        }

        // 🖼 IMAGE / GIF
        else {
          const embed = new EmbedBuilder()
            .setColor(0x808080)
            .setTitle("<:nsfw:1491794522441515109> Nội dung Neko Girl")
            .setDescription(textBlock)
            .setImage(rawUrl)
            .setFooter({
              text: `Trang ngẫu nhiên • ${count} kết quả`
            })
            .setTimestamp();

          await message.reply({ embeds: [embed] });
        }

        await new Promise(r => setTimeout(r, 250));
      }

    } catch (err) {
      console.error("NEKO ERROR:", err);
      return message.reply(
        "<:disabled:1487783250452545616> Lỗi khi lấy dữ liệu neko..."
      );
    }
  }
};