const { EmbedBuilder } = require("discord.js");
const { getRule34 } = require("../../Zay/nsfwApi.js");

const TAG_MAP = {
  futa: ["futa", "futanari", "futa_only"],
  boobs: ["boobs", "breasts"],
  ass: ["ass", "butt"],
  pussy: ["pussy", "vagina"],
  dick: ["dick", "penis"],
  anal: ["anal"],
  sex: ["sex", "intercourse"],
  neko: ["neko"],
  catgirl: ["catgirl"],
  hentai: ["hentai"]
};

function expandTags(tags = []) {
  const all = [];

  for (const t of tags) {
    if (!t) continue;
    const lower = t.toLowerCase();

    if (TAG_MAP[lower]) {
      all.push(...TAG_MAP[lower]);
    } else {
      all.push(lower);
    }
  }

  return [...new Set(all)];
}

module.exports = {
  name: "rule34",
  aliases: ["r34", "34"],
  category: "nsfw",
  subCategory: "Nội dung mở rộng",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    try {
      // ❌ check NSFW
      if (!message.channel.nsfw) {
        return message.reply(
          "<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi !"
        );
      }

      if (!args || !args.length) args = ["hentai"];

      let count = 1;
      let tagArgs = [...args];

      // 🔢 lấy số lượng an toàn
      const lastArg = args.length ? args[args.length - 1] : null;

      if (lastArg && !isNaN(lastArg)) {
        count = Math.min(Math.max(parseInt(lastArg), 1), 30);
        tagArgs = args.slice(0, -1);
      }

      if (!tagArgs.length) tagArgs = ["hentai"];
      tagArgs = tagArgs.slice(0, 5);

      const expandedTags = expandTags(tagArgs);
      const tagSearch = expandedTags.join(" ");

      const results = await getRule34(tagSearch, count);

      if (!results || !results.length) {
        return message.reply(
          "<:disabled:1487783250452545616> Không tìm thấy kết quả....."
        );
      }

      const now = Math.floor(Date.now() / 1000);

      for (const post of results) {
        const rawUrl = typeof post === "string" ? post : post?.file_url;
        if (!rawUrl) continue;

        const postId = typeof post === "object" ? post.id : null;

        const sourceUrl = postId
          ? `https://rule34.xxx/index.php?page=post&s=view&id=${postId}`
          : "https://rule34.xxx/";

        const isVideo = /\.(mp4|webm)$/i.test(rawUrl);

        const textBlock =
          `<:arror:1487785740673745096> ᴛᴀɢꜱ: ${expandedTags
            .map(t => `\`${t}\``)
            .join(", ")}\n` +
          `<:arror:1487785740673745096> ʏêᴜ ᴄầᴜ ʙởɪ: <@${message.author.id}>\n` +
          `<:arror:1487785740673745096> ᴛʜờɪ ɢɪᴀɴ: <t:${now}:F>\n\n` +
          `<:content:1492082065699508414> [ɴộɪ ᴅᴜɴɢ](${rawUrl}) | <:content:1492082065699508414> [ɴɢᴜồɴ](${sourceUrl})`;

        if (isVideo) {
          await message.reply({
            content:
              `<:video:1491794083776299241> **Video R34**\n` + textBlock
          });
        } else {
          const embed = new EmbedBuilder()
            .setColor(0x808080)
            .setTitle("<:nsfw:1491794522441515109> Nội Dung Người Lớn NSFW")
            .setDescription(textBlock)
            .setImage(rawUrl)
            .setFooter({
              text: `Trang ngẫu nhiên • ${count} kết quả`
            })
            .setTimestamp();

          await message.reply({ embeds: [embed] });
        }

        await new Promise(r => setTimeout(r, 250));
      }
    } catch (err) {
      console.error("❌ Lỗi R34:", err);
      return message.reply(
        "<:disabled:1487783250452545616> Lỗi khi tìm dữ liệu...."
      );
    }
  }
};