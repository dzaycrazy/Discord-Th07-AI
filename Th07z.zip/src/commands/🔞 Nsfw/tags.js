const { EmbedBuilder } = require("discord.js");
const axios = require("axios");

module.exports = {
  name: "tags",
  description: "Tìm tag từ Rule34",
  usage: "tags <từ khóa>",
  category: "nsfw",
  subCategory: "Nội dung khác",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    try {
      if (!message.channel.nsfw) {
        return message.reply(
          "<:disabled:1487783250452545616> Phải dùng trong kênh xác minh tuổi!"
        );
      }

      const query = args.join(" ").trim();

      if (!query) {
        return message.reply(
          "<:disabled:1487783250452545616> Nhập từ khóa tag!"
        );
      }

      const url = `https://api.rule34.xxx/autocomplete.php?q=${encodeURIComponent(query)}`;

      const res = await axios.get(url, {
        headers: { "User-Agent": "Mozilla/5.0" },
        timeout: 10000
      });

      const data = res.data;

      if (!Array.isArray(data) || data.length === 0) {
        return message.reply(
          "<:disabled:1487783250452545616> Không tìm thấy tag phù hợp..."
        );
      }

      const tags = data.slice(0, 40).map(t => t.value);

      // 🔥 format đẹp hơn
      const formatted = tags.map(t => `\`${t}\``);

      // chia chunk tránh embed limit
      const chunks = [];
      let current = "";

      for (const tag of formatted) {
        const line = `${tag}  `;

        if ((current + line).length > 900) {
          chunks.push(current);
          current = "";
        }

        current += line;
      }

      if (current) chunks.push(current);

      const embed = new EmbedBuilder()
        .setColor(0x808080)
        .setTitle("<:tags:1492084967965069322> Tìm kiếm nội dung Tags Rule34")
        .setDescription(
          `<:arror:1487785740673745096> **Tìm kiếm:** \`${query}\`\n` +
          `<:arror:1487785740673745096> **Kết quả:** ${tags.length} tags\n` +
          `<:arror:1487785740673745096> **Người yêu cầu:** <@${message.author.id}>`
        )
        .setFooter({ text: "Đã tìm kiếm nội dung Tags Rule34" })
        .setTimestamp();

      chunks.forEach((chunk, i) => {
        embed.addFields({
          name: `Trang ${i + 1}`,
          value: chunk || "Không có dữ liệu"
        });
      });

      await message.reply({ embeds: [embed] });

    } catch (err) {
      console.error("TAG ERROR:", err);
      return message.reply(
        "<:disabled:1487783250452545616> Lỗi khi lấy tag..."
      );
    }
  },
};