const { 
    EmbedBuilder, 
    PermissionFlagsBits 
} = require("discord.js");

module.exports = {
    name: "glist",
    aliases: ["giveawaylist", "giveaways", "activegiveaways"],
    description: "Liệt kê tất cả các giveaway đang hoạt động trong máy chủ",
    category: "giveaway",
    cooldown: 5,
    run: async (client, message, args, prefix) => {
        const arrow = client.emoji?.arrow || "▸";

        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Bạn cần quyền **Quản lý Máy chủ**.")
                ]
            });
        }

        const guildGiveaways = await client.db.get(`giveaways_${message.guild.id}`) || [];
        
        if (guildGiveaways.length === 0) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setTitle("<:warning:1487783235286073465> Danh sách Giveaway")
                        .setDescription(
                            `Không tìm thấy giveaway nào trong máy chủ này!\n\n` +
                            `Sử dụng \`${prefix}gstart <thời_gian> <số_người_thắng> <giải_thưởng>\` để tạo một giveaway!`
                        )
                ]
            });
        }

        const activeGiveaways = [];
        const endedGiveaways = [];

        for (const msgId of guildGiveaways) {
            const giveaway = await client.db.get(`giveaway_${msgId}`);
            if (giveaway) {
                if (giveaway.status && !giveaway.ended) {
                    activeGiveaways.push(giveaway);
                } else {
                    endedGiveaways.push(giveaway);
                }
            }
        }

        if (activeGiveaways.length === 0 && endedGiveaways.length === 0) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setTitle("<:warning:1487783235286073465> Danh sách Giveaway")
                        .setDescription(
                            `Không tìm thấy giveaway nào trong máy chủ này!\n\n` +
                            `Sử dụng \`${prefix}gstart <thời_gian> <số_người_thắng> <giải_thưởng>\` để tạo một giveaway!`
                        )
                ]
            });
        }

        let description = "";

        if (activeGiveaways.length > 0) {
            description += "**Giveaway đang hoạt động:**\n\n";
            
            for (const g of activeGiveaways.slice(0, 10)) {
                const endTimestamp = Math.floor(g.endTime / 1000);
                const messageUrl = `https://discord.com/channels/${g.guildId}/${g.channelId}/${g.messageId}`;
                
                description += `${arrow} **Giải thưởng:** ${g.prize}\n`;
                description += `${arrow} Người thắng: \`${g.winners}\` | Lượt tham gia: \`${g.entries?.length || 0}\`\n`;
                description += `${arrow} Kết thúc: <t:${endTimestamp}:R>\n`;
                description += `${arrow} [Chuyển đến Giveaway](${messageUrl})\n\n`;
            }

            if (activeGiveaways.length > 10) {
                description += `*...và ${activeGiveaways.length - 10} giveaway đang hoạt động khác*\n\n`;
            }
        }

        if (endedGiveaways.length > 0) {
            description += "**Giveaway đã kết thúc:**\n\n";
            
            const recentEnded = endedGiveaways.slice(-5).reverse();
            
            for (const g of recentEnded) {
                const messageUrl = `https://discord.com/channels/${g.guildId}/${g.channelId}/${g.messageId}`;
                const winners = g.winnerIds?.length > 0 
                    ? g.winnerIds.map(id => `<@${id}>`).join(", ")
                    : "Không có";
                
                description += `${arrow} **Giải thưởng:** ${g.prize}\n`;
                description += `${arrow} Người thắng: ${winners}\n`;
                description += `${arrow} Lượt tham gia: \`${g.entries?.length || 0}\`\n`;
                description += `${arrow} [Chuyển đến Giveaway](${messageUrl})\n\n`;
            }
        }

        const embed = new EmbedBuilder()
            .setColor('#26272F')
            .setTitle("<:warning:1487783235286073465> Danh sách Giveaway")
            .setDescription(description)
            .setFooter({ 
                text: `Đang hoạt động: ${activeGiveaways.length} | Tổng cộng: ${guildGiveaways.length}` 
            })
            .setTimestamp();

        return message.reply({ embeds: [embed] });
    }
};
