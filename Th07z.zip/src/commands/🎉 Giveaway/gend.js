const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { endGiveaway } = require("../../utils/giveawayUtils");

module.exports = {
    name: "gend",
    aliases: ["giveawayend", "endgiveaway"],
    description: "Kết thúc một giveaway ngay lập tức",
    category: "giveaway",
    usage: "<ID_tin_nhắn/liên_kết_tin_nhắn>",
    examples: ["gend 1234567890", "gend https://discord.com/channels/..."],
    cooldown: 3,
    run: async (client, message, args, prefix) => {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Bạn cần quyền **Quản lý Máy chủ**.")
                ]
            });
        }

        if (!args[0]) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setTitle("<:warning:1487783235286073465> Kết thúc Giveaway")
                        .setDescription(
                            `**Cách dùng:** \`${prefix}gend <ID_tin_nhắn/liên_kết_tin_nhắn>\`\n\n` +
                            `**Ví dụ:** \`${prefix}gend 1234567890123456789\``
                        )
                ]
            });
        }

        let messageId = args[0];
        
        if (messageId.includes("discord.com/channels/")) {
            const parts = messageId.split("/");
            messageId = parts[parts.length - 1];
        }

        const giveaway = await client.db.get(`giveaway_${messageId}`);
        
        if (!giveaway) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Không tìm thấy giveaway nào với ID tin nhắn đó!")
                ]
            });
        }

        if (giveaway.guildId !== message.guild.id) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Giveaway đó không thuộc máy chủ này!")
                ]
            });
        }

        if (giveaway.ended) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Giveaway đó đã kết thúc rồi!")
                ]
            });
        }

        const loadingMsg = await message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription("<:warning:1487783235286073465> Đang kết thúc giveaway...")
            ]
        });

        try {
            await endGiveaway(client, messageId);

            await loadingMsg.edit({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`<:warning:1487783235286073465> Giveaway cho **${giveaway.prize}** đã kết thúc!`)
                ]
            });
        } catch (error) {
            console.error("Error ending giveaway:", error);
            await loadingMsg.edit({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Không thể kết thúc giveaway. Vui lòng thử lại!")
                ]
            });
        }
    }
};
