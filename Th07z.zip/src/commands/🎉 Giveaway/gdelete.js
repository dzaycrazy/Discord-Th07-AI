const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionFlagsBits,
    ComponentType
} = require("discord.js");

module.exports = {
    name: "gdelete",
    aliases: ["giveawaydelete", "gcancel", "gremove"],
    description: "Xóa hoàn toàn một giveaway",
    category: "giveaway",
    usage: "<message_id/message_link>",
    examples: ["gdelete 1234567890", "gdelete https://discord.com/channels/..."],
    cooldown: 3,
    run: async (client, message, args, prefix) => {
        const arrow = client.emoji?.arrow || "▸";

        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Bạn cần quyền **Quản lý Máy chủ**.")
                ]
            });
        }

        if (!args[0]) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setTitle("<:warning:1487783235286073465> Xóa Giveaway")
                        .setDescription(
                            `**Cách dùng:** \`${prefix}gdelete <message_id/message_link>\`\n\n` +
                            `**Ví dụ:** \`${prefix}gdelete 1234567890123456789\``
                        )
                ]
            });
        }

        let messageId = args[0];
        
        if (messageId.includes("discord.com/channels/")) {
            const parts = messageId.split("/");
            messageId = parts[parts.length - 1];
        }

        const giveaway = await client.db.get(`giveaway_${messageId}`);
        
        if (!giveaway) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Không tìm thấy giveaway nào với ID tin nhắn đó!")
                ]
            });
        }

        if (giveaway.guildId !== message.guild.id) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Giveaway đó không thuộc máy chủ này!")
                ]
            });
        }

        const confirmEmbed = new EmbedBuilder()
            .setColor('#26272F')
            .setTitle("<:warning:1487783235286073465> Xác nhận Xóa")
            .setDescription(
                `${arrow} **Giải thưởng:** ${giveaway.prize}\n` +
                `${arrow} **Số lượt tham gia:** ${giveaway.entries?.length || 0}\n` +
                `${arrow} **Trạng thái:** ${giveaway.ended ? "Đã kết thúc" : "Đang hoạt động"}\n\n` +
                `Bạn có chắc chắn muốn xóa giveaway này không?`
            );

        const confirmBtn = new ButtonBuilder()
            .setCustomId("gdelete_confirm")
            .setStyle(ButtonStyle.Danger)
            .setLabel("Xóa")
            .setEmoji("🗑️");

        const cancelBtn = new ButtonBuilder()
            .setCustomId("gdelete_cancel")
            .setStyle(ButtonStyle.Secondary)
            .setLabel("Hủy");

        const row = new ActionRowBuilder().addComponents(confirmBtn, cancelBtn);

        const confirmMsg = await message.reply({
            embeds: [confirmEmbed],
            components: [row]
        });

        const collector = confirmMsg.createMessageComponentCollector({
            componentType: ComponentType.Button,
            filter: (i) => i.user.id === message.author.id,
            time: 30000,
            max: 1
        });

        collector.on("collect", async (interaction) => {
            if (interaction.customId === "gdelete_confirm") {
                try {
                    await client.db.delete(`giveaway_${messageId}`);
                    
                    let guildGiveaways = await client.db.get(`giveaways_${message.guild.id}`) || [];
                    guildGiveaways = guildGiveaways.filter(id => id !== messageId);
                    await client.db.set(`giveaways_${message.guild.id}`, guildGiveaways);

                    const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
                    if (channel) {
                        const giveawayMsg = await channel.messages.fetch(messageId).catch(() => null);
                        if (giveawayMsg) {
                            await giveawayMsg.delete().catch(() => {});
                        }
                    }

                    await interaction.update({
                        embeds: [
                            new EmbedBuilder()
                                .setColor('#26272F')
                                .setDescription(`<:warning:1487783235286073465> Giveaway cho **${giveaway.prize}** đã bị xóa!`)
                        ],
                        components: []
                    });
                } catch (error) {
                    console.error("Error deleting giveaway:", error);
                    await interaction.update({
                        embeds: [
                            new EmbedBuilder()
                                .setColor('#26272F')
                                .setDescription("<:disabled:1487783250452545616> Không thể xóa giveaway. Vui lòng thử lại!")
                        ],
                        components: []
                    });
                }
            } else {
                await interaction.update({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription("<:disabled:1487783250452545616> Đã hủy xóa giveaway.")
                    ],
                    components: []
                });
            }
        });

        collector.on("end", async (collected, reason) => {
            if (reason === "time" && collected.size === 0) {
                const disabledConfirmBtn = new ButtonBuilder()
                    .setCustomId("gdelete_confirm")
                    .setStyle(ButtonStyle.Danger)
                    .setLabel("Xóa")
                    .setEmoji("🗑️")
                    .setDisabled(true);

                const disabledCancelBtn = new ButtonBuilder()
                    .setCustomId("gdelete_cancel")
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel("Hủy")
                    .setDisabled(true);

                const disabledRow = new ActionRowBuilder().addComponents(disabledConfirmBtn, disabledCancelBtn);

                await confirmMsg.edit({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setTitle("<:warning:1487783235286073465> Hết thời gian xóa")
                            .setDescription("Yêu cầu xóa đã hết hạn.")
                    ],
                    components: [disabledRow]
                }).catch(() => {});
            }
        });
    }
};
