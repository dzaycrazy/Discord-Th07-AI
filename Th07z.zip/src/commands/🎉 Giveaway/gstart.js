const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionFlagsBits
} = require("discord.js");
const ms = require("ms");
const { scheduleGiveaway } = require("../../utils/giveawayUtils");

module.exports = {
    name: "gstart",
    aliases: ["giveawaystart", "gcreate", "giveaway"],
    description: "Bắt đầu một giveaway mới",
    category: "giveaway",
    usage: "<thời_gian> <số_người_thắng> <giải_thưởng>",
    examples: ["gstart 1h 1 Nitro", "gstart 30m 2 Discord Nitro Classic"],
    cooldown: 5,
    run: async (client, message, args, prefix) => {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Bạn cần quyền **Quản lý Máy chủ**.")
                ]
            });
        }

        if (args.length < 3) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setTitle("<:warning:1487783235286073465> Thiết lập Giveaway")
                        .setDescription(
                            `**Cách dùng:** \`${prefix}gstart <thời_gian> <số_người_thắng> <giải_thưởng>\`\n\n` +
                            `**Ví dụ:** \`${prefix}gstart 1h 1 Discord Nitro\``
                        )
                ]
            });
        }

        const timeArg = args[0];
        const winnersArg = args[1];
        const prize = args.slice(2).join(" ");

        const duration = ms(timeArg);
        if (!duration || duration < 10000) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Vui lòng cung cấp thời lượng hợp lệ! (Tối thiểu: 10 giây)")
                ]
            });
        }

        if (duration > 30 * 24 * 60 * 60 * 1000) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Thời lượng giveaway tối đa là 30 ngày!")
                ]
            });
        }

        const winners = parseInt(winnersArg);
        if (isNaN(winners) || winners < 1 || winners > 50) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Vui lòng cung cấp số lượng người thắng hợp lệ! (1-50)")
                ]
            });
        }

        if (!prize || prize.length > 256) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Vui lòng cung cấp giải thưởng hợp lệ! (Tối đa 256 ký tự)")
                ]
            });
        }

        const endTime = Date.now() + duration;
        const endTimestamp = Math.floor(endTime / 1000);
        const arrow = client.emoji?.arrow || "▸";

        const giveawayEmbed = new EmbedBuilder()
            .setColor('#26272F')
            .setTitle("<:giveaway:1488410187730653306> Giveaway 🎉")
            .setDescription(
                `${arrow} **Giải thưởng:** ${prize}\n` +
                `${arrow} **Kết thúc:** <t:${endTimestamp}:R> (<t:${endTimestamp}:t>)\n` +
                `${arrow} **Người thắng:** ${winners}\n` +
                `${arrow} **Người tổ chức:** ${message.author}`
            )
            .setTimestamp(endTime);

        const enterButton = new ButtonBuilder()
            .setCustomId("giveaway_enter")
            .setStyle(ButtonStyle.Secondary)
            .setEmoji("<:discordnole:1438114578830725201>")
            .setLabel("Tham gia");

        const entriesButton = new ButtonBuilder()
            .setCustomId("giveaway_entries_display")
            .setStyle(ButtonStyle.Secondary)
            .setLabel("Lượt tham gia: 0")
            .setDisabled(true);

        const row = new ActionRowBuilder().addComponents(enterButton, entriesButton);

        try {
            await message.delete().catch(() => {});

            const giveawayMessage = await message.channel.send({
                embeds: [giveawayEmbed],
                components: [row]
            });

            const giveawayData = {
                messageId: giveawayMessage.id,
                channelId: message.channel.id,
                guildId: message.guild.id,
                prize: prize,
                winners: winners,
                hostId: message.author.id,
                hostTag: message.author.tag,
                startTime: Date.now(),
                endTime: endTime,
                entries: [],
                status: true,
                ended: false
            };

            await client.db.set(`giveaway_${giveawayMessage.id}`, giveawayData);

            let guildGiveaways = await client.db.get(`giveaways_${message.guild.id}`) || [];
            guildGiveaways.push(giveawayMessage.id);
            await client.db.set(`giveaways_${message.guild.id}`, guildGiveaways);

            scheduleGiveaway(client, giveawayData);

        } catch (error) {
            console.error("Error starting giveaway:", error);
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616>  Không thể bắt đầu giveaway. Vui lòng thử lại!")
                ]
            });
        }
    }
};
