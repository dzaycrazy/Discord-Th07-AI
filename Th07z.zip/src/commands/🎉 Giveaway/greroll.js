const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionFlagsBits 
} = require("discord.js");

module.exports = {
    name: "greroll",
    aliases: ["giveawayreroll", "reroll"],
    description: "Chọn lại người thắng cho một giveaway đã kết thúc",
    category: "giveaway",
    usage: "<ID_tin_nhắn/liên_kết_tin_nhắn> [người_thắng]",
    examples: ["greroll 1234567890", "greroll 1234567890 2"],
    cooldown: 3,
    run: async (client, message, args, prefix) => {
        const arrow = client.emoji?.arrow || "▸";

        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Bạn cần quyền **Quản lý Máy chủ**.")
                ]
            });
        }

        if (!args[0]) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setTitle("<:warning:1487783235286073465> Chọn lại Giveaway")
                        .setDescription(
                            `**Cách dùng:** \`${prefix}greroll <ID_tin_nhắn/liên_kết_tin_nhắn> [người_thắng]\`\n\n` +
                            `**Ví dụ:** \`${prefix}greroll 1234567890123456789\``
                        )
                ]
            });
        }

        let messageId = args[0];
        const newWinnerCount = parseInt(args[1]) || null;
        
        if (messageId.includes("discord.com/channels/")) {
            const parts = messageId.split("/");
            messageId = parts[parts.length - 1];
        }

        const giveaway = await client.db.get(`giveaway_${messageId}`);
        
        if (!giveaway) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Không tìm thấy giveaway nào với ID tin nhắn đó!")
                ]
            });
        }

        if (giveaway.guildId !== message.guild.id) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Giveaway đó không thuộc máy chủ này!")
                ]
            });
        }

        if (!giveaway.ended) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`<:disabled:1487783250452545616> Giveaway đó chưa kết thúc! Hãy dùng \`${prefix}gend\` để kết thúc trước.`)
                ]
            });
        }

        const entries = giveaway.entries || [];
        
        if (entries.length === 0) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Không có ai tham gia giveaway đó! Không thể chọn lại.")
                ]
            });
        }

        const winnersToSelect = newWinnerCount || giveaway.winners;
        
        if (winnersToSelect < 1 || winnersToSelect > 50) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Số lượng người thắng phải từ 1 đến 50!")
                ]
            });
        }

        const shuffled = [...entries].sort(() => Math.random() - 0.5);
        const newWinners = shuffled.slice(0, Math.min(winnersToSelect, entries.length));

        giveaway.winnerIds = newWinners;
        await client.db.set(`giveaway_${messageId}`, giveaway);

        const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
        if (!channel) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription("<:disabled:1487783250452545616> Không thể tìm thấy kênh giveaway!")
                ]
            });
        }

        const giveawayMessage = await channel.messages.fetch(messageId).catch(() => null);
        const messageUrl = `https://discord.com/channels/${giveaway.guildId}/${giveaway.channelId}/${messageId}`;

        const winnerMentions = newWinners.map(id => `<@${id}>`).join(", ");
        
        if (giveawayMessage) {
            await giveawayMessage.reply({
                content: `<:warning:1487783235286073465> **Đã chọn lại Giveaway!**\n\n` +
                        `${arrow} Người thắng mới: ${winnerMentions}\n` +
                        `${arrow} **Giải thưởng:** ${giveaway.prize}\n` +
                        `${arrow} Được chọn lại bởi: ${message.author}`
            });
        }

        for (const winnerId of newWinners) {
            try {
                const winner = await client.users.fetch(winnerId).catch(() => null);
                if (winner) {
                    const dmEmbed = new EmbedBuilder()
                        .setColor('#26272F')
                        .setTitle("<:discordnole:1438114578830725201> Bạn đã thắng Giveaway (Chọn lại)!")
                        .setDescription(
                            `${arrow} **Giải thưởng:** ${giveaway.prize}\n` +
                            `${arrow} **Máy chủ:** ${message.guild.name}\n` +
                            `${arrow} **Người tổ chức:** ${giveaway.hostTag}\n` +
                            `${arrow} **Được chọn lại bởi:** ${message.author.tag}`
                        )
                        .setThumbnail(message.guild.iconURL({ dynamic: true }))
                        .setTimestamp();

                    const linkButton = new ButtonBuilder()
                        .setStyle(ButtonStyle.Link)
                        .setLabel("Đi đến Giveaway")
                        .setURL(messageUrl)
                        .setEmoji("🔗");

                    const dmRow = new ActionRowBuilder().addComponents(linkButton);

                    await winner.send({
                        embeds: [dmEmbed],
                        components: [dmRow]
                    }).catch(() => {});
                }
            } catch (err) {
                console.log(`Không thể gửi tin nhắn riêng cho người thắng được chọn lại ${winnerId}`);
            }
        }

        return message.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor('#26272F')
                    .setTitle("<:warning:1487783235286073465> Giveaway đã được chọn lại")
                    .setDescription(
                        `${arrow} **Giải thưởng:** ${giveaway.prize}\n` +
                        `${arrow} **Người thắng mới:** ${winnerMentions}`
                    )
                    .setTimestamp()
            ]
        });
    }
};
