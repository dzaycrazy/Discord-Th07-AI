
const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ButtonBuilder,
    SeparatorSpacingSize,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");

const ARROW = "<:arror:1487785740673745096>";
const STAR = "<:cat_star:1492453457158869113>";

module.exports = {
    name: "userinfo",
    aliases: ["ui"],
    cat: "util",

    run: async (client, message, args) => {

        const user   = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
        const member = message.guild.members.cache.get(user.id);

        const sep  = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
        const thin = () => new SeparatorBuilder().setDivider(false).setSpacing(SeparatorSpacingSize.Small);

        // ================= NOT IN GUILD =================
        if (!member) {
            return message.channel.send({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x2b2d31)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`## 👤 ${user.username}`)
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `${STAR} **Thông tin cơ bản**\n\n` +
                                `${ARROW} Đề cập: <@${user.id}>\n` +
                                `${ARROW} ID: \`${user.id}\`\n` +
                                `${ARROW} Bot: ${user.bot ? "Có" : "Không"}\n` +
                                `${ARROW} Tạo: <t:${Math.round(user.createdTimestamp / 1000)}:F>`
                            )
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `-# ❌ Không ở trong server • ${message.author.tag}`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
                allowedMentions: { users: [] },
            });
        }

        // ================= DATA =================
        const perms = member.permissions.toArray();

        let acknowledgement;
        if (member.id === message.guild.ownerId) acknowledgement = "👑 Chủ server";
        else if (perms.includes("Administrator")) acknowledgement = "⚡ Quản trị viên";
        else if (perms.includes("KickMembers") || perms.includes("BanMembers")) acknowledgement = "🛡️ Moderator";
        else acknowledgement = "👤 Thành viên";

        const memberRoles = [...member.roles.cache.values()]
            .sort((a, b) => b.rawPosition - a.rawPosition)
            .filter(r => r.id !== message.guild.id);

        const rolesDisplay = memberRoles.length === 0
            ? "Không có"
            : memberRoles.length > 25
                ? memberRoles.slice(0, 25).map(r => `<@&${r.id}>`).join(", ") + ` +${memberRoles.length - 25}`
                : memberRoles.map(r => `<@&${r.id}>`).join(", ");

        const permDisplay = perms
            .map(p => `\`${p}\``)
            .join(", ") || "Không có";

        // ================= MAIN UI =================
        const buildMain = () =>
            new ContainerBuilder()
                .setAccentColor(0x2b2d31)

                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## <:cat_robot:1492453448938033223> ${member.user.username}`
                    )
                )

                .addSeparatorComponents(sep())

                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${STAR} **Thông tin chung**\n\n` +
                        `${ARROW} Tag: <@${member.id}>\n` +
                        `${ARROW} ID: \`${member.id}\`\n` +
                        `${ARROW} Bot: ${member.user.bot ? "Có" : "Không"}\n` +
                        `${ARROW} Tạo: <t:${Math.round(member.user.createdTimestamp / 1000)}:F>\n` +
                        `${ARROW} Tham gia: <t:${Math.round(member.joinedTimestamp / 1000)}:F>`
                    )
                )

                .addSeparatorComponents(sep())

                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `📌 **Vai trò [${memberRoles.length}]**\n\n` +
                        `${ARROW} Cao nhất: <@&${member.roles.highest.id}>\n\n` +
                        rolesDisplay
                    )
                )

                .addSeparatorComponents(sep())

                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `🏷️ **Vai trò hệ thống**\n${acknowledgement}`
                    )
                )

                .addSeparatorComponents(sep())

                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `-# 📩 Yêu cầu bởi ${message.author.tag}`
                    )
                )

                .addActionRowComponents(row =>
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId("ui_perms")
                            .setLabel("Xem quyền hạn")
                            .setEmoji("1492132251608158338")
                            .setStyle(ButtonStyle.Secondary)
                    )
                );

        // ================= PERMS UI =================
        const buildPerms = () =>
            new ContainerBuilder()
                .setAccentColor(0x2b2d31)

                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## 🔐 ${member.user.username} • Quyền hạn`
                    )
                )

                .addSeparatorComponents(sep())

                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(permDisplay)
                )

                .addSeparatorComponents(sep())

                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `-# 📩 Yêu cầu bởi ${message.author.tag}`
                    )
                )

                .addActionRowComponents(row =>
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId("ui_back")
                            .setLabel("Quay lại")
                            .setStyle(ButtonStyle.Secondary)
                    )
                );

        // ================= SEND =================
        const msg = await message.channel.send({
            components: [buildMain()],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { roles: [], users: [] },
        });

        const collector = msg.createMessageComponentCollector({ time: 300000 });

        collector.on("collect", async (i) => {
            if (i.user.id !== message.author.id) {
                return i.reply({
                    content: "❌ Không phải menu của bạn",
                    ephemeral: true
                });
            }

            if (i.customId === "ui_perms") {
                return i.update({
                    components: [buildPerms()],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            if (i.customId === "ui_back") {
                return i.update({
                    components: [buildMain()],
                    flags: MessageFlags.IsComponentsV2
                });
            }
        });
    },
};