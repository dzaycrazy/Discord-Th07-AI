
const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ButtonBuilder,
    SeparatorSpacingSize,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");

module.exports = {
    name: "serverinfo",
    aliases: ["si"],
    category: "util",

    run: async (client, message) => {
        const guild = message.guild;
        const owner = await guild.fetchOwner().catch(() => null);

        const emoji = client.emoji || {};
        const sep = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);

        const boostUpload = { 0: "8 MB", 1: "8 MB", 2: "50 MB", 3: "100 MB" };

        // ⚠️ FIX lag roles (giới hạn hiển thị)
        const roles = guild.roles.cache
            .sort((a, b) => b.position - a.position)
            .filter(r => r.id !== guild.id);

        const rolesDisplay = roles.size === 0
            ? "Không có"
            : roles.size > 40
                ? roles.map(r => `<@&${r.id}>`).slice(0, 40).join(", ") + ` +${roles.size - 40} nữa`
                : roles.map(r => `<@&${r.id}>`).join(", ");

        // ================= MAIN =================
        const buildMain = () =>
            new ContainerBuilder()
                .setAccentColor(0x2b2d31)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# <:discord:1492466006201864383> ${guild.name}`
                    )
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**<:content:1492082065699508414> Thông tin chung**\n` +
                        `• ID: \`${guild.id}\`\n` +
                        `• Chủ sở hữu: ${owner ? owner.user.tag : "Không rõ"}\n` +
                        `• Đề cập đến ${owner ? `<@${owner.user.id}>` : "Không rõ"}\n` +
                        `• Thành viên: \`${guild.memberCount}\`\n` +
                        `• Tạo lúc: <t:${Math.floor(guild.createdTimestamp / 1000)}:F>`
                    )
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**<:search:1492132251608158338> Boost**\n` +
                        `• Level: \`${guild.premiumTier}\`\n` +
                        `• Boost: \`${guild.premiumSubscriptionCount}\`\n` +
                        `• Upload: \`${boostUpload[guild.premiumTier] ?? "8 MB"}\``
                    )
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `-# <:ass:1492125965688635532> Yêu cầu bởi ${message.author.tag}`
                    )
                )
                .addActionRowComponents(row =>
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId("si_roles")
                            .setLabel("Vai trò")
                            .setEmoji("1492466019157938308")
                            .setStyle(ButtonStyle.Secondary),

                        new ButtonBuilder()
                            .setCustomId("si_avatar")
                            .setLabel("Icon")
                            .setEmoji("1492126467574992936")
                            .setStyle(ButtonStyle.Secondary),

                        new ButtonBuilder()
                            .setCustomId("si_banner")
                            .setLabel("Banner")
                            .setEmoji("1492125965688635532")
                            .setStyle(ButtonStyle.Secondary)
                    )
                );

        // ================= ROLES =================
        const buildRoles = () =>
            new ContainerBuilder()
                .setAccentColor(0x2b2d31)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# <:rule:1492466019157938308> Vai trò [${roles.size}]`
                    )
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(rolesDisplay)
                )
                .addSeparatorComponents(sep())
                .addActionRowComponents(row =>
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId("si_back")
                            .setLabel("Quay lại")
                            .setEmoji("1487795549770879107")
                            .setStyle(ButtonStyle.Secondary)
                    )
                );

        // ================= AVATAR =================
        const buildAvatar = () => {
            const iconURL = guild.iconURL({ size: 1024, extension: "png" });

            return new ContainerBuilder()
                .setAccentColor(0x2b2d31)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`# <:cat_home:1492453453719666709> Icon Server`)
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        iconURL
                            ? `[Xem ảnh](${iconURL})`
                            : "Server không có icon"
                    )
                )
                .addSeparatorComponents(sep())
                .addActionRowComponents(row =>
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId("si_back")
                            .setLabel("Quay lại")
                            .setEmoji("1487795549770879107")
                            .setStyle(ButtonStyle.Secondary)
                    )
                );
        };

        // ================= BANNER =================
        const buildBanner = () => {
            const bannerURL = guild.bannerURL({ size: 1024, extension: "png" });

            return new ContainerBuilder()
                .setAccentColor(0x2b2d31)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`# <:search:1492132251608158338> Banner Server`)
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        bannerURL
                            ? `[Xem banner](${bannerURL})`
                            : "Server không có banner"
                    )
                )
                .addSeparatorComponents(sep())
                .addActionRowComponents(row =>
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId("si_back")
                            .setLabel("Quay lại")
                            .setEmoji("1487795549770879107")
                            .setStyle(ButtonStyle.Secondary)
                    )
                );
        };

        // ================= SEND =================
        const msg = await message.channel.send({
            components: [buildMain()],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { roles: [] },
        });

        const collector = msg.createMessageComponentCollector({ time: 300000 });

        collector.on("collect", async (i) => {
            if (i.user.id !== message.author.id) {
                return i.reply({
                    content: `${emoji.cross || "<:disabled:1487783250452545616>"} Không phải menu của bạn`,
                    ephemeral: true
                });
            }

            if (i.customId === "si_roles") {
                return i.update({ components: [buildRoles()], flags: MessageFlags.IsComponentsV2 });
            }

            if (i.customId === "si_avatar") {
                return i.update({ components: [buildAvatar()], flags: MessageFlags.IsComponentsV2 });
            }

            if (i.customId === "si_banner") {
                return i.update({ components: [buildBanner()], flags: MessageFlags.IsComponentsV2 });
            }

            if (i.customId === "si_back") {
                return i.update({ components: [buildMain()], flags: MessageFlags.IsComponentsV2 });
            }
        });
    },
};