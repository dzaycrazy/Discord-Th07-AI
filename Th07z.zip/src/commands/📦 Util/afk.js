const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    MessageFlags
} = require("discord.js");

module.exports = {
    name: "afk",
    description: "Đặt trạng thái AFK",
    cooldown: 3,

    run: async (client, message, args) => {
        const reason = args.join(" ") || "Hiện tại tôi đang AFK nên chưa thể trả lời ngay được. Nếu bạn có việc quan trọng thì cứ để lại tin nhắn, tôi sẽ xem và phản hồi sớm nhất có thể khi quay lại. Đừng lo nếu thấy tôi im lặng, vì chỉ là tạm thời thôi. Cảm ơn vì đã chờ và thông cảm nhé!";

        // 🔹 Lưu DB
        await client.db.set(`afk_${message.guild.id}_${message.author.id}`, {
            reason,
            time: Date.now()
        });

        // 🔹 Đổi nickname
        try {
            if (message.member && message.member.manageable) {

                let name = message.member.nickname || message.author.username;

                // ❌ xoá [AFK] cũ nếu có
                name = name.replace(/^\[AFK\]\s*/i, "");

                // ❌ giới hạn 32 ký tự của Discord
                let newName = `[AFK] ${name}`;
                if (newName.length > 32) {
                    newName = newName.slice(0, 32);
                }

                await message.member.setNickname(newName);
            }
        } catch (err) {
            // có thể log nếu cần
            // console.log(err);
        }

        // 🧠 thời gian
        const time = `<t:${Math.floor(Date.now() / 1000)}:R>`;

        // 🎨 UI
        const container = new ContainerBuilder()
            .setAccentColor(0x26272F)
            .addTextDisplayComponents(
                new TextDisplayBuilder()
                    .setContent(`### 💤 ${message.author.tag} đã chuyển sang AFK`)
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setSpacing(1)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `<:arror:1487785740673745096> <:lydo:1489896447099801642> » ${reason}\n` +
                    `<:arror:1487785740673745096> <:clock:1489894867122262036> Thời gian » ${time}`
                )
            );

        return message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};