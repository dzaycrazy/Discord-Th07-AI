const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ButtonBuilder,
    SeparatorSpacingSize,
    ButtonStyle,
    MessageFlags,
    version: djsVersion,
} = require("discord.js");

const os = require("os");

module.exports = {
    name: "stats",
    aliases: ["botstats", "botstatus", "st"],
    description: "Xem thống kê bot",

    run: async (client, message) => {

        const botGuilds   = client.guilds.cache.size;
        const usersCount  = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);
        const botChannels = client.channels.cache.size;
        const commands    = client.commands?.size ?? 0;
        const botPing     = client.ws.ping.toFixed(0);
        const nodeVersion = process.version;

        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);

        const uptimeStr =
            days > 0 ? `${days}d ${hours}h ${minutes}m`
            : hours > 0 ? `${hours}h ${minutes}m`
            : `${minutes}m`;

        // DB LATENCY (fake / safe)
        let dbLatency = 0;
        try {
            const start = process.hrtime.bigint();
            client.lmdb?.get("pingTest");
            const end = process.hrtime.bigint();
            dbLatency = Number(end - start) / 1e6;
        } catch {}

        const clusterId = client.cluster?.id ?? 0;
        const totalShards = client.cluster?.info?.TOTAL_SHARDS ?? client.options.shardCount ?? 1;
        const shardId = message.guild?.shardId ?? 0;

        const sep = () =>
            new SeparatorBuilder()
                .setDivider(true)
                .setSpacing(SeparatorSpacingSize.Small);

        const container = new ContainerBuilder()
            .setAccentColor(0x26272f)

            // ================= HEADER =================
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## <:cat_robot:1492453448938033223> ${client.user.username} Bảng điều khiển`
                )
            )

            .addSeparatorComponents(sep())

            // ================= OVERVIEW =================
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `### <:discord:1492466006201864383> Tổng quan\n` +
                    `<:arror:1487785740673745096> Máy chủ: \`${botGuilds.toLocaleString()}\`\n` +
                    `<:arror:1487785740673745096> Tổng Người dùng: \`${usersCount.toLocaleString()}\`\n` +
                    `<:arror:1487785740673745096> Tổng số Kênh: \`${botChannels.toLocaleString()}\`\n` +
                    `<:arror:1487785740673745096> Tổng số lệnh: \`${commands}\``
                )
            )

            .addSeparatorComponents(sep())

            // ================= PERFORMANCE =================
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `### <:search:1492132251608158338> Hiệu suất\n` +
                    `<:arror:1487785740673745096> WebSocket: \`${botPing}ms\`\n` +
                    `<:arror:1487785740673745096> Cơ sở dữ liệu: \`${dbLatency.toFixed(2)}ms\`\n` +
                    `<:arror:1487785740673745096> Thời gian hoạt động: \`${uptimeStr}\``
                )
            )

            .addSeparatorComponents(sep())

            // ================= SYSTEM =================
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `### <:uptime:1488165491494092901> Hệ thống\n` +
                    `<:arror:1487785740673745096> Node.js: \`${nodeVersion}\`\n` +
                    `<:arror:1487785740673745096> Discord.js: \`v${djsVersion}\`\n` +
                    `<:arror:1487785740673745096> Hệ điều hành: \`${os.platform()}\``
                )
            )

            .addSeparatorComponents(sep())

            // ================= SHARD =================
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `### <:cat_robot:1492453448938033223> Sharding\n` +
                    `<:arror:1487785740673745096> Shard: \`${shardId + 1}/${totalShards}\`\n` +
                    `<:arror:1487785740673745096> Cluster: \`${clusterId}\``
                )
            )

            .addSeparatorComponents(sep())

            // ================= FOOTER =================
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `-# <:andanh:1491797990015238254> Theo yêu cầu của ${message.author.tag}`
                )
            )

            // ================= BUTTONS =================
            .addActionRowComponents((row) =>
                row.addComponents(
                    new ButtonBuilder()
                        .setLabel("Mời Bot")
                        .setEmoji("1492084965494751313")
                        .setURL("https://tinyurl.com/Th07z")
                        .setStyle(ButtonStyle.Link),

                    new ButtonBuilder()
                        .setLabel("Máy chủ hỗ trợ")
                        .setEmoji("1492466006201864383")
                        .setURL("https://discord.gg/BW6NbrKdyF")
                        .setStyle(ButtonStyle.Link)
                )
            );

        return message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
        });
    },
};
