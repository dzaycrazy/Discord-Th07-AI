const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'prefix',
    aliases: ['setprefix', 'set-prefix'],
    description: "Xem hoặc thay đổi tiền tố máy chủ",
    category: 'util',
    cooldown: 3,
    run: async (client, message, args, prefix) => {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn cần quyền \`QUẢN LÝ MÁY CHỦ\` để thay đổi tiền tố máy chủ.`)]
            });
        }

        if (!args[0]) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setDescription(`Tiền tố của tôi cho máy chủ là: \`${prefix}\``)
                    .setColor('#26272F')]
            });
        }

        if (args[0].length > 3) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn không thể đặt tiền tố dài hơn ba ký tự.`)]
            });
        }

        if (args[1]) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} | Bạn không thể đặt đối số thứ 2 làm tiền tố`)]
            });
        }

        if (args[0] === client.config.prefix) {
            await client.db.delete(`prefix_${message.guild.id}`);
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} | Đã đặt lại tiền tố máy chủ thành công thành - \`${client.config.prefix}\``)]
            });
        }

        await client.db.set(`prefix_${message.guild.id}`, args[0]);
        return message.channel.send({
            embeds: [new EmbedBuilder()
                .setColor('#26272F')
                .setDescription(`${client.emoji.tick} | Tiền tố máy chủ đã được đặt thành - \`${args[0]}\``)]
        });
    }
}
