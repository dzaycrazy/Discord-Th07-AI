const {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ContainerBuilder,
    TextDisplayBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require("discord.js");

module.exports = {
    name: 'avatar',
    aliases: ['av'],
    description: "Avatar nâng cao",
    category: 'util',
    cooldown: 3,

    run: async (client, message, args) => {

        const emoji = client.emoji || {};
        let user, member;

        // ================= GET USER =================
        if (message.mentions.users.size) {
            user = message.mentions.users.first();
            member = message.mentions.members.first();
        } else if (args[0]) {
            user = await client.users.fetch(args[0]).catch(() => null);
            member = user ? await message.guild.members.fetch(user.id).catch(() => null) : null;
        } else {
            user = message.author;
            member = message.member;
        }

        if (!user) return message.reply("Không tìm thấy người dùng.");

        // ================= BADGE =================
        let badge = "<:andanh:1491797990015238254> Thành viên";
        if (user.bot) badge = "<:cat_robot:1492453448938033223> Bot";
        else if (user.id === message.guild.ownerId) badge = "<:skull:1492126467574992936> Chủ";
        else if (member?.permissions.has("Administrator")) badge = "<:hoanghot:1492128357817651450> Quản trị viên";

        // ================= AVATAR =================
        const avatarOptions = (hash) => ({
            extension: hash?.startsWith('a_') ? 'gif' : 'png',
            size: 4096
        });

        const globalAvatar = user.displayAvatarURL(avatarOptions(user.avatar));
        const guildAvatar = member?.avatar
            ? member.displayAvatarURL(avatarOptions(member.avatar))
            : null;

        // ================= BANNER =================
        let bannerURL = null;
        try {
            const fetchedUser = await user.fetch();
            bannerURL = fetchedUser.bannerURL({ size: 4096, extension: "png" });
        } catch {}

        // ================= COLOR AUTO =================
        const color = member?.displayHexColor !== "#000000"
            ? member.displayHexColor
            : "#2b2d31";

        const sep = () =>
            new SeparatorBuilder()
                .setDivider(true)
                .setSpacing(SeparatorSpacingSize.Small);

        // ================= UI =================
        const buildContainer = (imageUrl, type = "global") => {

            return new ContainerBuilder()
                .setAccentColor(parseInt(color.replace("#", ""), 16))

                // TITLE
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# <:speaker:1492466016289030194> Avatar ${type === "guild" ? "Server" : "Toàn cầu"}`
                    )
                )

                .addSeparatorComponents(sep())

                // INFO
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**<:andanh:1491797990015238254> Người dùng:** ${user.tag}\n` +
                        `**<:idea:1492084965494751313> ID:** \`${user.id}\`\n` +
                        `**<:tags:1492084967965069322> Loại:** ${type === "guild" ? "Server Avatar" : "Global Avatar"}\n` +
                        `**<:cat_star:1492453457158869113> Rank:** ${badge}\n` +
                        `**<:ass:1492125965688635532> Tạo:** <t:${Math.floor(user.createdTimestamp / 1000)}:F>`
                    )
                )

                .addSeparatorComponents(sep())

                // IMAGE
                .addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems(
                        new MediaGalleryItemBuilder().setURL(imageUrl)
                    )
                )

                .addSeparatorComponents(sep())

                // LINK + DOWNLOAD
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `<:search:1492132251608158338> [xᴇᴍ ảɴʜ](${imageUrl}) • <:search:1492132251608158338> [ᴅᴏᴡɴʟᴏᴀᴅ](${imageUrl})`
                    )
                )

                // BANNER (nếu có)
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        bannerURL
                            ? `<:cat_home:1492453453719666709> [xᴇᴍ ʙᴀɴɴᴇʀ](${bannerURL})`
                            : "<:cat_home:1492453453719666709> Không có banner"
                    )
                )

                .addSeparatorComponents(sep())

                // BUTTONS
                .addActionRowComponents(row =>
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId('avatar_global')
                            .setLabel('Toàn máy chủ')
                            .setEmoji("1492125965688635532")
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(type === "global"),

                        new ButtonBuilder()
                            .setCustomId('avatar_guild')
                            .setLabel('Máy chủ')
                            .setEmoji("1492466006201864383")
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(type === "guild" || !guildAvatar),

                        new ButtonBuilder()
                            .setStyle(ButtonStyle.Link)
                            .setLabel("Tải ảnh")
                            .setEmoji("1492132251608158338")
                            .setURL(imageUrl)
                    )
                );
        };

        // ================= SEND =================
        const msg = await message.reply({
            components: [buildContainer(globalAvatar, "global")],
            flags: MessageFlags.IsComponentsV2
        });

        const collector = msg.createMessageComponentCollector({
            filter: i => {
                if (i.user.id !== message.author.id) {
                    i.reply({
                        content: `${emoji.cross || "<:disabled:1487783250452545616>"} Không phải menu của bạn`,
                        ephemeral: true
                    });
                    return false;
                }
                return true;
            },
            time: 300000
        });

        collector.on('collect', async interaction => {

            if (interaction.customId === 'avatar_global') {
                return interaction.update({
                    components: [buildContainer(globalAvatar, "global")],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            if (interaction.customId === 'avatar_guild' && guildAvatar) {
                return interaction.update({
                    components: [buildContainer(guildAvatar, "guild")],
                    flags: MessageFlags.IsComponentsV2
                });
            }
        });
    }
};
