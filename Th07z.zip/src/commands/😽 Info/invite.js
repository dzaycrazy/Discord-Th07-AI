const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    name: "invite",
    aliases: ["inv", "botinvite"],
    description: "Lấy liên kết mời bot và máy chủ hỗ trợ",
    category: "info",
    cooldown: 3,
    run: async (client, message, args, prefix) => {

        const inviteURL = "https://tinyurl.com/Th07z";
        const supportURL = "https://discord.gg/BW6NbrKdyF";

        const embed = new EmbedBuilder()
            .setColor('#26272F')

            // 🔥 THUMBNAIL (avatar bot)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }))

            // 🔥 IMAGE (banner đẹp - m có thể đổi link)
            .setImage("https://cdn.discordapp.com/attachments/1490373725093367968/1492473710714818610/image0.gif?ex=69db75f5&is=69da2475&hm=f00534235bf40b8507ba1a1541c76eafd3f5cd3857bac997dff9e14dfc570205&") // đổi link nếu muốn

            .setTitle("<:idea:1492084965494751313> Mời bot & hỗ trợ")
            .setDescription(
                `<:speaker:1492466016289030194> **Cảm ơn bạn đã chọn ${client.user.username}!**\n\n` +
                `• Nhấn nút bên dưới để mời bot\n` +
                `• Hoặc tham gia server hỗ trợ\n\n` +
                `<:cat_star:1492453457158869113> Bot giúp quản lý & bảo vệ server của bạn`
            )
            .setFooter({
                text: `${client.user.username} • Invite System`,
                iconURL: client.user.displayAvatarURL()
            });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel("Mời tôi")
                .setStyle(ButtonStyle.Link)
                .setURL(inviteURL)
                .setEmoji("<:idea:1492084965494751313>"),

            new ButtonBuilder()
                .setLabel("Máy chủ hỗ trợ")
                .setStyle(ButtonStyle.Link)
                .setURL(supportURL)
                .setEmoji("<:discord:1492466006201864383>")
        );

        return message.channel.send({
            embeds: [embed],
            components: [row]
        });
    }
};
