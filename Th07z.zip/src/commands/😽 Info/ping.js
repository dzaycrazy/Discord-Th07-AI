const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require("discord.js");

module.exports = {
  name: "ping",
  aliases: ["latency"],
  category: "info",

  run: async (client, message) => {
    const websocketPing = client.ws.ping;

    const sep = () =>
      new SeparatorBuilder()
        .setDivider(true)
        .setSpacing(SeparatorSpacingSize.Small);

    // =========================
    // ⏳ LOADING UI
    // =========================
    const msg = await message.channel.send({
      components: [
        new ContainerBuilder()
          .setAccentColor(0x26272f)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              "<:loading:1488406665467531294> **Đang phân tích hệ thống...**"
            )
          ),
      ],
      flags: MessageFlags.IsComponentsV2,
    });

    const shardId = client.cluster?.id ?? 0;
    const totalShards = client.cluster?.count ?? 1;

    const dbPing = Math.floor(Math.random() * 5); // giả lập DB (m có thể thay real DB)

    // =========================
    // 📊 RESULT UI
    // =========================
    return msg.edit({
      components: [
        new ContainerBuilder()
          .setAccentColor(0x26272f)

          // TITLE
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              "## <:skull:1492126467574992936> Bảng điều khiển Ping hệ thống"
            )
          )

          .addSeparatorComponents(sep())

          // PING INFO
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `<:hoanghot:1492128357817651450> **Độ trễ socket:** \`${Math.round(websocketPing)}ms\`\n` +
              `<:uptime:1488165491494092901> **Độ trễ cơ sở dữ liệu:** \`${dbPing}ms\`\n` +
              `<:cat_home:1492453453719666709> **Trạng thái API:** \`Stable\``
            )
          )

          .addSeparatorComponents(sep())

          // SHARD INFO
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `<:cleaner:1488410427531591790> Shard: \`${shardId}/${totalShards}\`\n` +
              `<:clock:1489894867122262036> Đã cập nhật: <t:${Math.floor(Date.now() / 1000)}:R>`
            )
          )

          .addSeparatorComponents(sep())

          // FOOTER SMALL
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              "-# Zay System • optimized latency monitor"
            )
          ),
      ],
      flags: MessageFlags.IsComponentsV2,
    });
  },
};
