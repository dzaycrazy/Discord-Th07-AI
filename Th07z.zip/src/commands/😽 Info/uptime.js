const moment = require('moment');
require('moment-duration-format');
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const os = require('os');
const https = require('https');
const pidusage = require('pidusage');
const fs = require('fs');

const DATA_FILE = './uptime.json';

let saved = {};
if (fs.existsSync(DATA_FILE)) {
    saved = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function save() {
    fs.writeFileSync(DATA_FILE, JSON.stringify(saved, null, 2));
}

// ===== CACHE =====
let cachedHost = null;
let cachedPublicIP = null;
let vnPingCache = "Đang đo đường truyền....";
let usageCache = { memory: 0, cpu: 0 };
let animationStep = 0;

// ===== HOST + PUBLIC IP =====
function getHostProvider() {
    if (cachedHost && cachedPublicIP) {
        return Promise.resolve({
            host: cachedHost,
            ip: cachedPublicIP
        });
    }

    return new Promise(resolve => {
        https.get("https://ipinfo.io/json", res => {
            let data = "";
            res.on("data", c => data += c);
            res.on("end", () => {
                try {
                    const json = JSON.parse(data);

                    cachedPublicIP = json.ip || "Unknown";
                    cachedHost = json.org || "Không rõ";

                    resolve({
                        host: cachedHost,
                        ip: cachedPublicIP
                    });

                } catch {
                    resolve({ host: "Không rõ", ip: "Unknown" });
                }
            });
        }).on("error", () => resolve({ host: "Không rõ", ip: "Unknown" }));
    });
}

// ===== PING =====
function getPingVN() {
    return new Promise(resolve => {
        const start = Date.now();
        https.get("https://www.google.com.vn", () => resolve(Date.now() - start))
            .on("error", () => resolve("Lỗi"));
    });
}

// ===== ANIMATION PING =====
function animatedPing(ms) {
    if (ms === "Lỗi") return "[⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛]";

    const total = 14;
    let color;

    if (ms < 100) color = "🟩";
    else if (ms < 300) color = "🟨";
    else if (ms < 700) color = "🟧";
    else if (ms < 1500) color = "🟥";
    else color = "⬛";

    let bar = Array(total).fill(color);

    // animation chạy
    animationStep = (animationStep + 1) % total;
    bar[animationStep] = "⬜";

    return `[${bar.join("")}]`;
}

// ===== LOOP =====
async function startLoop(client, guildId, data) {

    const msg = data.message;
    const guild = msg.guild;

    const owner = await guild.members.fetch(guild.ownerId).catch(() => null);
    const ownerTag = owner ? owner.user.toString() : "Không xác định";

    const highestRole = owner?.roles.highest;
    const lowestRole = owner?.roles.cache
        .filter(r => r.id !== guild.id)
        .sort((a, b) => a.position - b.position)
        .first();

    const members = await guild.members.fetch();
    const totalMembers = members.size;
    const totalBots = members.filter(m => m.user.bot).size;

    const localIP = Object.values(os.networkInterfaces())
        .flat()
        .find(i => i && i.family === 'IPv4' && !i.internal)?.address || "Unknown";

    const botCreatedText = moment(client.user.createdTimestamp).utcOffset(7).format('HH:mm DD/MM/YYYY');
    const botJoinText = moment(guild.members.me.joinedTimestamp).utcOffset(7).format('HH:mm DD/MM/YYYY');
    const guildCreatedText = moment(guild.createdTimestamp).utcOffset(7).format('HH:mm DD/MM/YYYY');

    const hostData = await getHostProvider();

    // ===== CACHE UPDATE =====
    setInterval(async () => {
        vnPingCache = await getPingVN();
    }, 1500);

    setInterval(async () => {
        usageCache = await pidusage(process.pid);
    }, 3000);

    function createLoopBar() {
        const total = 25;
        const step = Math.floor((Date.now() / 500) % total);
        return Array.from({ length: total }, (_, i) => (i === step ? "█" : "░")).join('');
    }

    function createProgressBar(uptimeMs) {
        const totalBars = 25;
        const percent = Math.min((uptimeMs / (1000 * 60 * 60)) * 100, 100);
        const filled = Math.round((percent / 100) * totalBars);

        return {
            bar: "█".repeat(filled) + "░".repeat(totalBars - filled),
            percent: percent.toFixed(1)
        };
    }

    // ===== LOOP CHÍNH =====
    const interval = setInterval(() => {

        if (!msg || !msg.editable) return clearInterval(interval);

        const time = moment.duration(client.uptime).format('H[ giờ], m[ phút], s[ giây]');
        const wsPing = client.ws.ping;

        const vnPing = vnPingCache;
        const used = usageCache.memory / 1024 / 1024 || 0;
        const cpu = usageCache.cpu ? usageCache.cpu.toFixed(2) : "0.00";

        const loopBar = createLoopBar();
        const progress = createProgressBar(client.uptime);

        const vnTime = moment().utcOffset(7).format('HH:mm D/M/YYYY'); // thời gian Việt Nam

        const embed = new EmbedBuilder()
            .setColor('#26272F')
            .setDescription(
`<:uptime:1488165491494092901> **THÔNG TIN BOT**

<:arror:1487785740673745096> **HỆ THỐNG**
\`   ├─ IPv4 Nội bộ » ${localIP}
   ├─ IPv4 Public » ${hostData.ip}
   ├─ RAM » ${used.toFixed(1)}MB
   └─ CPU » ${cpu}%\`

<:arror:1487785740673745096> **THỜI GIAN**
\`   ├─ Bot tạo » ${botCreatedText}
   ├─ Join server » ${botJoinText}
   └─ Server tạo » ${guildCreatedText}\`

<:arror:1487785740673745096> **PING**
\`   ├─ Discord » ${wsPing}ms
   ├─ ${animatedPing(wsPing)}
   ├─ Node » ${vnPing}ms
   └─ ${animatedPing(vnPing)}\`

<:arror:1487785740673745096> **MÁY CHỦ**
\`   ├─ Máy chủ »\` **${guild.name}**
\`   ├─ Owner »\` **${ownerTag}**
\`   ├─ Role cao nhất »\` **${highestRole ? highestRole.toString() : "Không"}**
\`   ├─ Role thấp nhất »\` **${lowestRole ? lowestRole.toString() : "Không"}**
\`   ├─ Thành viên »\` **${totalMembers}**
\`   └─ Bot »\` **${totalBots}**

<:clock:1489894867122262036> **UPTIME**
\`   ├─ ${time}
   ├─ Thời gian VN » ${vnTime}
   ├─ Đơn vị nhà cung cấp
   ├─ ${hostData.host}
   ├─ ${loopBar}
   └─ ${progress.bar} (${progress.percent}%)\`
`
            );

        msg.edit({ embeds: [embed] }).catch(() => clearInterval(interval));

    }, 900);
}

// ===== COMMAND =====
module.exports = {
    name: 'uptime',
    aliases: ['upt'],
    cooldown: 3,
    premium: true,
    startLoop,

    run: async (client, message) => {

        client.activeUptime = client.activeUptime || new Map();
        const map = client.activeUptime;

        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.channel.send("<:disabled:1487783250452545616> cần quyền Admin!");
        }

        const guild = message.guild;

        if (map.has(guild.id)) {
            return message.channel.send({
                content: `<:uptime:1488165491494092901> Đang chạy rồi\n » ${map.get(guild.id).message.url}`
            });
        }

        let msg;

        if (saved[guild.id]) {
            try {
                const ch = await client.channels.fetch(saved[guild.id].channelId);
                msg = await ch.messages.fetch(saved[guild.id].messageId);
            } catch {}
        }

        // Nếu chưa có msg, gửi **embed trống** tạm thời
        if (!msg) {
            const embed = new EmbedBuilder()
                .setColor('#26272F')
                .setDescription("<:loading:1488406665467531294> Đang load UPTIME...");
            msg = await message.channel.send({ embeds: [embed] });
        }

        map.set(guild.id, { message: msg });

        saved[guild.id] = {
            channelId: msg.channel.id,
            messageId: msg.id
        };
        save();

        // ✅ Bắt đầu loop trực tiếp trên message hiện tại
        startLoop(client, guild.id, map.get(guild.id));
    }
};