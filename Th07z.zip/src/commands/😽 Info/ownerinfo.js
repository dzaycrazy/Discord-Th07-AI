const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} = require("discord.js");

const fs = require("fs");
const path = require("path");

// ✅ FIX PATH
const configPath = path.join(__dirname, "../../config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf8"));

module.exports = {
    name: "ownerifo",
    aliases: ["ownerinfo", "owner", "infoowner", "Zay", "zay"],
    description: "Thông tin chủ bot",
    category: "info",
    cooldown: 3,

    run: async (client, message) => {

        const ownerIDs = config.ownerID || [];

        const owners = [];

        for (const id of ownerIDs) {
            const user = await client.users.fetch(id).catch(() => null);
            if (user) owners.push(user);
        }

        const ownerText = owners.length
            ? owners.map((o, i) => `**${i + 1}. ${o.tag}** (\`${o.id}\`)`).join("\n")
            : "Không tìm thấy owner";

        const embed = new EmbedBuilder()
            .setColor("#26272F")
            .setTitle("<:speaker:1492466016289030194> Thông tin chủ sở hữu")
            .setThumbnail(client.user.displayAvatarURL())
            .setDescription(
                `<:arror:1487785740673745096> **Tên bot \n${client.user.username} #- (${client.user.id})\n\n` +
                `**<:hoanghot:1492128357817651450> Chủ sở hữu:**\n${ownerText}\n\n` +

                `<:search:1492132251608158338> **Liên kết mạng xã hội:**\n` +
                `<:youtube:1492466008823173120> YouTube: [ʏᴏᴜᴛᴜʙᴇ](${config.social?.youtube || "Không có"})\n` +
                `<:tiktok:1492466011213922466> TikTok: [ᴛɪᴋᴛᴏᴋ](${config.social?.tiktok || "Không có"})\n` +
                `<:facebook:1492466013479108748> Facebook: [ғᴀᴄᴇʙᴏᴏᴋ](${config.social?.facebook || "Không có"})\n` +
                `<:discord:1492466006201864383> Discord: [ᴅɪꜱᴄᴏʀᴅ](${config.social?.discord || "Không có"})`
            )
            .setFooter({ text: "Hệ thống bảng điều khiển chủ sở hữu" });

        const row = new ActionRowBuilder().addComponents(
            ...owners.map(owner =>
                new ButtonBuilder()
                    .setLabel(owner.username)
                    .setStyle(ButtonStyle.Link)
                    .setURL(`https://discord.com/users/${owner.id}`)
                    .setEmoji("1492132251608158338")
            )
        );

        return message.channel.send({
            embeds: [embed],
            components: owners.length ? [row] : []
        });
    }
};