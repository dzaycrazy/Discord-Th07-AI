const fs = require("fs");
const path = require("path");
const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ButtonBuilder,
    StringSelectMenuBuilder,
    SeparatorSpacingSize,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");

const ARROW = "<:arror:1487785740673745096>";

module.exports = {
    name: "help",
    aliases: ["h", "commands", "cmds"],
    description: "Xem tất cả các lệnh có sẵn",
    category: "info",
    cooldown: 3,

    run: async (client, message) => {
        let prefix = client.config.prefix;
        const prefixData = await client.db.get(`prefix_${message.guild.id}`);
        if (prefixData) prefix = prefixData;

        const emoji = client.emoji; // 🔥 dùng emoji custom của m

        const commandsPath = path.join(__dirname, "..");
        const categories = fs.readdirSync(commandsPath)
            .filter(d => fs.statSync(path.join(commandsPath, d)).isDirectory())
            .filter(c => !["owner", "subscription"].includes(c.toLowerCase()));

        const getCommands = (cat) => {
            const dir = path.join(commandsPath, cat);
            if (!fs.existsSync(dir)) return [];
            return fs.readdirSync(dir)
                .filter(f => f.endsWith(".js"))
                .map(f => require(path.join(dir, f)))
                .filter(c => c?.name);
        };

        const capitalize = (s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();

        const sep  = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
        const thin = () => new SeparatorBuilder().setDivider(false).setSpacing(SeparatorSpacingSize.Small);

        const makeDropdown = (selected = null) =>
            new StringSelectMenuBuilder()
                .setCustomId("help-category")
                .setPlaceholder(`${selected ? capitalize(selected) : "Chọn danh mục"}`)
                .addOptions(
                    categories.map((cat) => ({
                        label: capitalize(cat),
                        description: `Xem lệnh trong ${cat}`,
                        value: cat,
                        default: cat === selected,
                    }))
                );

        const makeNavButtons = (homeDisabled) =>
            new ButtonBuilder()
                .setCustomId("home")
                .setLabel("Trang chủ")
                .setEmoji("1492453453719666709")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(homeDisabled);

        const makeListButton = (listDisabled) =>
            new ButtonBuilder()
                .setCustomId("list")
                .setLabel("Tất cả lệnh")
                .setEmoji("1492466019157938308")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(listDisabled);

        // ================= HOME =================
        const buildHome = () =>
            new ContainerBuilder()
                .setAccentColor(0x2b2d31)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# <:cat_robot:1492453448938033223> ${client.user.username}\n` +
                        `-# Prefix: \`${prefix}\` • ${categories.length} danh mục`
                    )
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `<:cat_star:1492453457158869113> **Chào mừng!**\n` +
                        `Bot đa chức năng quản lý & bảo vệ server <:automod:1487785352612548638>\n\n` +
                        `${ARROW} Dùng menu bên dưới để xem lệnh\n` +
                        `${ARROW} Hoặc chọn **Tất cả lệnh**`
                    )
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `<:search:1492132251608158338> [ᴍờɪ ʙᴏᴛ](https://tinyurl.com/Th07z) • [ᴍáʏ ᴄʜủ ʜỗ ᴛʀợ](https://discord.gg/BW6NbrKdyF)`
                    )
                )
                .addSeparatorComponents(sep())
                .addActionRowComponents(row =>
                    row.addComponents(makeNavButtons(true), makeListButton(false))
                )
                .addActionRowComponents(row => row.addComponents(makeDropdown()));

        // ================= ALL COMMANDS =================
        const buildList = () => {
            const container = new ContainerBuilder()
                .setAccentColor(0x2b2d31)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`<:rule:1492466019157938308> **Tất cả lệnh**`)
                )
                .addSeparatorComponents(sep());

            categories.forEach((cat, index) => {
                const cmds = getCommands(cat)
                    .map(c => `${ARROW} \`${c.name}\``)
                    .join("\n") || "Không có";

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**${index + 1}. ${capitalize(cat)}**\n${cmds}`
                    )
                );

                if (index < categories.length - 1)
                    container.addSeparatorComponents(thin());
            });

            return container
                .addSeparatorComponents(sep())
                .addActionRowComponents(row =>
                    row.addComponents(makeNavButtons(false), makeListButton(true))
                )
                .addActionRowComponents(row => row.addComponents(makeDropdown()));
        };

        // ================= CATEGORY =================
        const buildCategory = (cat) => {
            const cmds = getCommands(cat)
                .map(c => `${ARROW} \`${prefix}${c.name}\``)
                .join("\n") || "Không có";

            return new ContainerBuilder()
                .setAccentColor(0x2b2d31)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`<:cat_folder:1492453451442163862> **${capitalize(cat)}**`)
                )
                .addSeparatorComponents(sep())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(cmds)
                )
                .addSeparatorComponents(sep())
                .addActionRowComponents(row =>
                    row.addComponents(makeNavButtons(false), makeListButton(false))
                )
                .addActionRowComponents(row => row.addComponents(makeDropdown(cat)));
        };

        const msg = await message.reply({
            components: [buildHome()],
            flags: MessageFlags.IsComponentsV2,
        });

        const collector = msg.createMessageComponentCollector({
            filter: (i) => {
                if (i.user.id !== message.author.id) {
                    i.reply({
                        content: `${emoji.cross} Không phải menu của bạn`,
                        ephemeral: true
                    });
                    return false;
                }
                return true;
            },
            time: 0,
        });

        collector.on("collect", async (i) => {
            if (i.customId === "home") {
                return i.update({ components: [buildHome()], flags: MessageFlags.IsComponentsV2 });
            }

            if (i.customId === "list") {
                return i.update({ components: [buildList()], flags: MessageFlags.IsComponentsV2 });
            }

            if (i.values?.[0]) {
                return i.update({ components: [buildCategory(i.values[0])], flags: MessageFlags.IsComponentsV2 });
            }
        });
    },
};
