const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
} = require("discord.js");

module.exports = {
    name: "multiwhitelist",
    aliases: ["multiwl", "mwl"],
    description: "Thêm hoặc xóa nhiều người dùng khỏi danh sách trắng cùng lúc",
    category: "antinuke",
    cooldown: 3,

    run: async (client, message, args, prefix) => {
        const owners      = client.config?.owner || [];
        const extra1      = await client.db.get(`ownerPermit1_${message.guild.id}`);
        const extra2      = await client.db.get(`ownerPermit2_${message.guild.id}`);
        const extraOwners = [extra1, extra2].filter(Boolean);

        if (
            message.author.id !== message.guild.ownerId &&
            !owners.includes(message.author.id) &&
            !extraOwners.includes(message.author.id)
        ) {
            return message.channel.send({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF0000)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `${client.emoji.cross} Chỉ **chủ sở hữu máy chủ** mới có thể sử dụng lệnh này.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        const key       = `whitelist_${message.guild.id}`;
        let   whitelist = client.lmdbGet(key) || [];

        const opt = args[0]?.toLowerCase();

        const sep = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);

        if (!opt || !["add", "remove"].includes(opt)) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x26272F)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent("## 🛡️ Danh sách trắng đa người dùng")
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `\`${prefix}multiwhitelist add <@users...>\` — Thêm nhiều người dùng\n` +
                                `\`${prefix}multiwhitelist remove <@users...>\` — Xóa nhiều người dùng`
                            )
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`-# Yêu cầu bởi ${message.author.tag}`)
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        let users = message.mentions.members.map(m => m);
        if (users.length === 0) {
            users = args.slice(1)
                .map(id => message.guild.members.cache.get(id))
                .filter(Boolean);
        }

        if (users.length === 0) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x26272F)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `${client.emoji.cross} Không có người dùng hợp lệ nào được cung cấp.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        if (opt === "add") {
            const added   = [];
            const skipped = [];

            for (const user of users) {
                if (!whitelist.includes(user.id)) {
                    whitelist.push(user.id);
                    added.push(user.user.tag);
                } else {
                    skipped.push(user.user.tag);
                }
            }

            client.lmdbSet(key, whitelist);
            if (client.updateWhitelistCache) {
                for (const user of users) client.updateWhitelistCache(message.guild.id, user.id, true);
            }

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x57F287)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent("## <:enable:1487783260565143614> Danh sách trắng đã cập nhật")
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `**Đã thêm [${added.length}]**\n${added.length ? added.map(t => `\`${t}\``).join(", ") : "Không có"}\n\n` +
                                `**Đã có trong danh sách trắng [${skipped.length}]**\n${skipped.length ? skipped.map(t => `\`${t}\``).join(", ") : "Không có"}`
                            )
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`-# Yêu cầu bởi ${message.author.tag}`)
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        if (opt === "remove") {
            const removed  = [];
            const notFound = [];

            for (const user of users) {
                if (whitelist.includes(user.id)) {
                    whitelist = whitelist.filter(x => x !== user.id);
                    removed.push(user.user.tag);
                } else {
                    notFound.push(user.user.tag);
                }
            }

            client.lmdbSet(key, whitelist);
            if (client.updateWhitelistCache) {
                for (const user of users) client.updateWhitelistCache(message.guild.id, user.id, false);
            }

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF0000)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent("## <:enable:1487783260565143614> Danh sách trắng đã cập nhật")
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `**Đã xóa [${removed.length}]**\n${removed.length ? removed.map(t => `\`${t}\``).join(", ") : "Không có"}\n\n` +
                                `**Không tìm thấy [${notFound.length}]**\n${notFound.length ? notFound.map(t => `\`${t}\``).join(", ") : "Không có"}`
                            )
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`-# Yêu cầu bởi ${message.author.tag}`)
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }
    },
};
