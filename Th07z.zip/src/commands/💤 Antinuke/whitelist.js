const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ButtonBuilder,
    SeparatorSpacingSize,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");

module.exports = {
    name: "whitelist",
    aliases: ["wl"],
    description: "Quản lý người dùng trong danh sách trắng chống phá hoại",
    category: "antinuke",
    cooldown: 3,

    run: async (client, message, args, prefix) => {
        const owners      = client.config?.owner || [];
        const extra1      = await client.db.get(`ownerPermit1_${message.guild.id}`);
        const extra2      = await client.db.get(`ownerPermit2_${message.guild.id}`);
        const extraOwners = [extra1, extra2].filter(Boolean);

        if (
            message.author.id !== message.guild.ownerId &&
            !owners.includes(message.author.id) &&
            !extraOwners.includes(message.author.id)
        ) {
            return message.channel.send({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF0000)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `${client.emoji.cross} Chỉ **chủ sở hữu máy chủ** mới có thể sử dụng lệnh này.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        const guildId   = message.guild.id;
        const key       = `whitelist_${guildId}`;
        let   whitelist = client.lmdbGet(key) || [];

        const sep = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);

        const opt = args[0]?.toLowerCase();

        if (!opt) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x26272F)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent("## 🛡️ Quản lý Danh sách trắng")
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `\`${prefix}whitelist add <user>\` — Thêm người dùng\n` +
                                `\`${prefix}whitelist remove <user>\` — Xóa người dùng\n` +
                                `\`${prefix}whitelist show\` — Xem tất cả người dùng trong danh sách trắng\n` +
                                `\`${prefix}whitelist reset\` — Xóa danh sách trắng`
                            )
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`-# Yêu cầu bởi ${message.author.tag}`)
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        if (opt === "show") {
            let users = [];
            for (const id of whitelist) {
                const u = await client.users.fetch(id).catch(() => null);
                if (u) users.push(u);
            }

            if (users.length === 0) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0x26272F)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    "## 🛡️ Người dùng trong Danh sách trắng\n\nHiện không có người dùng nào trong danh sách trắng."
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            const pageSize = 10;
            let page = 0;
            const total = Math.ceil(users.length / pageSize);

            const buildPage = () => {
                const start = page * pageSize;
                const list  = users.slice(start, start + pageSize);
                return new ContainerBuilder()
                    .setAccentColor(0x26272F)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## 🛡️ Người dùng trong Danh sách trắng — ${users.length}`)
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            list.map((u, i) =>
                                `\`${start + i + 1}.\` **${u.tag}** — \`${u.id}\``
                            ).join("\n")
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`-# Trang ${page + 1}/${total}`)
                    )
                    .addActionRowComponents((row) =>
                        row.addComponents(
                            new ButtonBuilder()
                                .setCustomId("wl_prev")
                                .setLabel("Trước")
                                .setStyle(ButtonStyle.Secondary)
                                .setDisabled(page === 0),
                            new ButtonBuilder()
                                .setCustomId("wl_next")
                                .setLabel("Tiếp")
                                .setStyle(ButtonStyle.Secondary)
                                .setDisabled(page === total - 1),
                            new ButtonBuilder()
                                .setCustomId("wl_close")
                                .setLabel("Đóng")
                                .setStyle(ButtonStyle.Danger)
                        )
                    );
            };

            const sent = await message.reply({
                components: [buildPage()],
                flags: MessageFlags.IsComponentsV2,
            });

            const collector = sent.createMessageComponentCollector({
                filter: (i) => i.user.id === message.author.id,
                time: 300000,
            });

            collector.on("collect", async (i) => {
                if (i.customId === "wl_prev") page = Math.max(0, page - 1);
                if (i.customId === "wl_next") page = Math.min(total - 1, page + 1);
                if (i.customId === "wl_close") {
                    await i.message.delete().catch(() => {});
                    return collector.stop();
                }
                await i.update({ components: [buildPage()], flags: MessageFlags.IsComponentsV2 });
            });

            return;
        }

        if (opt === "add") {
            let userId   = args[1];
            const mentioned = message.mentions.users.first();
            if (mentioned) userId = mentioned.id;

            if (!userId) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0x26272F)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${client.emoji.cross} Vui lòng cung cấp thẻ người dùng hoặc ID.`
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            const user = await client.users.fetch(userId).catch(() => null);
            if (!user) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0xFF0000)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} ID người dùng không hợp lệ.`)
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            if (whitelist.includes(user.id)) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0x26272F)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${client.emoji.cross} **${user.tag}** đã có trong danh sách trắng.`
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            whitelist.push(user.id);
            client.lmdbSet(key, whitelist);
            if (!client._whitelistCache) client._whitelistCache = new Map();
            if (!client._whitelistCache.has(guildId)) client._whitelistCache.set(guildId, new Set());
            client._whitelistCache.get(guildId).add(user.id);

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x57F287)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `<:enable:1487783260565143614> **${user.tag}** đã được thêm vào danh sách trắng.\n-# ID: \`${user.id}\``
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        if (opt === "remove") {
            let userId      = args[1];
            const mentioned = message.mentions.users.first();
            if (mentioned) userId = mentioned.id;

            if (!userId) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0x26272F)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${client.emoji.cross} Vui lòng cung cấp thẻ người dùng hoặc ID.`
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            const user = await client.users.fetch(userId).catch(() => null);
            if (!user) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0xFF0000)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} ID người dùng không hợp lệ.`)
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            if (!whitelist.includes(user.id)) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0x26272F)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${client.emoji.cross} **${user.tag}** không có trong danh sách trắng.`
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            whitelist = whitelist.filter(x => x !== user.id);
            client.lmdbSet(key, whitelist);
            if (!client._whitelistCache) client._whitelistCache = new Map();
            if (client._whitelistCache.has(guildId)) client._whitelistCache.get(guildId).delete(user.id);

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF0000)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `<:disabled:1487783250452545616> **${user.tag}** đã bị xóa khỏi danh sách trắng.\n-# ID: \`${user.id}\``
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        if (opt === "reset") {
            if (whitelist.length === 0) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0x26272F)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${client.emoji.cross} Danh sách trắng đã trống.`
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            const buildConfirm = () =>
                new ContainerBuilder()
                    .setAccentColor(0xFF0000)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent("## <:warning:1487783235286073465> Xác nhận Đặt lại")
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `Thao tác này sẽ xóa **${whitelist.length}** người dùng khỏi danh sách trắng.\nHành động này không thể hoàn tác.`
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addActionRowComponents((row) =>
                        row.addComponents(
                            new ButtonBuilder()
                                .setCustomId("wl_confirm")
                                .setLabel("Xác nhận Đặt lại")
                                .setStyle(ButtonStyle.Danger),
                            new ButtonBuilder()
                                .setCustomId("wl_cancel")
                                .setLabel("Hủy")
                                .setStyle(ButtonStyle.Secondary)
                        )
                    );

            const confirmMsg = await message.reply({
                components: [buildConfirm()],
                flags: MessageFlags.IsComponentsV2,
            });

            const collector = confirmMsg.createMessageComponentCollector({
                filter: (i) => i.user.id === message.author.id,
                time: 30000,
                max: 1,
            });

            collector.on("collect", async (i) => {
                if (i.customId === "wl_confirm") {
                    const count = whitelist.length;
                    client.lmdbSet(key, []);
                    if (!client._whitelistCache) client._whitelistCache = new Map();
                    client._whitelistCache.set(guildId, new Set());

                    return i.update({
                        components: [
                            new ContainerBuilder()
                                .setAccentColor(0xFF0000)
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(
                                        `<:disabled:1487783250452545616> Danh sách trắng đã được đặt lại.\n-# Đã xóa \`${count}\` người dùng.`
                                    )
                                ),
                        ],
                        flags: MessageFlags.IsComponentsV2,
                    });
                }

                if (i.customId === "wl_cancel") {
                    return i.update({
                        components: [
                            new ContainerBuilder()
                                .setAccentColor(0x26272F)
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent("Đã hủy đặt lại.")
                                ),
                        ],
                        flags: MessageFlags.IsComponentsV2,
                    });
                }
            });

            collector.on("end", async (collected) => {
                if (collected.size === 0) {
                    await confirmMsg.edit({
                        components: [
                            new ContainerBuilder()
                                .setAccentColor(0x26272F)
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent("Đặt lại đã hết thời gian.")
                                ),
                        ],
                        flags: MessageFlags.IsComponentsV2,
                    }).catch(() => {});
                }
            });

            return;
        }
    },
};
