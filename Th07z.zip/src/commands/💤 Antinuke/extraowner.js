
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "extraowner",
    aliases: ["extraowners", "addowner"],
    description: "Quản lý chủ sở hữu bổ sung để truy cập chống phá hoại",
    category: "antinuke",
    cooldown: 3,

    run: async (client, message, args, prefix) => {

        // ================= PERMISSION =================
        if (
            message.author.id !== message.guild.ownerId &&
            !client.config.owner.includes(message.author.id)
        ) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} Chỉ Chủ sở hữu máy chủ mới được phép chạy lệnh này.`)
                ]
            });
        }

        // ================= DATA =================
        let a = await client.db.get(`ownerPermit1_${message.guild.id}`);
        let b = await client.db.get(`ownerPermit2_${message.guild.id}`);

        // ================= NO ARG =================
        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} Cách dùng: \`${prefix}extraowner <add/remove/show>\``)
                ]
            });
        }

        let opt = args[0].toLowerCase();

        // ================= SHOW =================
        if (opt === "show") {
            let ans = "";

            if (a) ans += `\n<@${a}>`;
            if (b) ans += `\n<@${b}>`;

            if (!ans) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} Không có Chủ sở hữu bổ sung nào trong máy chủ này`)
                    ]
                });
            }

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(ans)
                        .setAuthor({
                            name: "Danh sách Extra Owner",
                            iconURL: message.guild.iconURL({ dynamic: true })
                        })
                ]
            });
        }

        // ================= GET USER =================
        let user =
            message.mentions.members.first() ||
            message.guild.members.cache.get(args[1]);

        if (!user) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} Vui lòng cung cấp một người dùng hợp lệ.`)
                ]
            });
        }

        // ================= ADD =================
        if (opt === "add") {

            // tránh add owner chính
            if (user.id === message.guild.ownerId) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} Người này đã là chủ server.`)
                    ]
                });
            }

            if (a === user.id || b === user.id) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} ${user} đã có trong danh sách Chủ sở hữu bổ sung`)
                    ]
                });
            }

            if (!a) {
                await client.db.set(`ownerPermit1_${message.guild.id}`, user.id);
            } else if (!b) {
                await client.db.set(`ownerPermit2_${message.guild.id}`, user.id);
            } else {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} Không thể thêm quá 2 Chủ sở hữu bổ sung`)
                    ]
                });
            }

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.tick} Đã thêm thành công ${user} vào Chủ sở hữu bổ sung`)
                ]
            });
        }

        // ================= REMOVE =================
        if (opt === "remove") {

            if (user.id === a) {
                await client.db.delete(`ownerPermit1_${message.guild.id}`);
            } else if (user.id === b) {
                await client.db.delete(`ownerPermit2_${message.guild.id}`);
            } else {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} ${user} không phải là Chủ sở hữu bổ sung`)
                    ]
                });
            }

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.tick} Đã xóa thành công ${user} khỏi Chủ sở hữu bổ sung`)
                ]
            });
        }

        // ================= INVALID =================
        return message.channel.send({
            embeds: [
                new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.cross} Lệnh không hợp lệ.`)
            ]
        });
    }
};