const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ButtonBuilder,
    SeparatorSpacingSize,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");

const ENABLED_EMOJI  = "<:enable:1487783260565143614>";
const DISABLED_EMOJI = "<:disabled:1487783250452545616>";

const ANTINUKE_MODULES = [
    { name: "Chống Tạo Kênh",    key: "channelCreate" },
    { name: "Chống Xóa Kênh",    key: "channelDelete" },
    { name: "Chống Cập Nhật Kênh",    key: "channelUpdate" },
    { name: "Chống Tạo Quyền",       key: "roleCreate" },
    { name: "Chống Xóa Quyền",       key: "roleDelete" },
    { name: "Chống Cập Nhật Quyền",       key: "roleUpdate" },
    { name: "Chống Tạo Webhook",    key: "webhookCreate" },
    { name: "Chống Xóa Webhook",    key: "webhookDelete" },
    { name: "Chống Cập Nhật Webhook",    key: "webhookUpdate" },
    { name: "Chống Cập Nhật Máy Chủ",      key: "guildUpdate" },
    { name: "Chống Thêm Tích Hợp",   key: "integrationAdd" },
    { name: "Chống Cập Nhật Tích Hợp",key: "integrationUpdate" },
    { name: "Chống Xóa Tích Hợp",key: "integrationDelete" },
    { name: "Chống Cấm",               key: "ban" },
    { name: "Chống Kick",              key: "kick" },
    { name: "Chống Bỏ Cấm",             key: "unban" },
    { name: "Chống Thêm Bot",           key: "botAdd" },
    { name: "Chống Ping Everyone",     key: "everyonePing" },
    { name: "Chống Ping Here",         key: "herePing" },
    { name: "Chống Cập Nhật Quyền Thành Viên",key: "memberRoleUpdate" },
    { name: "Chống Kênh Cộng Đồng", key: "communityChannel" },
    { name: "Chống Quyền Liên Kết",       key: "linkedRole" },
    { name: "Chống Cắt Bỏ Thành Viên",      key: "memberPrune" },
];

module.exports = {
    name: "antinuke",
    aliases: ["an"],
    description: "Bật hoặc tắt bảo vệ chống phá hoại máy chủ",
    category: "antinuke",
    cooldown: 3,

    run: async (client, message, args, prefix) => {
        if (!client.config.owner.includes(message.author.id) &&
            message.guild.ownerId !== message.author.id) {
            return message.channel.send({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF0000)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `${client.emoji.cross} Chỉ **Chủ sở hữu máy chủ** mới có thể sử dụng lệnh này.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        const sub     = args[0]?.toLowerCase();
        const guildId = message.guild.id;
        const key     = `antinuke_${guildId}`;
        const isEnabled = client.lmdbGet(key) === "enabled";

        const sep  = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
        const thin = () => new SeparatorBuilder().setDivider(false).setSpacing(SeparatorSpacingSize.Small);

        if (!sub) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x26272F)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent("## <:dev:1487792093828091904> Hệ thống Antinuke")
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `\`${prefix}antinuke enable\` — Bật bảo vệ\n` +
                                `\`${prefix}antinuke disable\` — Tắt bảo vệ\n` +
                                `\`${prefix}antinuke status\` — Xem trạng thái hiện tại`
                            )
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`-# Yêu cầu bởi ${message.author.tag}`)
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        if (sub === "status") {
            const whitelist = client.lmdbGet(`whitelist_${guildId}`) || [];

            let currentPage = "status";

            const buildStatus = () =>
                new ContainerBuilder()
                    .setAccentColor(isEnabled ? 0x57F287 : 0xFF0000)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `## <:dev:1487792093828091904> ${message.guild.name}\nTrạng thái bảo mật`
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `**Bảo vệ** : ${isEnabled ? `${ENABLED_EMOJI} Hoạt động` : `${DISABLED_EMOJI} Không hoạt động`}\n` +
                            `**Cấp độ** : ${isEnabled ? "`Tối đa`" : "`Không`"}\n` +
                            `**Người dùng trong danh sách trắng** : \`${whitelist.length}\``
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            isEnabled
                                ? `${ENABLED_EMOJI} Máy chủ của bạn được bảo vệ hoàn toàn.`
                                : `${DISABLED_EMOJI} Bảo mật máy chủ hiện đang bị tắt.`
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`-# ID máy chủ: ${guildId}`)
                    )
                    .addActionRowComponents((row) =>
                        row.addComponents(
                            new ButtonBuilder()
                                .setCustomId("an_features")
                                .setLabel("Xem Mô-đun")
                                .setStyle(ButtonStyle.Secondary)
                                .setEmoji("⚡")
                        )
                    );

            const buildFeatures = () =>
                new ContainerBuilder()
                    .setAccentColor(isEnabled ? 0x57F287 : 0xFF0000)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent("## ⚡ Mô-đun Bảo vệ")
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            ANTINUKE_MODULES.map(m =>
                                `${isEnabled ? ENABLED_EMOJI : DISABLED_EMOJI} ${m.name}`
                            ).join("\n")
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            isEnabled
                                ? `-# Tất cả các mô-đun đang hoạt động và bảo vệ máy chủ của bạn`
                                : `-# Bật antinuke để kích hoạt tất cả các mô-đun`
                        )
                    )
                    .addActionRowComponents((row) =>
                        row.addComponents(
                            new ButtonBuilder()
                                .setCustomId("an_back")
                                .setLabel("Quay lại")
                                .setStyle(ButtonStyle.Secondary)
                                .setEmoji("<:back:1487795549770879107>")
                        )
                    );

            const buildExpiredStatus = () =>
                new ContainerBuilder()
                    .setAccentColor(0x26272F)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `## 🛡️ ${message.guild.name} — Trạng thái bảo mật`
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `**Bảo vệ** : ${isEnabled ? `${ENABLED_EMOJI} Hoạt động` : `${DISABLED_EMOJI} Không hoạt động`}\n` +
                            `**Cấp độ** : ${isEnabled ? "`Tối đa`" : "`Không`"}\n` +
                            `**Người dùng trong danh sách trắng** : \`${whitelist.length}\``
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            isEnabled
                                ? `${ENABLED_EMOJI} Máy chủ của bạn được bảo vệ hoàn toàn.`
                                : `${DISABLED_EMOJI} Bảo mật máy chủ hiện đang bị tắt.`
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`-# ID máy chủ: ${guildId}`)
                    )
                    .addActionRowComponents((row) =>
                        row.addComponents(
                            new ButtonBuilder()
                                .setCustomId("an_features_disabled")
                                .setLabel("Xem Mô-đun")
                                .setStyle(ButtonStyle.Secondary)
                                .setEmoji("⚡")
                                .setDisabled(true)
                        )
                    );

            const buildExpiredFeatures = () =>
                new ContainerBuilder()
                    .setAccentColor(0x26272F)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent("## ⚡ Mô-đun Bảo vệ")
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            ANTINUKE_MODULES.map(m =>
                                `${isEnabled ? ENABLED_EMOJI : DISABLED_EMOJI} ${m.name}`
                            ).join("\n")
                        )
                    )
                    .addSeparatorComponents(sep())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            isEnabled
                                ? `-# Tất cả các mô-đun đang hoạt động và bảo vệ máy chủ của bạn`
                                : `-# Bật antinuke để kích hoạt tất cả các mô-đun`
                        )
                    )
                    .addActionRowComponents((row) =>
                        row.addComponents(
                            new ButtonBuilder()
                                .setCustomId("an_back_disabled")
                                .setLabel("Quay lại")
                                .setStyle(ButtonStyle.Secondary)
                                .setEmoji("<:back:1487795549770879107>")
                                .setDisabled(true)
                        )
                    );

            const sent = await message.reply({
                components: [buildStatus()],
                flags: MessageFlags.IsComponentsV2,
            });

            const collector = sent.createMessageComponentCollector({
                filter: (i) => i.user.id === message.author.id,
                time: 120000,
            });

            collector.on("collect", async (i) => {
                if (i.customId === "an_features") {
                    currentPage = "features";
                    return i.update({ components: [buildFeatures()], flags: MessageFlags.IsComponentsV2 });
                }
                if (i.customId === "an_back") {
                    currentPage = "status";
                    return i.update({ components: [buildStatus()], flags: MessageFlags.IsComponentsV2 });
                }
            });

            collector.on("end", async () => {
                const expired = currentPage === "features" ? buildExpiredFeatures() : buildExpiredStatus();
                await sent.edit({ components: [expired], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
            });

            return;
        }

        if (sub === "enable") {
            if (isEnabled) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0x26272F)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${ENABLED_EMOJI} Antinuke đã **được bật** cho máy chủ này.`
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            client.lmdbSet(key, "enabled");
            if (!client._antinukeCache) client._antinukeCache = new Map();
            client._antinukeCache.set(guildId, true);

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x57F287)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `${ENABLED_EMOJI} Antinuke đã **được bật** thành công.\n-# Máy chủ của bạn hiện đã được bảo vệ hoàn toàn.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        if (sub === "disable") {
            if (!isEnabled) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0x26272F)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${DISABLED_EMOJI} Antinuke đã **bị tắt** cho máy chủ này.`
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            client.lmdbDel(key);
            if (!client._antinukeCache) client._antinukeCache = new Map();
            client._antinukeCache.set(guildId, false);

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF0000)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `${DISABLED_EMOJI} Antinuke đã **bị tắt** thành công.\n-# Máy chủ của bạn không còn được bảo vệ.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        return message.reply({
            components: [
                new ContainerBuilder()
                    .setAccentColor(0x26272F)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `${client.emoji.cross} Tùy chọn không hợp lệ. Sử dụng \`${prefix}antinuke <enable|disable|status>\``
                        )
                    ),
            ],
            flags: MessageFlags.IsComponentsV2,
        });
    },
};
