const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "sendmsg",
    description: "Gửi tin nhắn đến bất kỳ kênh máy chủ nào",
    category: 'owner',
    cooldown: 3,
    run: async (client, message, args, prefix) => {
        if (message.author.id !== '1187321862724800562') {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription('<:disabled:1487783250452545616> Bạn không có quyền sử dụng lệnh này.')]
            });
        }

        if (args.length < 3) {
            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setTitle('📨 Lệnh Gửi Tin Nhắn')
                    .setDescription(
                        `**Cách dùng:** \`${prefix}sendmsg <guildid> <channelid> <message>\`\n\n` +
                        `**Ví dụ:**\n` +
                        `\`${prefix}sendmsg 123456789 987654321 Chào mọi người!\`\n\n` +
                        `**Tính năng:**\n` +
                        `• Gửi tin nhắn văn bản kèm biểu tượng cảm xúc\n` +
                        `• Đính kèm hình ảnh, video, tệp\n` +
                        `• Gửi nhãn dán\n` +
                        `• Hoạt động trong bất kỳ máy chủ/kênh nào mà bot có mặt`
                    )]
            });
        }

        const guildId = args[0];
        const channelId = args[1];
        const messageContent = args.slice(2).join(' ');

        try {
            const targetGuild = client.guilds.cache.get(guildId);
            if (!targetGuild) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`<:disabled:1487783250452545616> Không tìm thấy máy chủ. Đảm bảo bot có mặt trong máy chủ đó.\n**ID Máy chủ:** \`${guildId}\``)]
                });
            }

            const targetChannel = targetGuild.channels.cache.get(channelId);
            if (!targetChannel) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`<:disabled:1487783250452545616> Không tìm thấy kênh trong **${targetGuild.name}**.\n**ID Kênh:** \`${channelId}\``)]
                });
            }

            if (!targetChannel.isTextBased()) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`<:disabled:1487783250452545616> Không thể gửi tin nhắn đến **${targetChannel.name}** (không phải kênh văn bản).`)]
                });
            }

            const messageOptions = {};

            if (messageContent && messageContent.trim().length > 0) {
                messageOptions.content = messageContent;
            }

            if (message.attachments.size > 0) {
                messageOptions.files = Array.from(message.attachments.values()).map(att => ({
                    attachment: att.url,
                    name: att.name
                }));
            }

            if (message.stickers.size > 0) {
                const sticker = message.stickers.first();
                messageOptions.stickers = [sticker.id];
            }

            if (!messageOptions.content && !messageOptions.files && !messageOptions.stickers) {
                return message.channel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription('<:disabled:1487783250452545616> Vui lòng cung cấp tin nhắn, tệp đính kèm hoặc nhãn dán để gửi.')]
                });
            }

            await targetChannel.send(messageOptions);

            const confirmEmbed = new EmbedBuilder()
                .setColor('#26272F')
                .setTitle('<:enable:1487783260565143614> Đã gửi tin nhắn thành công')
                .setDescription(
                    `**Máy chủ:** ${targetGuild.name} (\`${guildId}\`)\n` +
                    `**Kênh:** ${targetChannel.name} (\`${channelId}\`)`
                )
                .setTimestamp();

            if (messageContent) {
                confirmEmbed.addFields({ name: 'Nội dung tin nhắn', value: messageContent.length > 1024 ? messageContent.substring(0, 1021) + '...' : messageContent });
            }

            if (message.attachments.size > 0) {
                confirmEmbed.addFields({ name: 'Tệp đính kèm', value: `${message.attachments.size} tệp được đính kèm` });
            }

            if (message.stickers.size > 0) {
                confirmEmbed.addFields({ name: 'Nhãn dán', value: `${message.stickers.size} nhãn dán đã gửi` });
            }

            await message.channel.send({ embeds: [confirmEmbed] });

        } catch (error) {
            console.error('SendMsg Error:', error);
            
            let errorMessage = '<:disabled:1487783250452545616> Gửi tin nhắn thất bại.';
            
            if (error.code === 50013) {
                errorMessage = '<:disabled:1487783250452545616> Thiếu quyền gửi tin nhắn trong kênh đó.';
            } else if (error.code === 50001) {
                errorMessage = '<:disabled:1487783250452545616> Thiếu quyền truy cập vào kênh đó.';
            } else if (error.message) {
                errorMessage = `<:disabled:1487783250452545616> Lỗi: ${error.message}`;
            }

            return message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(errorMessage)]
            });
        }
    }
};
