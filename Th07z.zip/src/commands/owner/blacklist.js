const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "blacklist",
    aliases: ["bl"],
    description: "Quản lý danh sách đen người dùng",
    category: "owner",
    cooldown: 3,
    run: async (client, message, args, prefix) => {

        let accessList = await client.db.get(`blacklistaccess_${client.user.id}`) || [];

        if (message.author.id !== "1187321862724800562" && !accessList.includes(message.author.id)) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Bạn không được phép sử dụng lệnh này.`)
                ]
            });
        }

        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.cross} | Cách dùng: \`${prefix}blacklist <thêm/xóa/cập nhật/đặt lại>\``)
                ]
            });
        }

        let db = await client.db.get(`blacklist_${client.user.id}`);
        if (!db) {
            await client.db.set(`blacklist_${client.user.id}`, []);
            db = [];
        }

        let bl = [...db];
        let opt = args[0].toLowerCase();

        let user =
            message.mentions.users.first() ||
            client.users.cache.get(args[1]) ||
            (args[1]?.match(/^\d+$/) ? { id: args[1] } : null);

        let reason = args.slice(2).join(" ") || "Không có lý do nào được cung cấp";

        if (["add", "remove"].includes(opt)) {
            let targetId = user?.id;
            if (targetId === "1187321862724800562") {
                return message.channel.send({
                    files: [{
                        attachment: "https://cdn.discordapp.com/attachments/1127970897802833980/1438804935893450783/Doraemon_Achha_Laude_Memes.jpeg"
                    }]
                });
            }
        }

        if (opt === "add") {
            if (!user) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} | Vui lòng cung cấp một người dùng hợp lệ.`)
                    ]
                });
            }

            if (bl.includes(user.id)) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} | Người dùng đã có trong danh sách đen.`)
                    ]
                });
            }

            bl.push(user.id);
            await client.db.set(`blacklist_${client.user.id}`, bl);
            await client.db.set(`blreason_${user.id}`, reason);

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.tick} | Đã thêm <@${user.id}> vào danh sách đen thành công`)
                ]
            });
        }

        if (opt === "remove") {
            if (!user) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} | Vui lòng cung cấp một người dùng hợp lệ.`)
                    ]
                });
            }

            if (!bl.includes(user.id)) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} | Người dùng không có trong danh sách đen.`)
                    ]
                });
            }

            bl = bl.filter(x => x !== user.id);
            await client.db.set(`blacklist_${client.user.id}`, bl);
            await client.db.delete(`blreason_${user.id}`);

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.tick} | Đã xóa <@${user.id}> khỏi danh sách đen`)
                ]
            });
        }

        if (opt === "update") {
            let list = bl.map(id => `${client.emoji.dot} <@${id}> | \`${id}\``);

            if (!list.length) {
                return message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${client.emoji.cross} | Không có người dùng nào trong danh sách đen.`)
                    ]
                });
            }

            let embed = new EmbedBuilder()
                .setColor('#26272F')
                .setAuthor({ name: "Người dùng trong danh sách đen", iconURL: client.user.displayAvatarURL() })
                .setDescription(list.join("\n"))
                .setFooter({ text: `Tổng cộng: ${list.length}` });

            let ch = client.channels.cache.get(client.config.gban_channel_id);
            if (!ch) return message.channel.send({ content: `${client.emoji.cross} | Không tìm thấy kênh.` });

            let old = await client.db.get(`blmsg_${client.user.id}`);
            if (old) {
                let msg = ch.messages.cache.get(old);
                if (msg) msg.delete().catch(() => {});
            }

            let sent = await ch.send({ embeds: [embed] });
            await client.db.set(`blmsg_${client.user.id}`, sent.id);

            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.tick} | Danh sách đen đã được cập nhật.`)
                ]
            });
        }

        if (opt === "reset") {
            await client.db.set(`blacklist_${client.user.id}`, []);
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(`${client.emoji.tick} | Đã đặt lại danh sách đen thành công.`)
                ]
            });
        }
    }
};
