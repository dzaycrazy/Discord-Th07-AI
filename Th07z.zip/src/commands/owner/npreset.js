const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ComponentType
} = require('discord.js');

module.exports = {
    name: 'npreset',
    description: 'Đặt lại danh sách noprefix',
    category: 'owner',
    cooldown: 3,
    async run(client, message) {
        const allowedUsers = ['1187321862724800562', '1305737661411233905', '1414144380322713661', '1338128522014883884'];
        if (!allowedUsers.includes(message.author.id)) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        const embed = new EmbedBuilder()
            .setColor('#26272F')
            .setTitle('Yêu cầu xác nhận')
            .setDescription(
                '**Bạn có chắc chắn muốn đặt lại danh sách noprefix không?**\n\n' +
                'Hành động này không thể hoàn tác.\n' +
                'Nhấp vào **Xác nhận** để tiếp tục hoặc **Hủy** để hủy bỏ.'
            )
            .setFooter({ text: 'Yêu cầu này sẽ hết hạn sau 30 phút.' });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('npreset_confirm')
                .setLabel('Xác nhận')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('npreset_cancel')
                .setLabel('Hủy')
                .setStyle(ButtonStyle.Secondary)
        );

        const msg = await message.channel.send({
            embeds: [embed],
            components: [row]
        });

        const collector = msg.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time: 30 * 60 * 1000 // 30 minutes
        });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) {
                return interaction.reply({
                    content: 'Chỉ tác giả lệnh mới có thể sử dụng các nút này.',
                    ephemeral: true
                });
            }

            if (interaction.customId === 'npreset_confirm') {
                await client.db.set('noprefix', []);

                const successEmbed = new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription(`${client.emoji.tick} Danh sách noprefix đã được đặt lại.`);

                collector.stop('confirmed');
                await interaction.update({
                    embeds: [successEmbed],
                    components: []
                });
            }

            if (interaction.customId === 'npreset_cancel') {
                const cancelEmbed = new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription('❌ Hành động đã bị hủy. Danh sách noprefix không thay đổi.');

                collector.stop('cancelled');
                await interaction.update({
                    embeds: [cancelEmbed],
                    components: []
                });
            }
        });

        collector.on('end', async (_, reason) => {
            if (reason === 'time') {
                const expiredEmbed = new EmbedBuilder()
                    .setColor('#26272F')
                    .setDescription('⏰ Xác nhận đã hết hạn. Vui lòng chạy lại lệnh.');

                await msg.edit({
                    embeds: [expiredEmbed],
                    components: []
                });
            }
        });
    }
};
