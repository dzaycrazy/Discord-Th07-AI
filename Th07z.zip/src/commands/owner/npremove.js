const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'npremove',
    description: 'Xóa người dùng khỏi danh sách không tiền tố',
    category: 'owner',
    cooldown: 3,
    async run(client, message, args) {
        const allowedUsers = ['1187321862724800562', '1305737661411233905', '1414144380322713661', '1338128522014883884'];
        if (!allowedUsers.includes(message.author.id)) return message.reply('Bạn không có quyền sử dụng lệnh này.');

        const user = message.mentions.users.first();
        if (!user) return message.reply('Vui lòng đề cập một người dùng.');

        let npList = await client.db.get('noprefix') || [];
        npList = npList.filter(entry => entry.userId !== user.id);

        await client.db.set('noprefix', npList);

        const embed = new EmbedBuilder()
            .setColor('#26272F')
            .setDescription(`${client.emoji.tick} Đã xóa ${user} khỏi danh sách không tiền tố.`);
        message.channel.send({ embeds: [embed] });
    }
};
