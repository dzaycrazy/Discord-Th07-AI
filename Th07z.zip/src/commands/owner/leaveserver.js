const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    PermissionFlagsBits,
} = require('discord.js');

module.exports = {
    name: 'leaveserver',
    aliases: ['gl', 'gleave'],
    description: 'Rời khỏi máy chủ bằng ID',
    category: 'owner',
    cooldown: 3,
    run: async (client, message, args) => {
        // Owner-only protection
        if (message.author.id !== '1187321862724800562') return;

        // Guild ID or fallback to current guild
        const id = args[0];
        const guild = id ? await client.guilds.fetch(id).catch(() => null) : message.guild;

        if (!guild) {
            return message.channel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(client.color || 0xff0000)
                        .setDescription(`<:disabled:1487783250452545616> | ID máy chủ không hợp lệ hoặc tôi không có trong máy chủ đó.`)
                ]
            });
        }

        const name = guild.name || 'Máy chủ không xác định';

        // Confirmation buttons
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('confirm_leave')
                .setLabel('✅ Có, Rời khỏi')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('cancel_leave')
                .setLabel('❌ Hủy')
                .setStyle(ButtonStyle.Secondary)
        );

        const confirmEmbed = new EmbedBuilder()
            .setColor(client.color || 0xffcc00)
            .setDescription(`<:warning:1487783235286073465> Bạn có chắc chắn muốn tôi rời khỏi **${name} (${guild.id})** không?`);

        const msg = await message.channel.send({
            embeds: [confirmEmbed],
            components: [row],
        });

        const collector = msg.createMessageComponentCollector({
            time: 15000,
            filter: (i) => i.user.id === message.author.id,
        });

        collector.on('collect', async (i) => {
            await i.deferUpdate();
            if (i.customId === 'cancel_leave') {
                collector.stop('cancelled');
                return msg.edit({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color || 0x00ff00)
                            .setDescription(`<:enable:1487783260565143614> Đã hủy việc rời khỏi **${name}**.`)
                    ],
                    components: [],
                });
            }

            if (i.customId === 'confirm_leave') {
                collector.stop('confirmed');
                await message.channel.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color || 0xff9900)
                            .setDescription(`<:enable:1487783260565143614> Đã rời khỏi máy chủ **${name}**.\nLý do: Được yêu cầu bởi Chủ sở hữu\nNgười thực thi: <@1187321862724800562>`)
                    ],
                });

                await guild.leave().catch(() => null);

                return msg.edit({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color || 0x00ff00)
                            .setDescription(`<:tick:1487788656432382012> | Đã rời khỏi **${name} (${guild.id})** thành công.`)
                    ],
                    components: [],
                });
            }
        });

        collector.on('end', (_, reason) => {
            if (reason === 'time') {
                msg.edit({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(client.color || 0x999999)
                            .setDescription(`<:warning:1487783235286073465> Xác nhận đã hết thời gian. Không rời khỏi **${name}**.`)
                    ],
                    components: [],
                });
            }
        });
    },
};

