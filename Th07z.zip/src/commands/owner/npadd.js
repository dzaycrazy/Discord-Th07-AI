const moment = require('moment');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'npadd',
    description: 'Thêm người dùng vào danh sách noprefix với thời hạn tùy chọn',
    category: 'owner',
    cooldown: 3,
    async run(client, message, args) {
        const allowedUsers = ['1187321862724800562', '1305737661411233905', '1414144380322713661', '1338128522014883884'];
        if (!allowedUsers.includes(message.author.id)) return message.reply('Bạn không có quyền sử dụng lệnh này.');

        const user = message.mentions.users.first();
        if (!user) return message.reply('Vui lòng đề cập một người dùng.');

        let duration = null;
        if (args[1]) {
            const time = args[1];
            const timeValue = parseInt(time.slice(0, -1));
            const timeUnit = time.slice(-1);

            switch (timeUnit) {
                case 'd':
                    duration = moment().add(timeValue, 'days').toDate();
                    break;
                case 'm':
                    duration = moment().add(timeValue, 'months').toDate();
                    break;
                default:
                    return message.reply('Định dạng thời gian không hợp lệ. Sử dụng `1d` cho 1 ngày, `1m` cho 1 tháng, v.v.');
            }
        }

        let npList = await client.db.get('noprefix') || [];
        npList = npList.filter(entry => entry.userId !== user.id);
        npList.push({ userId: user.id, expiresAt: duration });

        await client.db.set('noprefix', npList);

        const embed = new EmbedBuilder()
            .setColor('#26272F')
            .setDescription(`${client.emoji.tick} Đã thêm ${user} vào danh sách noprefix${duration ? ` cho đến ${moment(duration).format('LLL')}` : ''}.`);
        message.channel.send({ embeds: [embed] });
    }
};
