const { getVoiceConnections } = require("@discordjs/voice");
const { removeAFK } = require("../../utils/afkManager");
const Database = require("better-sqlite3");

// ===== DB =====
const db = new Database("dzay-vc.db");

module.exports = {
  name: "247leave",
  aliases: ["afkleave", "vcleave"],
  category: "voice",
  cooldown: 3,
  premium: true,

  run: async (client, message) => {

    const connection = getVoiceConnections().get(message.guild.id);

    if (!connection)
      return message.reply("<:disabled:1487783250452545616> Bot không ở voice!");

    // ===== DISCONNECT =====
    connection.destroy();

    // ===== XOÁ RAM =====
    removeAFK(message.guild.id);

    // ===== XOÁ DB =====
    db.prepare(`
      DELETE FROM afk_voice WHERE guild_id = ?
    `).run(message.guild.id);

    return message.reply("<:disabled:1487783250452545616> Đã tắt 24/7 và rời voice");
  }
};