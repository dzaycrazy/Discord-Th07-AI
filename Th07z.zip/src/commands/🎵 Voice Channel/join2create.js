"use strict";

const {
  PermissionsBitField,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ActivityType,
} = require("discord.js");

const Database = require("better-sqlite3");
const db = new Database("dzay-vc.db");

// ─────────────────────── DB SCHEMA ───────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS j2c_settings (
    guild_id         TEXT PRIMARY KEY,
    join_channel_id  TEXT,
    category_id      TEXT,
    default_name     TEXT    DEFAULT '{user}''s Channel',
    default_limit    INTEGER DEFAULT 0,
    default_bitrate  INTEGER DEFAULT 64000,
    default_region   TEXT    DEFAULT NULL
  );

  CREATE TABLE IF NOT EXISTS j2c_channels (
    channel_id  TEXT PRIMARY KEY,
    owner_id    TEXT NOT NULL,
    guild_id    TEXT NOT NULL,
    created_at  TEXT DEFAULT (datetime('now'))
  );
`);

// ─────────────────────── CONSTANTS ───────────────────────
const SUPPORT_URL   = "https://discord.gg/BW6NbrKdyF";
const VOICE_NAME      = "ִֶָ𓂃 ࣪˖ᴄʀᴇᴀᴛᴇ-ᴠᴏɪᴄᴇ~ʀᴏᴏᴍִֶָ🐇་༘࿐";
const BOT_NAME    = "Th07";

const MOOD_ICONS    = ["❤️","😈","⚡","🌙","💤","🫪"];
const VALID_REGIONS = [
  "us-west","us-east","us-central","us-south",
  "singapore","southafrica","sydney","europe",
  "brazil","hongkong","russia","japan","india","vietnam",
];

const BTN = {
  LOCK:       "j2c_lock",
  UNLOCK:     "j2c_unlock",
  GHOST:      "j2c_ghost",
  REVEAL:     "j2c_reveal",
  CLAIM:      "j2c_claim",
  DISCONNECT: "j2c_disconnect",
  INFO:       "j2c_info",
  INCREASE:   "j2c_increase",
  DECREASE:   "j2c_decrease",
};

// ─────────────────────── HELPERS ─────────────────────────
const mood = () => MOOD_ICONS[Math.floor(Math.random() * MOOD_ICONS.length)];

function getActivity(member) {
  const a = member.presence?.activities?.[0];
  if (!a) return "";
  if (a.type === ActivityType.Playing)   return ` 🎮 ${a.name}`;
  if (a.type === ActivityType.Listening) return ` 🎧 ${a.name}`;
  if (a.type === ActivityType.Streaming) return ` 📡 ${a.name}`;
  return "";
}

// ─────────────────────── DB HELPERS ──────────────────────
const settingsCache = new Map();

function getSettings(guildId) {
  const cached = settingsCache.get(guildId);
  if (cached && Date.now() < cached.expiry) return cached.data;
  const row = db.prepare("SELECT * FROM j2c_settings WHERE guild_id=?").get(guildId);
  settingsCache.set(guildId, { data: row ?? null, expiry: Date.now() + 300_000 });
  return row ?? null;
}

function bustCache(guildId) { settingsCache.delete(guildId); }

function getChannel(channelId) {
  return db.prepare("SELECT * FROM j2c_channels WHERE channel_id=?").get(channelId);
}

function isOwner(channelId, userId) {
  return db.prepare("SELECT owner_id FROM j2c_channels WHERE channel_id=?")
    .get(channelId)?.owner_id === userId;
}

// ─────────────────────── VC NAME ─────────────────────────
async function updateVCName(channel) {
  try {
    const data = getChannel(channel.id);
    if (!data) return;

    const guild = channel.guild;

    // 🔥 FETCH OWNER SAFE
    const owner =
      guild.members.cache.get(data.owner_id) ||
      (await guild.members.fetch(data.owner_id).catch(() => null));

    if (!owner) return;

    const memberCount = channel.members?.size ?? 0;

    const name = `${mood()} ${owner.user.username} [${memberCount}]${getActivity(owner)}`;

    // 🔥 FIX 1: tránh rename liên tục (Discord rate limit protection)
    if (channel.name === name) return;

    // 🔥 FIX 2: debounce nhẹ tránh spam khi member join/leave liên tục
    if (channel._renaming) return;
    channel._renaming = true;

    setTimeout(() => {
      channel._renaming = false;
    }, 3000);

    await channel.setName(name).catch(() => {});

  } catch (err) {
    console.error("[J2C] updateVCName error:", err);
  }
}

// ─────────────────────── CREATE VC ───────────────────────
async function createVC(member) {
  const guild = member.guild;
  const settings = getSettings(guild.id);

  if (!settings?.join_channel_id) return;

  try {
    // 🔥 REUSE CHANNEL
    const existing = db.prepare(
      "SELECT channel_id FROM j2c_channels WHERE owner_id=? AND guild_id=?"
    ).get(member.id, guild.id);

    if (existing) {
      const old = guild.channels.cache.get(existing.channel_id);
      if (old) {
        await member.voice.setChannel(old).catch(() => {});
        return old;
      }
    }

    // 🔥 CATEGORY SAFE
    let category = null;
    if (settings.category_id) {
      const cat = guild.channels.cache.get(settings.category_id);
      if (cat) {
        const bot = guild.members.me;
        if (cat.permissionsFor(bot)?.has(PermissionsBitField.Flags.ManageChannels)) {
          category = cat;
        } else {
          console.error("[J2C] Bot has no permission in category -> fallback null");
        }
      }
    }

    // 🔥 BOT CHECK
    const botMember =
      guild.members.me ||
      (await guild.members.fetchMe().catch(() => null));

    if (!botMember) return;

    // 🔥 CREATE CHANNEL (SIMPLIFIED + SAFE)
    const ch = await guild.channels.create({
      name: (settings.default_name || "{user}'s Channel")
        .replace("{user}", member.user.username),

      type: ChannelType.GuildVoice,
      parent: category || null,

      userLimit: settings.default_limit || 0,
      bitrate: settings.default_bitrate || 64000,
      rtcRegion: settings.default_region || undefined,

      permissionOverwrites: [
        // EVERYONE ONLY CONNECT (GIẢM RỦI RO 50013)
        {
          id: guild.roles.everyone.id,
          allow: [
            PermissionsBitField.Flags.Connect,
            PermissionsBitField.Flags.ViewChannel,
          ],
        },

        // OWNER FULL
        {
          id: member.id,
          allow: [
            PermissionsBitField.Flags.Connect,
            PermissionsBitField.Flags.Speak,
            PermissionsBitField.Flags.Stream,

            PermissionsBitField.Flags.ManageChannels,
            PermissionsBitField.Flags.MoveMembers,
            PermissionsBitField.Flags.MuteMembers,
            PermissionsBitField.Flags.DeafenMembers,
          ],
        },

        // BOT FULL (NHƯNG KHÔNG OVER KILL)
        {
          id: botMember.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.Connect,
            PermissionsBitField.Flags.Speak,

            PermissionsBitField.Flags.ManageChannels,
            PermissionsBitField.Flags.MoveMembers,
            PermissionsBitField.Flags.MuteMembers,
            PermissionsBitField.Flags.DeafenMembers,
          ],
        },
      ],
    }).catch(err => {
      console.error("[J2C] CREATE CHANNEL FAILED:", err);
      return null;
    });

    if (!ch) return;

    // 🔥 SAVE DB
    db.prepare(
      "INSERT OR REPLACE INTO j2c_channels (channel_id, owner_id, guild_id) VALUES (?,?,?)"
    ).run(ch.id, member.id, guild.id);

    // 🔥 MOVE USER
    await member.voice.setChannel(ch).catch(() => {});

    // 🔥 PANEL
    await ch.send({
      embeds: [buildInterfaceEmbed()],
      components: buildInterfaceComponents(),
    }).catch(() => {});

    return ch;

  } catch (err) {
    console.error("[J2C] createVC error:", err);
  }
}
// ─────────────────────── CLEANUP VC ──────────────────────
async function cleanupVC(channel) {
  try {
    const data = getChannel(channel.id);
    if (!data) return;

    db.prepare("DELETE FROM j2c_channels WHERE channel_id=?").run(channel.id);

    await channel.delete("J2C: empty channel").catch(() => {});
  } catch (err) {
    console.error("[J2C] cleanupVC error:", err);
  }
}
// ─────────────────────── CHANNEL OPS ─────────────────────
const lockChannel    = ch => ch.permissionOverwrites.edit(ch.guild.roles.everyone, { Connect: false });
const unlockChannel  = ch => ch.permissionOverwrites.edit(ch.guild.roles.everyone, { Connect: true });
const ghostChannel   = ch => ch.permissionOverwrites.edit(ch.guild.roles.everyone, { ViewChannel: false });
const unghostChannel = ch => ch.permissionOverwrites.edit(ch.guild.roles.everyone, { ViewChannel: true });
const increaseLimit  = ch => ch.edit({ userLimit: ch.userLimit > 0 ? Math.min(ch.userLimit + 1, 99) : 2 });
const decreaseLimit  = ch => ch.edit({ userLimit: ch.userLimit <= 1 ? 0 : ch.userLimit - 1 });

async function claimChannel(channel, member) {
  const data = getChannel(channel.id);
  if (!data) return false;
  const owner = channel.guild.members.cache.get(data.owner_id);
  if (owner?.voice?.channelId === channel.id) return false;
  db.prepare("UPDATE j2c_channels SET owner_id=? WHERE channel_id=?").run(member.id, channel.id);
  if (owner) await channel.permissionOverwrites.delete(owner).catch(() => {});
  await channel.permissionOverwrites.edit(member, {
    ManageChannels: true, ManageRoles: true,
    MoveMembers: true, MuteMembers: true, DeafenMembers: true,
  }).catch(() => {});
  return true;
}

// ─────────────────────── INFO EMBED ──────────────────────
function buildInfoEmbed(channel) {
  const data   = getChannel(channel.id);
  const owner  = data ? channel.guild.members.cache.get(data.owner_id) : null;
  const perms  = channel.permissionOverwrites.cache.get(channel.guild.roles.everyone.id);
  const locked = perms?.deny?.has(PermissionsBitField.Flags.Connect)    ?? false;
  const hidden = perms?.deny?.has(PermissionsBitField.Flags.ViewChannel) ?? false;
  const status = [locked && "Locked", hidden && "Hidden"].filter(Boolean).join(" · ") || "Open";

  return new EmbedBuilder()
    .setTitle(`📊 ${channel.name}`)
    .setColor(0x5865F2)
    .addFields(
      { name: "👑 Người sở hữu",   value: owner ? `<@${owner.id}>` : "Unknown",                     inline: true },
      { name: "👥 Thành viên", value: `${channel.members.size}`,                                inline: true },
      { name: "🔒 Trạng thái",  value: status,                                                    inline: true },
      { name: "🎚️ Giới hạn",  value: channel.userLimit ? `${channel.userLimit}` : "Unlimited", inline: true },
      { name: "📡 Tốc độ bit", value: `${Math.round(channel.bitrate / 1000)} kbps`,             inline: true },
      { name: "🌍 Khu vực",  value: channel.rtcRegion || "Tự động",                         inline: true },
    );
}

// ─────────────────────── INTERFACE PANEL ─────────────────
function buildInterfaceEmbed() {
  return new EmbedBuilder()
    .setTitle(`${BOT_NAME} | Voice Interface`)
    .setColor(0x5865F2)
    .setDescription(
      `🔒 — **Khoá** kênh voice\n` +
      `🔓 — **Mở** kênh voice\n` +
      `👻 — **Ẩn** kênh voice\n` +
      `👁️ — **Tiết lộ** kênh voice\n` +
      `🏳️ — **Khẳng định** kênh voice\n` +
      `👢 — **Ngắt kết nối** thành viên\n` +
      `📊 — **Xem** thông tin kênh\n` +
      `➕ — **Tăng** giới hạn người dùng\n` +
      `➖ — **Giảm** giới hạn người dùng`
    );
}

function buildInterfaceComponents() {
  const btn = (id, emoji, label) =>
    new ButtonBuilder().setCustomId(id).setEmoji(emoji).setLabel(label).setStyle(ButtonStyle.Secondary);
  return [
    new ActionRowBuilder().addComponents(
      btn(BTN.LOCK,  "🔒", "Lock"),    btn(BTN.UNLOCK, "🔓", "Unlock"),
      btn(BTN.GHOST, "👻", "Hide"),    btn(BTN.REVEAL,  "👁️", "Reveal"),
      btn(BTN.CLAIM, "🏳️", "Claim"),
    ),
    new ActionRowBuilder().addComponents(
      btn(BTN.DISCONNECT, "👢", "Disconnect"), btn(BTN.INFO,     "📊", "Info"),
      btn(BTN.INCREASE,   "➕", "Limit+"),     btn(BTN.DECREASE, "➖", "Limit-"),
    ),
  ];
}

// ─────────────────────── BUTTON HANDLER ──────────────────
async function handleButton(interaction) {
  const id = interaction.customId;
  if (!Object.values(BTN).includes(id)) return;

  const channel = interaction.member.voice?.channel;
  if (!channel)
    return interaction.reply({ content: "❌ Bạn phải đang trong một voice channel.", ephemeral: true });

  const ownerOnly = [BTN.LOCK, BTN.UNLOCK, BTN.GHOST, BTN.REVEAL, BTN.DISCONNECT, BTN.INCREASE, BTN.DECREASE];
  if (ownerOnly.includes(id) && !isOwner(channel.id, interaction.user.id))
    return interaction.reply({ content: "❌ Bạn không phải chủ kênh này.", ephemeral: true });

  await interaction.deferReply({ ephemeral: true });

  try {
    switch (id) {
      case BTN.LOCK:
        await lockChannel(channel);
        return interaction.editReply("🔒 Kênh đã được khoá.");

      case BTN.UNLOCK:
        await unlockChannel(channel);
        return interaction.editReply("🔓 Kênh đã được mở khoá.");

      case BTN.GHOST:
        await ghostChannel(channel);
        return interaction.editReply("👻 Kênh đã được ẩn.");

      case BTN.REVEAL:
        await unghostChannel(channel);
        return interaction.editReply("👁️ Kênh đã được hiện.");

      case BTN.CLAIM: {
        const ok = await claimChannel(channel, interaction.member);
        return interaction.editReply(ok
          ? "🏳️ Đã nhận quyền sở hữu kênh."
          : "❌ Không thể claim kênh này. Chủ kênh vẫn đang trong kênh.");
      }

      case BTN.INFO:
        return interaction.editReply({ embeds: [buildInfoEmbed(channel)] });

      case BTN.INCREASE:
        await increaseLimit(channel);
        return interaction.editReply(`➕ Đã tăng giới hạn thành **${channel.userLimit}**.`);

      case BTN.DECREASE:
        await decreaseLimit(channel);
        return interaction.editReply(`➖ Giới hạn hiện tại: **${channel.userLimit || "không giới hạn"}**.`);

      case BTN.DISCONNECT: {
        const members = [...channel.members.values()].filter(m => m.id !== interaction.user.id && !m.user.bot);
        if (!members.length) return interaction.editReply("❌ Không có thành viên nào để disconnect.");
        const select = new StringSelectMenuBuilder()
          .setCustomId("j2c_disconnect_select")
          .setPlaceholder("Chọn thành viên cần disconnect…")
          .setMinValues(1).setMaxValues(Math.min(members.length, 25))
          .addOptions(members.slice(0, 25).map(m => ({ label: m.displayName, value: m.id })));
        return interaction.editReply({
          content: "Chọn thành viên cần disconnect:",
          components: [new ActionRowBuilder().addComponents(select)],
        });
      }
    }
  } catch (err) {
    console.error("[J2C] button error:", err);
    interaction.editReply("❌ Đã xảy ra lỗi.").catch(() => {});
  }
}

// ─────────────────────── SELECT HANDLER ──────────────────
async function handleSelect(interaction) {
  if (interaction.customId !== "j2c_disconnect_select") return;
  await interaction.deferUpdate();

  const disconnected = [], failed = [];
  for (const uid of interaction.values) {
    const m = interaction.guild.members.cache.get(uid);
    if (m?.voice?.channel) {
      try { await m.voice.disconnect(); disconnected.push(m.displayName); }
      catch { failed.push(m.displayName); }
    }
  }

  const parts = [];
  if (disconnected.length) parts.push(`✅ Đã disconnect: ${disconnected.join(", ")}`);
  if (failed.length)       parts.push(`❌ Thất bại: ${failed.join(", ")}`);
  await interaction.editReply({
    content: parts.join("\n") || "❌ Không có ai bị disconnect.",
    components: [],
  });
}

// ─────────────────────── EVENT REGISTRATION ──────────────
// Gọi 1 lần duy nhất khi lệnh chạy lần đầu
function registerEvents(client) {
  if (client._j2cRegistered) return;
  client._j2cRegistered = true;

  client.on("voiceStateUpdate", async (oldS, newS) => {
    const member = newS.member ?? oldS.member;
    if (!member || member.user.bot) return;
    try {
      if (newS.channelId) {
        const settings = getSettings(member.guild.id);
        if (settings && newS.channelId === settings.join_channel_id) await createVC(member);
        if (getChannel(newS.channelId)) updateVCName(newS.channel).catch(() => {});
      }
      if (oldS.channel && oldS.channel.members.size === 0 && getChannel(oldS.channelId)) {
        await cleanupVC(oldS.channel);
      }
    } catch (err) {
      console.error("[J2C] voiceStateUpdate error:", err);
    }
  });

  client.on("presenceUpdate", (_, presence) => {
    const vc = presence?.member?.voice?.channel;
    if (vc && getChannel(vc.id)) updateVCName(vc).catch(() => {});
  });

  client.on("interactionCreate", async (interaction) => {
    try {
      if (interaction.isButton())           await handleButton(interaction);
      if (interaction.isStringSelectMenu()) await handleSelect(interaction);
    } catch (err) {
      console.error("[J2C] interaction error:", err);
    }
  });

  console.log("[J2C] Events registered.");
}

// ─────────────────────── EXPORT ──────────────────────────
module.exports = {
  name: "j2c",
  aliases: ["join2create", "vm", "voicemaster"],
  description: "Quản lý voice channel tạm thời (Join2Create)",
  category: "voice",
  cooldown: 3,
  premium: true,

  run: async (client, message, args) => {
    // Đăng ký events voice/interaction lần đầu tiên
    registerEvents(client);

    const guild  = message.guild;
    const author = message.member;
    const [sub, ...rest] = args;

    const isAdmin = () =>
      author.permissions.has(PermissionsBitField.Flags.Administrator) ||
      author.permissions.has(PermissionsBitField.Flags.ManageGuild);

    // ── help / no args ────────────────────────────────────
if (!sub || sub === "help") {
  const icon = message.guild.iconURL({ dynamic: true, size: 1024 });

  return message.reply({
    embeds: [
      new EmbedBuilder()
        .setTitle(`🎧 ${BOT_NAME} | ZayVoice`)
        .setColor(0x5865F2)
        .setThumbnail(icon)
        .setDescription("⚡ Hệ thống tạo & quản lý voice channel tự động")
        .addFields(
          {
            name: "⚙️ Lệnh quản trị viên",
            value:
              "`setup` · `sendinterface` · `reset`\n" +
              "`default name <text>` · `default limit <n>`\n" +
              "`default bitrate <n>` · `default region <zone>`",
          },
          {
            name: "🔊 Điều khiển giọng nói",
            value:
              "`lock` · `unlock` · `ghost` · `unghost` · `claim`\n" +
              "`name <text>` · `limit <n>` · `bitrate <n>`\n" +
              "`transfer @user` · `permit @user` · `reject @user`",
          },
          {
            name: "👥 Công cụ dành cho thành viên",
            value:
              "`disconnect @user` · `status <text>` · `config`",
          }
        )
        .setFooter({
          text: `${message.guild.name} • Hệ thống Th07VC`,
          iconURL: icon,
        })
        .setTimestamp(),
    ],
  });
}
    // ── setup ─────────────────────────────────────────────
if (sub === "setup") {
  if (!isAdmin()) return message.reply("❌ Cần quyền Manage Guild.");

  try {
    const botMember = guild.members.me;
    if (!botMember) return message.reply("❌ Không lấy được bot member.");

    // 🔥 LOAD EXISTING SETTING
    let settings = getSettings(guild.id);

    let category;
    let joinChannel;

    // ─────────────────────────────
    // 🔥 CASE 1: đã có DB (restart bot)
    // ─────────────────────────────
    if (settings?.category_id || settings?.join_channel_id) {
      category = guild.channels.cache.get(settings.category_id);
      joinChannel = guild.channels.cache.get(settings.join_channel_id);
    }

    // ─────────────────────────────
    // 🔥 CASE 2: MISSING CATEGORY
    // ─────────────────────────────
    if (!category && joinChannel) {
      category = await guild.channels.create({
        name: VOICE_NAME,
        type: ChannelType.GuildCategory,
      });

      await joinChannel.setParent(category).catch(() => {});
    }

    // ─────────────────────────────
    // 🔥 CASE 3: MISSING JOIN CHANNEL
    // ─────────────────────────────
    if (!joinChannel && category) {
      joinChannel = await guild.channels.create({
        name: "૮꒰ ྀི >⸝⸝⸝<ᴄʟɪᴄᴋ~ᴛᴏ~ᴊᴏɪɴ ྀི꒱ა",
        type: ChannelType.GuildVoice,
        parent: category,
      });
    }

    // ─────────────────────────────
    // 🔥 CASE 4: NONE EXIST → CREATE FULL
    // ─────────────────────────────
    if (!category && !joinChannel) {
      category = await guild.channels.create({
        name: Voice_NAME,
        type: ChannelType.GuildCategory,
      });

      joinChannel = await guild.channels.create({
        name: "૮꒰ ྀི >⸝⸝⸝<ᴄʟɪᴄᴋ~ᴛᴏ~ᴊᴏɪɴ ྀི꒱ა",
        type: ChannelType.GuildVoice,
        parent: category,
      });
    }

    // 🔥 BOT PERMISSION FIX
    const botPerms = [
      PermissionsBitField.Flags.ViewChannel,
      PermissionsBitField.Flags.Connect,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.MoveMembers,
      PermissionsBitField.Flags.MuteMembers,
      PermissionsBitField.Flags.DeafenMembers,
    ];

    await category.permissionOverwrites.edit(botMember.id, {
      ViewChannel: true,
      ManageChannels: true,
      ManageRoles: true,
      MoveMembers: true,
    }).catch(() => {});

    await joinChannel.permissionOverwrites.edit(botMember.id, {
      ViewChannel: true,
      Connect: true,
      ManageChannels: true,
      ManageRoles: true,
      MoveMembers: true,
      MuteMembers: true,
      DeafenMembers: true,
    }).catch(() => {});

    // 🔥 SAVE DB (PERSIST + RESTORE AFTER RESTART)
    db.prepare(`
      INSERT INTO j2c_settings 
      (guild_id, join_channel_id, category_id, default_name, default_limit, default_bitrate)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET
        join_channel_id = excluded.join_channel_id,
        category_id = excluded.category_id,
        default_name = excluded.default_name,
        default_limit = excluded.default_limit,
        default_bitrate = excluded.default_bitrate
    `).run(
      guild.id,
      joinChannel.id,
      category.id,
      "{user}'s Channel",
      0,
      64000
    );

    bustCache(guild.id);

    console.log("[J2C] setup OK (AUTO FIX ENABLED)");
    console.log("Join:", joinChannel.id);
    console.log("Category:", category.id);

    return message.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle("✅ Setup hoàn tất (Auto Fix Mode)")
          .setColor(0x00cc66)
          .setDescription(
            "🔧 Tự động sửa thiếu category / voice / reconnect DB\n" +
            "♻️ Có thể restart bot vẫn hoạt động bình thường"
          )
          .addFields(
            { name: "Join Channel", value: `<#${joinChannel.id}>` },
            { name: "Category", value: category.name }
          )
      ],
    });

  } catch (err) {
    console.error("[J2C] setup error:", err);
    return message.reply("❌ Setup thất bại. Check quyền bot.");
  }
}
    // ── reset ─────────────────────────────────────────────
    if (sub === "reset") {
      if (!isAdmin()) return message.reply("❌ Cần quyền Manage Guild.");
      try {
        const settings = getSettings(guild.id);
        for (const row of db.prepare("SELECT channel_id FROM j2c_channels WHERE guild_id=?").all(guild.id)) {
          const ch = guild.channels.cache.get(row.channel_id);
          if (ch) await ch.delete("J2C reset").catch(() => {});
        }
        if (settings?.join_channel_id) {
          const jc = guild.channels.cache.get(settings.join_channel_id);
          if (jc) await jc.delete("J2C reset").catch(() => {});
        }
        if (settings?.category_id) {
          const cat = guild.channels.cache.get(settings.category_id);
          if (cat && cat.children?.cache.size === 0) await cat.delete("J2C reset").catch(() => {});
        }
        db.prepare("DELETE FROM j2c_channels WHERE guild_id=?").run(guild.id);
        db.prepare("DELETE FROM j2c_settings  WHERE guild_id=?").run(guild.id);
        bustCache(guild.id);
        return message.reply("🔄 VoiceMaster đã được reset.");
      } catch (err) {
        console.error("[J2C] reset error:", err);
        return message.reply("❌ Reset thất bại.");
      }
    }

    // ── category ──────────────────────────────────────────
    if (sub === "category") {
      if (!isAdmin()) return message.reply("❌ Cần quyền Manage Guild.");
      const catId = rest[0]?.replace(/[^0-9]/g, "");
      const cat   = catId ? guild.channels.cache.get(catId) : null;
      db.prepare("UPDATE j2c_settings SET category_id=? WHERE guild_id=?").run(cat?.id ?? null, guild.id);
      bustCache(guild.id);
      return message.reply(cat ? `📁 Kênh sẽ được tạo trong **${cat.name}**.` : "📁 Đã xoá category.");
    }

    // ── default ───────────────────────────────────────────
    if (sub === "default") {
      if (!isAdmin()) return message.reply("❌ Cần quyền Manage Guild.");
      const [dsub, ...drest] = rest;

      if (!dsub) {
        const s = getSettings(guild.id);
        if (!s) return message.reply("❌ Chưa setup. Dùng `th!j2c setup` trước.");
        return message.reply({
          embeds: [new EmbedBuilder()
            .setTitle(`${BOT_NAME} | Cài đặt mặc định`)
            .setColor(0x5865F2)
            .addFields(
              { name: "✏️ Name",     value: s.default_name  || "{user}'s Channel",                          inline: true },
              { name: "👥 Limit",   value: s.default_limit ? `${s.default_limit}` : "Không giới hạn",      inline: true },
              { name: "📡 Bitrate", value: `${Math.round((s.default_bitrate || 64000) / 1000)} kbps`,      inline: true },
              { name: "🌍 Region",  value: s.default_region || "Tự động",                                  inline: true },
            )],
        });
      }

      if (dsub === "name") {
        const name = drest.join(" ");
        if (!name)             return message.reply("❌ Nhập tên. Dùng `{user}` làm placeholder.");
        if (name.length > 100) return message.reply("❌ Tên tối đa 100 ký tự.");
        db.prepare("UPDATE j2c_settings SET default_name=? WHERE guild_id=?").run(name, guild.id);
        bustCache(guild.id);
        return message.reply(`✏️ Tên mặc định: **${name}**`);
      }

      if (dsub === "limit") {
        const n = parseInt(drest[0]);
        if (isNaN(n) || n < 0 || n > 99) return message.reply("❌ Limit phải từ 0–99.");
        db.prepare("UPDATE j2c_settings SET default_limit=? WHERE guild_id=?").run(n, guild.id);
        bustCache(guild.id);
        return message.reply(n === 0 ? "👥 Đã xoá giới hạn mặc định." : `👥 Limit mặc định: **${n}**`);
      }

      if (dsub === "bitrate") {
        const n = parseInt(drest[0]);
        if (isNaN(n) || n < 8 || n > 384) return message.reply("❌ Bitrate phải từ 8–384 kbps.");
        db.prepare("UPDATE j2c_settings SET default_bitrate=? WHERE guild_id=?").run(n * 1000, guild.id);
        bustCache(guild.id);
        return message.reply(`📡 Bitrate mặc định: **${n} kbps**`);
      }

      if (dsub === "region") {
        const region = drest[0]?.toLowerCase() ?? null;
        if (region && !VALID_REGIONS.includes(region))
          return message.reply(`❌ Region không hợp lệ. Hợp lệ: \`${VALID_REGIONS.join(", ")}\``);
        db.prepare("UPDATE j2c_settings SET default_region=? WHERE guild_id=?").run(region, guild.id);
        bustCache(guild.id);
        return message.reply(region ? `🌍 Region mặc định: **${region}**` : "🌍 Region: **Tự động**");
      }

      return message.reply("❌ Sub-lệnh không hợp lệ. Thử: `name`, `limit`, `bitrate`, `region`.");
    }

    // ── Owner commands — phải đang trong VC ───────────────
    const voiceChannel = author.voice?.channel;
    if (!voiceChannel) return message.reply("❌ Bạn phải đang trong một voice channel.");

    function requireOwner() {
      if (!isOwner(voiceChannel.id, author.id)) {
        message.reply("❌ Bạn không phải chủ kênh này.");
        return false;
      }
      return true;
    }

    if (sub === "lock") {
      if (!requireOwner()) return;
      await lockChannel(voiceChannel).catch(() => {});
      return message.reply("🔒 Kênh đã được khoá.");
    }

    if (sub === "unlock") {
      if (!requireOwner()) return;
      await unlockChannel(voiceChannel).catch(() => {});
      return message.reply("🔓 Kênh đã được mở khoá.");
    }

    if (sub === "ghost") {
      if (!requireOwner()) return;
      await ghostChannel(voiceChannel).catch(() => {});
      return message.reply("👻 Kênh đã được ẩn.");
    }

    if (sub === "unghost") {
      if (!requireOwner()) return;
      await unghostChannel(voiceChannel).catch(() => {});
      return message.reply("👁️ Kênh đã được hiện.");
    }

    if (sub === "claim") {
      const ok = await claimChannel(voiceChannel, author);
      return message.reply(ok
        ? "🏳️ Đã nhận quyền sở hữu kênh."
        : "❌ Không thể claim. Chủ kênh vẫn đang trong kênh.");
    }

    if (sub === "configuration") {
      if (!requireOwner()) return;
      return message.reply({ embeds: [buildInfoEmbed(voiceChannel)] });
    }

    if (sub === "limit") {
      if (!requireOwner()) return;
      const n = parseInt(rest[0]);
      if (isNaN(n) || n < 0 || n > 99) return message.reply("❌ Limit phải từ 0–99.");
      await voiceChannel.edit({ userLimit: n }).catch(() => {});
      return message.reply(n === 0 ? "👥 Đã xoá giới hạn." : `👥 Giới hạn: **${n}**`);
    }

    if (sub === "name") {
      if (!requireOwner()) return;
      const name = rest.join(" ");
      if (!name)             return message.reply("❌ Nhập tên kênh.");
      if (name.length > 100) return message.reply("❌ Tên tối đa 100 ký tự.");
      await voiceChannel.edit({ name }).catch(() => {});
      return message.reply(`✏️ Đã đổi tên thành **${name}**.`);
    }

    if (sub === "bitrate") {
      if (!requireOwner()) return;
      const n = parseInt(rest[0]);
      if (isNaN(n) || n < 8 || n > 384) return message.reply("❌ Bitrate phải từ 8–384 kbps.");
      await voiceChannel.edit({ bitrate: n * 1000 }).catch(() => {});
      return message.reply(`📡 Bitrate: **${n} kbps**`);
    }

    if (sub === "status") {
      if (!requireOwner()) return;
      const text = rest.join(" ") || null;
      await voiceChannel.edit({ status: text }).catch(() => {});
      return message.reply(text ? `📝 Status: **${text}**` : "📝 Đã xoá status.");
    }

    if (sub === "transfer") {
      if (!requireOwner()) return;
      const targetId = rest[0]?.replace(/[^0-9]/g, "");
      const target   = targetId ? guild.members.cache.get(targetId) : null;
      if (!target)                                      return message.reply("❌ Mention một thành viên hợp lệ.");
      if (target.id === author.id)                      return message.reply("❌ Không thể transfer cho chính mình.");
      if (target.voice?.channelId !== voiceChannel.id)  return message.reply("❌ Thành viên đó phải đang trong kênh của bạn.");
      db.prepare("UPDATE j2c_channels SET owner_id=? WHERE channel_id=?").run(target.id, voiceChannel.id);
      await voiceChannel.permissionOverwrites.delete(author).catch(() => {});
      await voiceChannel.permissionOverwrites.edit(target, {
        ManageChannels: true, ManageRoles: true,
        MoveMembers: true, MuteMembers: true, DeafenMembers: true,
      }).catch(() => {});
      return message.reply(`👑 Đã chuyển quyền sở hữu cho **${target.displayName}**.`);
    }

    if (sub === "permit") {
      if (!requireOwner()) return;
      const targetId = rest[0]?.replace(/[^0-9]/g, "");
      const target   = targetId ? (guild.members.cache.get(targetId) || guild.roles.cache.get(targetId)) : null;
      if (!target) return message.reply("❌ Mention một thành viên hoặc role.");
      await voiceChannel.permissionOverwrites.edit(target, { Connect: true }).catch(() => {});
      return message.reply(`✅ **${target.displayName ?? target.name}** có thể vào kênh.`);
    }

    if (sub === "reject") {
      if (!requireOwner()) return;
      const targetId = rest[0]?.replace(/[^0-9]/g, "");
      const target   = targetId ? (guild.members.cache.get(targetId) || guild.roles.cache.get(targetId)) : null;
      if (!target) return message.reply("❌ Mention một thành viên hoặc role.");
      await voiceChannel.permissionOverwrites.edit(target, { Connect: false }).catch(() => {});
      if (target.voice?.channelId === voiceChannel.id) await target.voice.disconnect().catch(() => {});
      return message.reply(`⛔ **${target.displayName ?? target.name}** bị chặn khỏi kênh.`);
    }

    if (sub === "disconnect") {
      if (!requireOwner()) return;
      const targetId = rest[0]?.replace(/[^0-9]/g, "");
      const target   = targetId ? guild.members.cache.get(targetId) : null;
      if (!target)                                     return message.reply("❌ Mention một thành viên hợp lệ.");
      if (target.voice?.channelId !== voiceChannel.id) return message.reply("❌ Thành viên đó không ở trong kênh của bạn.");
      await target.voice.disconnect().catch(() => {});
      return message.reply(`👢 **${target.displayName}** đã bị disconnect.`);
    }

    return message.reply(`❌ Sub-lệnh \`${sub}\` không tồn tại. Dùng \`!j2c help\`.`);
  },
};
