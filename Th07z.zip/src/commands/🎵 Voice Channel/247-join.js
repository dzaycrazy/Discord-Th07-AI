const { joinVoiceChannel } = require("@discordjs/voice");
const { setAFK, removeAFK } = require("../../utils/afkManager");
const Database = require("better-sqlite3");

// ===== DB =====
const db = new Database("dzay-vc.db");

db.exec(`
CREATE TABLE IF NOT EXISTS afk_voice (
  guild_id TEXT PRIMARY KEY,
  channel_id TEXT
);
`);

module.exports = {
  name: "247",
  aliases: ["afkvoice", "vc", "join"],
  category: "voice",
  cooldown: 3,
  premium: true,

  run: async (client, message) => {

    const member = message.member;

    if (!member.voice.channel)
      return message.reply("<:disabled:1487783250452545616> Bạn phải ở voice channel!");

    const voiceChannel = member.voice.channel;

    const permissions = voiceChannel.permissionsFor(message.guild.members.me);
    if (!permissions?.has("Connect") || !permissions?.has("Speak"))
      return message.reply("<:disabled:1487783250452545616> Bot không đủ quyền vào voice!");

    // ===== LƯU RAM =====
    setAFK(message.guild.id, voiceChannel.id);

    // ===== LƯU DB =====
    db.prepare(`
      INSERT OR REPLACE INTO afk_voice (guild_id, channel_id)
      VALUES (?, ?)
    `).run(message.guild.id, voiceChannel.id);

    // ===== JOIN =====
    const connect = () => {
      const connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: message.guild.id,
        adapterCreator: message.guild.voiceAdapterCreator,
        selfDeaf: true,
        selfMute: true,
      });

      connection.on("error", () => {
        setTimeout(connect, 5000);
      });
    };

    connect();

    return message.reply(
      `<:enable:1487783260565143614> Đã bật 24/7 AFK tại **${voiceChannel.name}**`
    );
  },

  // ===== AUTO REJOIN KHI BOT START =====
  init: (client) => {
    client.once("ready", async () => {
      console.log("🔄 AFK Voice loading...");

      const rows = db.prepare(`SELECT * FROM afk_voice`).all();

      for (const data of rows) {
        const guild = client.guilds.cache.get(data.guild_id);
        if (!guild) continue;

        const channel = guild.channels.cache.get(data.channel_id);
        if (!channel) {
          // xoá DB nếu channel mất
          db.prepare(`DELETE FROM afk_voice WHERE guild_id = ?`)
            .run(data.guild_id);
          continue;
        }

        try {
          joinVoiceChannel({
            channelId: channel.id,
            guildId: guild.id,
            adapterCreator: guild.voiceAdapterCreator,
            selfDeaf: true,
            selfMute: true,
          });

          setAFK(guild.id, channel.id);

          console.log(`🔊 Rejoined: ${channel.name}`);
        } catch (err) {
          console.log("❌ Lỗi rejoin:", err);
        }
      }
    });
  }
};