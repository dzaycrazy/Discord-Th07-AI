const {
  EmbedBuilder,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

const Database = require("better-sqlite3");
const db = new Database("dzay-vc.db");

module.exports = {
  name: "247list",
  aliases: ["afklist"],
  category: "voice",
  cooldown: 3,

  run: async (client, message) => {

    const owners = client.config.ownerID || client.config.owner || [];
    if (!owners.includes(message.author.id)) {
      return message.reply("<:disabled:1487783250452545616> Bạn không được phép dùng");
    }

    // ===== LẤY DB =====
    const rowsDB = db.prepare(`SELECT * FROM afk_voice`).all();

    if (!rowsDB.length) {
      return message.reply("<:skull:1492126467574992936> Không có server AFK");
    }

    const embed = new EmbedBuilder()
      .setColor("#00ff99")
      .setTitle("<:hoanghot:1492128357817651450> Danh sách AFK")
      .setThumbnail(client.user.displayAvatarURL())
      .setDescription("Danh sách server đang AFK , với nút join bên dưới")
      .setTimestamp();

    // =========================
    // BUTTONS
    // =========================
    const rows = [];
    let currentRow = new ActionRowBuilder();
    let count = 0;

    for (const data of rowsDB) {

      const guild = client.guilds.cache.get(data.guild_id);
      const channel = guild?.channels?.cache.get(data.channel_id);

      let url = "https://discord.com";

      try {
        if (
          channel &&
          guild.members.me.permissions.has(PermissionsBitField.Flags.CreateInstantInvite)
        ) {
          const invite = await channel.createInvite({
            maxAge: 0,
            maxUses: 0
          });

          url = `https://discord.gg/${invite.code}`;
        }
      } catch {}

      const btn = new ButtonBuilder()
        .setLabel((guild?.name || "Unknown").slice(0, 20))
        .setStyle(ButtonStyle.Link)
        .setURL(url)
        .setEmoji("1492132251608158338");

      currentRow.addComponents(btn);
      count++;

      if (currentRow.components.length === 5) {
        rows.push(currentRow);
        currentRow = new ActionRowBuilder();
      }

      if (count === 25) break;
    }

    if (currentRow.components.length) rows.push(currentRow);

    embed.addFields(
      {
        name: "<:automod:1487785352612548638> Tổng số máy chủ AFK",
        value: `\`${rowsDB.length}\``,
        inline: true
      },
      {
        name: "<:ass:1492125965688635532> Đang hiển thị",
        value: `\`${Math.min(rowsDB.length, 25)} / ${rowsDB.length}\``,
        inline: true
      }
    );

    return message.reply({
      embeds: [embed],
      components: rows
    });
  }
};