const { EmbedBuilder } = require("discord.js");

const gifs = [
  "https://cdn.discordapp.com/attachments/965979549533872319/965979631041789993/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/965979664352968714/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/965979778542878750/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/965979800223227984/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/965979846381559838/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/965979902828511272/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/965980336204939294/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/965980358581563402/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/965981047575699476/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/1130879728748875846/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/1130880425468895252/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/1151397341316784138/assfuck.gif",
  "https://cdn.discordapp.com/attachments/965979549533872319/1151398068277760110/assfuck.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "assfuck",
  aliases: ["fuckass"],
  description: "NSFW đóng vai địt 🍑",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử...`;
      } else {
        actionText = `<:ass:1492125965688635532> <@${message.author.id}> vừa *đụ đít* <@${target.id}> <:hoanghot:1492128357817651450>`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm mục tiêu...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố đụ ai đó bằng đít **\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};