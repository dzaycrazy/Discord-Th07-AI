const { EmbedBuilder } = require("discord.js");

const gifs = [
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331989763401453620/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331990109079339009/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331988979528237067/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331989045588525078/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331989125468913724/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331989195266330644/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331989854258462852/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331989927197544581/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331989997242286092/squirt.gif",
  "https://cdn.discordapp.com/attachments/1331988926834933872/1331990056977694760/squirt.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "squirting",
  aliases: ["squirt"],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("Phải dùng trong kênh NSFW!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử 💦...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> làm <@${target.id}> 💦💦`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để 💦...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố cho ${target.id} ra 💦**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};