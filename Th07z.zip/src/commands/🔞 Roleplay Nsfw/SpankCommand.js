const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/736274084488282113/736274092105269308/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/736274115195043931/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/736274130747523072/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/736274138632552478/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/736274153820127362/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/736274160266903674/spank.gif",

  // MTF
  "https://cdn.discordapp.com/attachments/736274084488282113/736274104361025606/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/736274143187828757/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842096350789692/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842212650844160/spank.gif",

  // ATF
  "https://cdn.discordapp.com/attachments/736274084488282113/834842062976188456/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842075178467389/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842123806965790/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842136088150016/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842148817862656/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842161659904100/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842176428703824/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842192396288040/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842232880234516/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/834842252601065562/spank.gif",

  // ATA
  "https://cdn.discordapp.com/attachments/736274084488282113/736274118776979483/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/736274121486237736/spank.gif",
  "https://cdn.discordapp.com/attachments/736274084488282113/736274125311443056/spank.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "spank",
  aliases: [],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh NSFW!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *đánh mông* <@${target.id}> <:ass:1492125965688635532>`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *đánh mông*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đánh cố đánh mông <:ass:1492125965688635532>**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};