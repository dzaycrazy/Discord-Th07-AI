
const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/834493654742728764/834493985648541776/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494003180994660/boobsgrab.gif",

  // MTF
  "https://cdn.discordapp.com/attachments/834493654742728764/834493853951721502/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834493927197114429/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834493958905659422/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494080339148840/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494112286638210/boobsgrab.gif",

  // ATF
  "https://cdn.discordapp.com/attachments/834493654742728764/834493865028616232/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834493902748647424/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834493914957742110/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834493941012758578/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834493971501154316/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494014942085190/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494026912104528/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494039390552114/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494053588140053/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494066951323658/boobsgrab.gif",
  "https://cdn.discordapp.com/attachments/834493654742728764/834494093999734792/boobsgrab.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "boobsgrab",
  aliases: ["boobgrab", "grabboobs", "tittygrab", "grabtitty", "titsgrab", "grabtits"],
  description: "NSFW nhập vai sờ vú 🍒",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự bóp bản thân...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> vừa *bóp vú* <@${target.id}> 🍒`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *bóp vú*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố bóp vú 🍒**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};