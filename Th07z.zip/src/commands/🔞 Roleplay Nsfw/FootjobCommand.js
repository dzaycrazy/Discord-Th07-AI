
const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/884506240179372112/884506586196885604/footjob.gif",

  // FTM
  "https://cdn.discordapp.com/attachments/884506240179372112/884506336732278844/footjob.gif",
  "https://cdn.discordapp.com/attachments/884506240179372112/884506781299126302/footjob.gif",
  "https://cdn.discordapp.com/attachments/884506240179372112/884506860911231016/footjob.gif",
  "https://cdn.discordapp.com/attachments/884506240179372112/884507081099608134/footjob.gif",
  "https://cdn.discordapp.com/attachments/884506240179372112/884507187127410708/footjob.gif",
  "https://cdn.discordapp.com/attachments/884506240179372112/884507241447837748/footjob.gif",
  "https://cdn.discordapp.com/attachments/884506240179372112/884507559057317938/footjob.gif",
  "https://cdn.discordapp.com/attachments/884506240179372112/1151399334278074398/footjob.gif",

  // MTF
  "https://cdn.discordapp.com/attachments/884506240179372112/884506706317570079/footjob.gif",

  // ATM
  "https://cdn.discordapp.com/attachments/884506240179372112/884506467409989642/footjob.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "footjob",
  aliases: ["feetjob", "feet"],
  description: "NSFW nhập vai mát-xa cu 🦶",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *mát xa dương vật bằng chân* <@${target.id}> 🦶`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *mát xa dương vật bằng chân*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố mát xa dương vật bằng chân 🦶**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};