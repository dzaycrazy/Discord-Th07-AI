const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/958005774603386881/958007654524002344/finger.gif",
  "https://cdn.discordapp.com/attachments/958005774603386881/958007878634053703/finger.gif",

  // MTF
  "https://cdn.discordapp.com/attachments/958005774603386881/958007701223391292/finger.gif",
  "https://cdn.discordapp.com/attachments/958005774603386881/958007761629757470/finger.gif",
  "https://cdn.discordapp.com/attachments/958005774603386881/958007818340937748/finger.gif",

  // ATF
  "https://cdn.discordapp.com/attachments/958005774603386881/958007005254140005/finger.gif",
  "https://cdn.discordapp.com/attachments/958005774603386881/958007071817760838/finger.gif",
  "https://cdn.discordapp.com/attachments/958005774603386881/958007294594015252/finger.gif",
  "https://cdn.discordapp.com/attachments/958005774603386881/958007513561853983/finger.gif",
  "https://cdn.discordapp.com/attachments/958005774603386881/958007592087613440/finger.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "finger",
  aliases: [],
  description: "NSFW nhập vai ngón tay 👇",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử.....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *móc* <@${target.id}> `;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *móc*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố móc **\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};