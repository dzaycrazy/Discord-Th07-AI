const { EmbedBuilder } = require("discord.js");

const gifs = [
  "https://cdn.discordapp.com/attachments/834844814671478824/834844931423993946/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834844958598758421/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834844969951952916/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834844981931409438/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834844998775078952/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845029348409364/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845041263378501/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845053163536404/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845068141133874/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845083684962364/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845094661718016/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845106716540988/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845117496033280/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845130196385832/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845146393739284/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/834845159539081226/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/881905383625596959/tittyfuck.gif",
  "https://cdn.discordapp.com/attachments/834844814671478824/881905488055377960/tittyfuck.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "tittyfuck",
  aliases: ["titjob", "titfuck", "boobfuck", "boobsfuck"],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("Phải dùng trong kênh xác minh độ tuổi !");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *tương tác* với <@${target.id}> <:ass:1492125965688635532>`;
      }
    } else {
      actionText = `<:search:1492132251608158338> <@${message.author.id}> đang tìm ai đó...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố đụ bằng vú <:ass:1492125965688635532>**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};