
const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTM
  "https://cdn.discordapp.com/attachments/834831425651474442/834831757462208613/masturbate.gif",

  // FTA
  "https://cdn.discordapp.com/attachments/834831425651474442/834831584216481802/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831608800215060/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831631893135380/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831683081207919/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831694942044260/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831705964544071/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831745881997382/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831769156845608/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831780376477816/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831790748467220/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831804020162660/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831815612825643/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/834831827457802271/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/881905216432259072/masturbate.gif",
  "https://cdn.discordapp.com/attachments/834831425651474442/958006810047045662/masturbate.gif",

  // MTA
  "https://cdn.discordapp.com/attachments/834831425651474442/834831559366279178/masturbate.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "masturbate",
  aliases: ["fap", "jerkoff", "thudam"],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh NSFW!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *thủ dâm* trước mặt <@${target.id}> 💦`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó....`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố thủ dâm**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};