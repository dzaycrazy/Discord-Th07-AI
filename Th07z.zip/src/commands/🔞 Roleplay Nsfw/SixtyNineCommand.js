
const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/969973669126340758/969973986052153364/69.gif",

  // FTM
  "https://cdn.discordapp.com/attachments/969973669126340758/969973746679046154/69.gif",
  "https://cdn.discordapp.com/attachments/969973669126340758/969974210329997363/69.gif",
  "https://cdn.discordapp.com/attachments/969973669126340758/969974239987892304/69.gif",
  "https://cdn.discordapp.com/attachments/969973669126340758/969974274003714068/69.gif",
  "https://cdn.discordapp.com/attachments/969973669126340758/969974337576796180/69.gif",
  "https://cdn.discordapp.com/attachments/969973669126340758/969974368648175706/69.gif",
  "https://cdn.discordapp.com/attachments/969973669126340758/969974394178928660/69.gif",
  "https://cdn.discordapp.com/attachments/969973669126340758/969974427569762314/69.gif",
  "https://cdn.discordapp.com/attachments/969973669126340758/1220286428055867443/69.gif",

  // FTA
  "https://cdn.discordapp.com/attachments/969973669126340758/969974301258293268/69.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "69",
  aliases: ["sixtynine", "sau9", "sauchin", "69tuthe"],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh NSFW!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *làm tư thế số 69* với <@${target.id}> 👅`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *làm tư thế số 69*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang làm tư thế số 69 👅**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};