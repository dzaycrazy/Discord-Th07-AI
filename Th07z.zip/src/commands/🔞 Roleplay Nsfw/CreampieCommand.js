const { EmbedBuilder } = require("discord.js");

// =========================
// GIFS
// =========================
const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/955839621902774272/955839871052808292/creampie.gif",

  // MTF
  "https://cdn.discordapp.com/attachments/955839621902774272/955839955505139752/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955840066230554644/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955840111520649216/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955840159235063818/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955840213391912960/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955840275845115924/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955840306388029460/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955840998074896384/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955841342288842812/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955842304869027890/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/955842659140898816/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/1073601527287119964/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/1073602819321507840/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/1073602940889206824/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/1073603217922994237/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/1073603841506955345/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/1073604277651648532/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/1130880259626111097/creampie.gif",
  "https://cdn.discordapp.com/attachments/955839621902774272/1151398338701299783/creampie.gif",

  // ATA
  "https://cdn.discordapp.com/attachments/955839621902774272/1073604357951606784/creampie.gif"
];

// =========================
// RANDOM
// =========================
const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "creampie",
  aliases: ["impregnate"],
  description: "NSFW nhập vai xuất tinh vô lồn 🥧",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> vừa *xuất vô bên trong lồn* <@${target.id}> 🥧`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *xuất tinh vô lồn*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Xuất bên vô lồn 🥧**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};