const { EmbedBuilder } = require("discord.js");

const gifs = [
                "https://cdn.discordapp.com/attachments/736281485216317442/736281817845596320/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281899454169198/fuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283244990955611/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283255959060520/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283260031860786/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283266994405406/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283284023017492/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283293082714193/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283297788854282/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283343087206550/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283350062334032/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283359470157844/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283393096024134/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283405695713380/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283415682351104/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283431201276014/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283456941719642/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283473274339388/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283490856992858/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/736283499455053854/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/834849298096717874/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/834849312219463680/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736283166758797324/863573933479428176/yurifuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281490484363344/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281495257219112/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281501951590430/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281505260765235/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281509488754740/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281518988853358/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281529122029628/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281556859224074/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281570234728488/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281590858252368/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281600660209695/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281606838550562/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281611712331796/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281619572195378/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281724828254241/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281746059952168/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281750543532126/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281763680092190/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281774547665016/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281794927919164/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281798841204846/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281806084767861/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281826154250270/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281834740252833/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281838242496602/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281848426135582/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281854746951870/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281859821928529/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281866805706752/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281876154810408/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281881833897984/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281887823233105/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281906164924526/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281915144929311/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281920832405624/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281925446139924/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736281929590243489/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736282288844963891/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/736282318788100157/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504681929441340/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504694314434641/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504706431647754/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504717995999282/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504729135546428/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504740397907968/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504751953346620/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504764301639770/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504779337564220/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504793681821756/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504805186666517/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504819333922876/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504831435014174/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504843614748672/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504856135794739/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504868944412682/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504880298524702/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504891498102814/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504903023657000/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504915186483252/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504941166395513/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504957121789993/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834504993163444294/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505557791735898/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505568831144016/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505579565285417/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505592860704788/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505605435490414/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505616780427324/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505628352512010/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505640805531668/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505654043017216/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505669088509970/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505681498800138/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505696023150662/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505710149959710/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505729607335987/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505743930753084/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505758375936021/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505769625976873/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505780685963354/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505792626753566/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505805549273098/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505825778270329/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505841902223452/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505854895259678/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505876944453692/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505937364320316/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505950391566376/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505963209621514/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505974165405766/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834505987490578529/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834506000609837096/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834506018188165160/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/834506032612114492/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/839471780678991882/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/839471858193530910/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881903289946484776/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881903723922731129/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881903786346549259/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881903844748046406/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881903908941873172/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881903968723275786/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881904031323287592/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881904123405021264/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/881904190358704148/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/1130880574412828672/fuck.gif",
                "https://cdn.discordapp.com/attachments/736281485216317442/1220286272581668864/fuck.gif",
 "https://cdn.discordapp.com/attachments/736282657062912080/736282666126540870/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282674771001514/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282683608662021/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282721147683077/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282730442129498/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282734363803758/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282742261547120/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282750390239425/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282759458193438/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282769197629490/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282776311169034/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282784410370148/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282790647169085/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282865708564560/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282873144803418/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282877402021888/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736282999921967134/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736283005601054860/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736283034310934608/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736283038224351272/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736283045077975081/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736283049439789066/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736283053487292446/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/736283058642223154/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848432635772928/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848443721187359/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848457453862964/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848479415107594/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848493922156544/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848505100370000/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848518304694292/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848533659123723/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848548377591848/yaoifuck.gif",
                "https://cdn.discordapp.com/attachments/736282657062912080/834848562604802068/yaoifuck.gif"

];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "fuck",
  aliases: ["chich", "du"],
  description: "NSFW đụ ai đó",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *chịch* <@${target.id}> <:ass:1492125965688635532>`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *chịch*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố chịch <:ass:1492125965688635532>**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
