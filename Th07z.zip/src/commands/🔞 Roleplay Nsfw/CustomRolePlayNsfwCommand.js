
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "customrp_nsfw",
  aliases: ["comrp"],
  description: "Nhập vai NSFW tùy chỉnh 🧩",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    if (!args.length) {
      return message.reply("<:disabled:1487783250452545616> Vui lòng nhập hành động (vd: th!comrp ôm @user)");
    }

    const target = message.mentions.users.first();
    const now = Math.floor(Date.now() / 1000);

    // remove mention khỏi text
    const text = args.join(" ").replace(/<@!?\d+>/, "").trim();

    let actionText;

    if (target) {
      actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> ${text} <@${target.id}>`;
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> ${text}`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Nhập vai Nsfw tùy chỉnh")
      .setDescription(
        `**Hành động tự chỉnh 🧩**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};