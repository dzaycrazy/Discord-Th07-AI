const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/964484282984857610/964484953062670336/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/964484985551740948/pussyeat.gif",

  // MTF
  "https://cdn.discordapp.com/attachments/964484282984857610/964484568642125854/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/964484607351357521/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/964484793255460934/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/964484837744476180/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/964484887572774972/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/964484920548401192/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/964485018485399622/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/964485051599446016/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/1054775394622001182/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/1054775458006306986/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/1054775595931795486/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/1054775652936601620/pussyeat.gif",
  "https://cdn.discordapp.com/attachments/964484282984857610/1054775911792246845/pussyeat.gif",

  // ATF
  "https://cdn.discordapp.com/attachments/964484282984857610/1054775530748133486/pussyeat.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "pussyeat",
  aliases: ["eatpussy", "anlon", "lon"],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh NSFW!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *đang bú lồn* <@${target.id}> 👅`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *bú lồn*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố bú lồn 👅**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};