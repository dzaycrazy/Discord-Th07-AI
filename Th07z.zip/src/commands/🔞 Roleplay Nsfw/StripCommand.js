const { EmbedBuilder } = require("discord.js");

const gifs = [
  "https://cdn.discordapp.com/attachments/991784316881346601/991784604409266346/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991784967526944898/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991785174650077314/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991785592281125035/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991785635851538482/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991785735772459008/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991785912402968667/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991786585706221688/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991787556666605608/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991786888086179961/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991787181708423278/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991785726549180466/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991786090379882637/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991786363856879686/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991786604555423806/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991787148158173315/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991787453683879967/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991787670604877884/strip.gif",
  "https://cdn.discordapp.com/attachments/991784316881346601/991787737667621034/strip.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "strip",
  aliases: ["undress"],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("Phải dùng trong kênh NSFW!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự cởi đồ...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *lột đồ* <@${target.id}> <:ass:1492125965688635532>`;
      }
    } else {
      actionText = `<:search:1492132251608158338> <@${message.author.id}> đang tìm ai đó để *lột đồ*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố lột quần áo <:ass:1492125965688635532>**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};