
const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220284060488831017/bathroomfuck.gif",

  // FTM
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220283477610729625/bathroomfuck.gif",
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220283805383004160/bathroomfuck.gif",
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220283866464518264/bathroomfuck.gif",
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220283937373425674/bathroomfuck.gif",
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220283998715121735/bathroomfuck.gif",
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220284131129294898/bathroomfuck.gif",
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220284200327057509/bathroomfuck.gif",
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220284257575108658/bathroomfuck.gif",
  "https://cdn.discordapp.com/attachments/1220283255580921856/1220284437393051678/bathroomfuck.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "bathroomfuck",
  aliases: ["bathfuck"],
  description: "NSFW đóng vai trong phòng tắm 🛁",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự chơi trong phòng tắm...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> vừa *bathroomfuck* <@${target.id}> <:bathroom:1492134605774520421>`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó trong phòng tắm...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố đụ ai đó trong phòng tắm <:bathroom:1492134605774520421>**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};