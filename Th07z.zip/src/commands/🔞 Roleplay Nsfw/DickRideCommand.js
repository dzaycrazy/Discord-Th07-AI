const { EmbedBuilder } = require("discord.js");

// =========================
// GIFS
// =========================
const gifs = [
  "https://cdn.discordapp.com/attachments/969967119469019136/969967204336549938/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969967744403517520/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969967825382940702/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969967859918856222/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969967894752559114/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969967934040596500/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969967969511833630/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969967999471743066/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969968026818580530/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969968480147357839/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/969968872272830474/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/1151398675667501086/dickride.gif",
  "https://cdn.discordapp.com/attachments/969967119469019136/1151398874825637908/dickride.gif"
];

// =========================
// RANDOM
// =========================
const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "dickride",
  aliases: ["ridedick"],
  description: "NSFW nhập vai cưỡi dương vật 🍆",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang cho <@${target.id}> *cưỡi một con cặc của họ* 🍆`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *cưỡi dương vật*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cho cưỡi con cặc 🍆**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};