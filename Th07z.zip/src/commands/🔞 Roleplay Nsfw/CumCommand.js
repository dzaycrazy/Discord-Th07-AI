
const { EmbedBuilder } = require("discord.js");

// =========================
// GIFS
// =========================
const gifs = [
  // MTF
  "https://cdn.discordapp.com/attachments/834500528426844160/834500917847916605/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834500928869761044/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834500940002230332/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834500964269686784/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834500991411945482/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834501054635704420/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834501065961111622/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834501078753476639/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834501092069998622/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834501103655190548/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834501115449180200/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834501127272923217/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/834501140014956624/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/839471906024849408/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/881904994863951873/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/881905088447250443/cum.gif",
  "https://cdn.discordapp.com/attachments/834500528426844160/1151397084436627466/cum.gif",

  // ATF
  "https://cdn.discordapp.com/attachments/834500528426844160/834500951191584809/cum.gif"
];

// =========================
// RANDOM
// =========================
const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "cum",
  aliases: ["semen"],
  description: "NSFW nhập vai xuất tinh 💦",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> vừa *xuất tinh* vào <@${target.id}> 💦`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *xuất tinh*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố xuất tinh 💦**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};