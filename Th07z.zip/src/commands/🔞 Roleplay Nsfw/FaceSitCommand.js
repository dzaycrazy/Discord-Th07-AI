const { EmbedBuilder } = require("discord.js");

const gifs = [
  "https://cdn.discordapp.com/attachments/969970754944909332/1220286016531992606/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971027041980457/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971063696031764/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971096717766666/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971128468668467/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971163793063986/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971197976657970/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971565989093406/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971921791893504/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971959108620319/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969971995544526868/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/969972020102185020/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/1130881488284561530/facesit.gif",
  "https://cdn.discordapp.com/attachments/969970754944909332/1130882325698314361/facesit.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "facesit",
  aliases: ["sitface"],
  description: "NSFW nhập vai ngồi lên mặt 🪑",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *ngồi lên mặt* <@${target.id}> 🪑`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *ngồi lên mặt*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố ngồi lên mặt 🪑**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
