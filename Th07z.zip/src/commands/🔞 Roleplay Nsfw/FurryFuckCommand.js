const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/736283579457208414/736283802317619250/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283818163437698/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283848052047913/furryfuck.gif",

  // FTM
  "https://cdn.discordapp.com/attachments/736283579457208414/736283596993855548/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283604535214100/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283613531734127/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283618409840717/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283623678017606/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283792360341594/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283808466206780/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283993590202538/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506911276728330/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506927178383420/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506943896223794/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506981464473610/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506994937102407/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834507010568486962/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834507023235153954/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834507036699263026/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834507047667236874/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834507066743717908/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834507432750350346/furryfuck.gif",

  // MTM
  "https://cdn.discordapp.com/attachments/736283579457208414/736283644867379220/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283650022178907/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283677222502400/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283685443338340/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283693911507024/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283785569632296/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283824652156938/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283830163472479/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506896194535534/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834507078596427786/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834507707331379240/furryfuck.gif",

  // MTA
  "https://cdn.discordapp.com/attachments/736283579457208414/736283636428570634/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/736283774983340102/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506853157175356/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506955405000804/furryfuck.gif",
  "https://cdn.discordapp.com/attachments/736283579457208414/834506966902243348/furryfuck.gif"

];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "furryfuck",
  aliases: [],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh NSFW!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự tương tác...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang tương tác với <@${target.id}> 🦊`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để tương tác...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Tương tác thú 🦊**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};
