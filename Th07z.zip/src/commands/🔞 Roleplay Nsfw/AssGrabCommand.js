
const { EmbedBuilder } = require("discord.js");

const gifs = [
  // MTF
  "https://cdn.discordapp.com/attachments/834460432818241566/834461989321441300/assgrab.gif",

  // ATF
  "https://cdn.discordapp.com/attachments/834460432818241566/834461925894127651/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/834461937664000040/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/834461948993208340/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/834461961277931610/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/834461976402460732/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/834462003274711077/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/834462015236997191/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/834462028906233866/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/834462042706542643/assgrab.gif",
  "https://cdn.discordapp.com/attachments/834460432818241566/881905588206968832/assgrab.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "assgrab",
  aliases: ["grabass"],
  description: "NSFW nhập vai sờ mông 🍑",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự bóp bản thân....`;
      } else {
        actionText = `<:ass:1492125965688635532> <@${message.author.id}> vừa *nắm mông* <@${target.id}> <:hoanghot:1492128357817651450>`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *nắm mông*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố sờ mong <:ass:1492125965688635532>**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};