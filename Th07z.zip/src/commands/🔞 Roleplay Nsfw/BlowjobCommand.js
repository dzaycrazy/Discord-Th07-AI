const { EmbedBuilder } = require("discord.js");

const gifs = [
  "https://cdn.discordapp.com/attachments/834490895260844032/834491115314610277/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491215537242182/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491235456516156/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491248382705684/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491260789063700/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491273691136041/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491298353381446/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491311238283315/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491323016806531/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491339138924574/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/834491350865936434/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/881904390376673330/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/881904479627255828/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/881904551949635604/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/881904674318471258/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/881904763275452466/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/881904859471818862/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/1130880678553190550/blowjob.gif",
  "https://cdn.discordapp.com/attachments/834490895260844032/1130881299943522397/blowjob.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "blowjob",
  description: "NSFW đóng vai quan hệ tình dục bằng miệng 🍆",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *quan hệ tình dục bằng miệng* <@${target.id}> 🍆`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *quan hệ tình dục bằng miệng*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**quan hệ tình dục bằng miệng 🍆**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
