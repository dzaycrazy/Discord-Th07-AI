
const { EmbedBuilder } = require("discord.js");

// =========================
// GIFS
// =========================
const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/965983252718428230/965983462442008606/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985092562473050/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985320116027472/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985699201425429/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985737621266462/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985802683310220/boobsuck.gif",

  // MTF
  "https://cdn.discordapp.com/attachments/965983252718428230/965983495983866007/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965983534370140211/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985028876169226/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985344984064000/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985776829628496/boobsuck.gif",
  "https://cdn.discordapp.com/attachments/965983252718428230/965985839802904626/boobsuck.gif"
];

// =========================
// RANDOM
// =========================
const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "boobsuck",
  aliases: ["boobssuck", "boobysuck", "suckboob", "suckboobs"],
  description: "NSFW nhập vai bú vú 🍒",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự bú vú`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *bú vú* <@${target.id}> 🍒`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *bú vú*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Bú vú 🍒**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};