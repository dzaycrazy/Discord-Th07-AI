
const { EmbedBuilder } = require("discord.js");

const gifs = [
  "https://cdn.discordapp.com/attachments/972916898436108318/972917081148391454/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972917114388238427/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972917143890952322/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972918667597721740/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972918776725114890/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972918826708652102/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972918853464121344/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972919151293235340/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972919627866832946/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/972919659026341989/handjob.gif",
  "https://cdn.discordapp.com/attachments/972916898436108318/1130879599786594414/handjob.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "handjob",
  aliases: [],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh NSFW!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự tương tác...`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang tương tác với <@${target.id}>`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để tương tác...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Tương tác bằng tay**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};