
const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/992100317430808596/992101961530884106/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102611161452627/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992103003421155369/bondage.gif",

  // FTM
  "https://cdn.discordapp.com/attachments/992100317430808596/992100428948979812/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992100462910251138/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992100531730399232/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992100634566332536/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992101619682529340/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992101757272473641/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102066786934914/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102158830927932/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102227747536906/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102373361205328/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102694632300656/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102732100010094/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992103053899612170/bondage.gif",

  // FTA
  "https://cdn.discordapp.com/attachments/992100317430808596/992100561044373504/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992100598008791151/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992101666738413668/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992101812880551986/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102032339120198/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102275608752288/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102396731859064/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102795694055424/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102840464048168/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102896101503057/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992102941173485639/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992103090830454804/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992103134992269392/bondage.gif",
  "https://cdn.discordapp.com/attachments/992100317430808596/992103175530229840/bondage.gif",

  // ATA
  "https://cdn.discordapp.com/attachments/992100317430808596/992101997643841596/bondage.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "bondage",
  aliases: ["gag"],
  description: "NSFW đóng vai nô lệ 🪢",
  category: "nsfw",
  subCategory: "Nội dung nhập vai",
  cooldown: 3,
  nsfw: true,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi!");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự trói bản thân..`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đang *trói buộc* <@${target.id}> <:leather:1492144270029754559>`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *trói buộc*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố trói <:leather:1492144270029754559>**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};