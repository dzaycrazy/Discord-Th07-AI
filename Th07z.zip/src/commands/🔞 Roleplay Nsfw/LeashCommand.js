const { EmbedBuilder } = require("discord.js");

const gifs = [
  // FTF
  "https://cdn.discordapp.com/attachments/955835975609749534/955836190802718761/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836254405132338/leash.gif",

  // MTF
  "https://cdn.discordapp.com/attachments/955835975609749534/955836016932032512/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836092060418118/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836134854897734/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836316136906752/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836365025738823/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836425654382672/leash.gif",

  // ATF
  "https://cdn.discordapp.com/attachments/955835975609749534/955836504767344740/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836549789007933/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836603476099122/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/955836699726979102/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/992098894043414559/leash.gif",
  "https://cdn.discordapp.com/attachments/955835975609749534/992098924506644601/leash.gif"
];

const randomGif = () => gifs[Math.floor(Math.random() * gifs.length)];

module.exports = {
  name: "leash",
  aliases: [],
  nsfw: true,
  subCategory: "Nội dung nhập vai",
  cooldown: 3,

  async execute(client, message, args) {
    if (!message.channel.nsfw) {
      return message.reply("<:disabled:1487783250452545616> Phải dùng trong kênh xác minh độ tuổi !");
    }

    const target = message.mentions.users.first();
    const gif = randomGif();
    const now = Math.floor(Date.now() / 1000);

    let actionText;

    if (target) {
      if (target.id === message.author.id) {
        actionText = `<:skull:1492126467574992936> <@${message.author.id}> đang tự xử....`;
      } else {
        actionText = `<:hoanghot:1492128357817651450> <@${message.author.id}> đã *dây xích* <@${target.id}> 🐕`;
      }
    } else {
      actionText = `<:ass:1492125965688635532> <@${message.author.id}> đang tìm ai đó để *xích*...`;
    }

    const embed = new EmbedBuilder()
      .setColor(0xff4d6d)
      .setTitle("<:nsfw:1491794522441515109> Tương tác Nsfw")
      .setDescription(
        `**Đang cố xích 🐕**\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `${actionText}\n\n` +
        `-# ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
        `> <:clock:1489894867122262036> **Thời gian:** <t:${now}:F>\n` +
        `> <:search:1492132251608158338> **Kênh chat:** <#${message.channel.id}>`
      )
      .setImage(gif)
      .setFooter({
        text: `Theo yêu cầu của ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  },
};