const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "../data/afkVoice.json");

function load() {
    if (!fs.existsSync(file)) fs.writeFileSync(file, "{}");
    return JSON.parse(fs.readFileSync(file, "utf8"));
}

function save(data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function setAFK(guildId, channelId) {
    const data = load();
    data[guildId] = channelId;
    save(data);
}

function removeAFK(guildId) {
    const data = load();
    delete data[guildId];
    save(data);
}

function getAll() {
    return load();
}

module.exports = {
    setAFK,
    removeAFK,
    getAll
};