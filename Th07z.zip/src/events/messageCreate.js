const {
    PermissionFlagsBits,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ButtonBuilder,
    SeparatorSpacingSize,
    ButtonStyle,
    MessageFlags,
    EmbedBuilder,
    ActionRowBuilder // ✅ FIX THIẾU
} = require("discord.js");

const commandCooldowns = new Map();
const blacklistCooldown = new Map();
const premiumCooldown = new Map(); // ✅ FIX vị trí

const activeReports = global.activeReports || (global.activeReports = new Map());
const lockedUsers = global.lockedUsers || (global.lockedUsers = new Map());

let globalLock = false;
let lockTimeout = null;

function applyGlobalLock() {
    globalLock = true;
    clearTimeout(lockTimeout);
    lockTimeout = setTimeout(() => { globalLock = false; }, 1000);
}

const sep = () => new SeparatorBuilder()
    .setDivider(true)
    .setSpacing(SeparatorSpacingSize.Small);

// ⏳ FORMAT TIME
function formatTime(ms) {
    if (ms <= 0) return "Hết hạn";

    const days = Math.floor(ms / (1000 * 60 * 60 * 24));
    const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((ms / (1000 * 60)) % 60);

    return `${days}d ${hours}h ${minutes}m`;
}

module.exports = async (client) => {

    if (client._eventLoaded) return;
    client._eventLoaded = true;

    client.on("rateLimit", () => applyGlobalLock());

    client.on("messageCreate", async (message) => {
        if (!message.guild || message.author.bot) return;
        if (globalLock) return;

        const perms = message.channel.permissionsFor(message.guild.members.me);
        if (!perms || !perms.has([
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.EmbedLinks,
        ])) return;

        // =========================
        // PREFIX
        // =========================
        let prefix = client.config.prefix;
        const prefixData = await client.db.get(`prefix_${message.guild.id}`);
        if (prefixData) prefix = prefixData;

        const mentionedBot =
            message.content === `<@${client.user.id}>` ||
            message.content === `<@!${client.user.id}>`;

        const botregex = new RegExp(`^<@!?${client.user.id}>( |)`);
        const pre = message.content.match(botregex)
            ? message.content.match(botregex)[0]
            : prefix;

        const argsWithPrefix = message.content.startsWith(pre)
            ? message.content.slice(pre.length).trim().split(/ +/)
            : null;

        const argsWithoutPrefix = message.content.trim().split(/ +/);

        const commandWithPrefix = argsWithPrefix ? argsWithPrefix.shift()?.toLowerCase() : null;
        const commandWithoutPrefix = argsWithoutPrefix.shift()?.toLowerCase();

        const cmdWithPrefix = commandWithPrefix
            ? client.commands.get(commandWithPrefix) ||
              client.commands.find(c => c.aliases?.includes(commandWithPrefix))
            : null;

        const cmdWithoutPrefix =
            client.commands.get(commandWithoutPrefix) ||
            client.commands.find(c => c.aliases?.includes(commandWithoutPrefix));

        const npList = await client.db.get("noprefix") || [];
        const isNoprefixUser = npList.some(e => e.userId === message.author.id);

        let cmd, args;
        if (isNoprefixUser) {
            cmd  = cmdWithoutPrefix || cmdWithPrefix;
            args = cmdWithoutPrefix ? argsWithoutPrefix : argsWithPrefix;
        } else {
            cmd  = cmdWithPrefix;
            args = argsWithPrefix;
        }

        if (!args) args = [];

        // =========================
        // 🚨 BLACKLIST
        // =========================
        const bl = await client.db.get(`blacklist_${client.user.id}`) || [];

        if ((mentionedBot || cmd) && bl.includes(message.author.id)) {
            const now = Date.now();
            const last = blacklistCooldown.get(message.author.id) || 0;
            if (now - last < 60000) return;

            blacklistCooldown.set(message.author.id, now);

            const reason = await client.db.get(`blreason_${message.author.id}`) || "Không có lý do";

            return message.channel.send({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF0000)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `<:disabled:1487783250452545616> <@${message.author.id}> **Bạn đã bị blacklist**`
                            )
                        )
                        .addSeparatorComponents(sep())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `\`\`\`yml\nLý do : ${reason}\`\`\``
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // =========================
        // 🤖 MENTION BOT
        // =========================
        if (mentionedBot) {
            return message.channel.send({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0x26272F)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `<:speaker:1492466016289030194> **Xin chào ${message.author}**\n` +
                                `<:search:1492132251608158338> Prefix: \`${prefix}\`\n` +
                                `<:cat_star:1492453457158869113> Gõ \`${prefix}help\``
                            )
                        )
                        .addSeparatorComponents(sep())
                        .addActionRowComponents(row =>
                            row.addComponents(
                                new ButtonBuilder()
                                    .setLabel("Mời Bot")
                                    .setEmoji("1492126467574992936")
                                    .setStyle(ButtonStyle.Link)
                                    .setURL("https://tinyurl.com/Th07z"),

                                new ButtonBuilder()
                                    .setLabel("Hỗ trợ")
                                    .setEmoji("1492125965688635532")
                                    .setStyle(ButtonStyle.Link)
                                    .setURL("https://discord.gg/BW6NbrKdyF")
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // =========================
        // ❌ NO COMMAND
        // =========================
        if (!cmd) return;

        // =========================
        // ⏱ COOLDOWN
        // =========================
        const now = Date.now();
        const key = `${message.author.id}-${cmd.name}`;
        const cd = (cmd.cooldown || 3) * 1000;

        if (commandCooldowns.has(key)) {
            const expire = commandCooldowns.get(key);
            if (now < expire) {
                const remain = Math.ceil((expire - now) / 1000);
                return message.channel.send(
                    `<:clock:1489894867122262036> Đợi ${remain}s để dùng lệnh **${cmd.name}**`
                );
            }
        }

        commandCooldowns.set(key, now + cd);
        setTimeout(() => commandCooldowns.delete(key), cd);

        // =========================
        // 💎 PREMIUM
        // =========================
        if (cmd.premium === true) {
            const guildPremium = await client.db.get(`premium_guild_${message.guild.id}`);
            const timeLeft = guildPremium ? guildPremium.expiresAt - Date.now() : 0;
            const hasPremium = guildPremium && timeLeft > 0;

            if (!hasPremium) {
                const last = premiumCooldown.get(message.author.id);
                if (last && Date.now() - last < 10000) return;
                premiumCooldown.set(message.author.id, Date.now());

                const embed = new EmbedBuilder()
                    .setColor(0xFFD700)
                    .setAuthor({
                        name: "Yêu cầu trả phí",
                        iconURL: message.guild.iconURL({ dynamic: true })
                    })
                    .setThumbnail("https://discord.com/channels/1263492117175603283/1490373725093367968/1493252121506615346")
                    .setDescription(
`<:cat_star:1492453457158869113> Lệnh này thuộc **gói Premium** <:Premium:1492870966664233021>

<:idea:1492084965494751313> Nâng cấp để mở khóa:
• <:search:1492132251608158338> Tất cả lệnh Đặc Quyền Premium
• <:skull:1492126467574992936> Hiệu năng cao hơn
• <:hoanghot:1492128357817651450> Tính năng độc quyền

<:clock:1489894867122262036> Trạng thái: **Chưa kích hoạt**`
                    )
                    .setFooter({
                        text: `${client.user.username} • Premium`,
                        iconURL: client.user.displayAvatarURL()
                    });

                return message.reply({ embeds: [embed] });
            }
        }

        // =========================
        // 🚀 RUN COMMAND
        // =========================
        try {
            if (cmd.execute) await cmd.execute(client, message, args);
            else if (cmd.run) await cmd.run(client, message, args, prefix);
        } catch (err) {
            console.error(err);
            message.channel.send("<:disabled:1487783250452545616> Lỗi khi dùng lệnh...");
        }
    });
};
