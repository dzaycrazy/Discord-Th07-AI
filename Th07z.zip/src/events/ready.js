const { ActivityType } = require("discord.js");
const fs = require("fs");
const uptimeCmd = require("../commands/😽 Info/uptime.js");

const DATA_FILE = "./uptime.json";

module.exports = (client) => {
  client.on("clientReady", async () => {

    console.log(`[Bot] ${client.user.tag}`);

    client.activeUptime = client.activeUptime || new Map();

    const shardId = client.cluster?.info?.SHARD_LIST?.[0] ?? 0;

    // ===== PRESENCE (GIỮ NGUYÊN) =====
    const list = [
      {
        status: "online",
        activity: {
          name: `Th07z - th!help || Shards ${shardId}`,
          type: ActivityType.Playing,
        },
      },
      {
        status: "idle",
        activity: {
          name: `th!antinuke enable - Antinuke`,
          type: ActivityType.Watching,
        },
      },
      {
        status: "dnd",
        activity: {
          name: `Tổng ${client.guilds.cache.size} máy chủ bot đã tham gia`,
          type: ActivityType.Watching,
        },
      },
      {
        status: "idle",
        activity: {
          name: `Liên hệ hỗ trợ @dzaycrazy`,
          type: ActivityType.Playing,
        },
      },
      {
        status: "dnd",
        activity: {
          name: `Gmail -> dzaycrazy@gmail.com`,
          type: ActivityType.Watching,
        },
      },
    ];

    let i = 0;
    setInterval(() => {
      const cur = list[i];

      client.user.setPresence({
        status: cur.status,
        activities: [cur.activity],
      });

      i = (i + 1) % list.length;
    }, 5000);

    // ===== RESUME UPTIME =====
    try {
      if (!fs.existsSync(DATA_FILE)) return;

      const saved = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));

      for (const guildId of Object.keys(saved)) {
        try {
          const { channelId, messageId } = saved[guildId];

          const ch = await client.channels.fetch(channelId).catch(() => null);
          if (!ch) continue;

          const msg = await ch.messages.fetch(messageId).catch(() => null);
          if (!msg) continue;

          if (client.activeUptime.has(guildId)) continue;

          client.activeUptime.set(guildId, { message: msg });

          // 🔥 FIX CHÍNH
          uptimeCmd.startLoop(client, guildId, client.activeUptime.get(guildId));

        } catch {
          delete saved[guildId];
        }
      }

    } catch (e) {
      console.log("Resume lỗi:", e);
    }

    console.log("HOÀN THÀNH ✅");
  });
};
