
const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require("discord.js");

module.exports = (client) => {
    client.on("interactionCreate", async (interaction) => {

        // ================= SLASH =================
        if (interaction.isChatInputCommand()) {
            const cmd = client.commands.get(interaction.commandName);
            if (!cmd || !cmd.runSlash) return;

            try {
                await cmd.runSlash(client, interaction);
            } catch (err) {
                console.error(`[Lỗi Lệnh Slash] ${interaction.commandName}:`, err);

                const errorEmbed = new EmbedBuilder()
                    .setColor('#FF4B4B')
                    .setDescription("Đã xảy ra lỗi khi thực thi lệnh này.");
                
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ embeds: [errorEmbed], ephemeral: true }).catch(() => {});
                } else {
                    await interaction.reply({ embeds: [errorEmbed], ephemeral: true }).catch(() => {});
                }
            }
            return;
        }

        // ================= REPORT BUTTON =================
        if (interaction.isButton() && interaction.customId.startsWith("report_reply_")) {

            const [, , userId, reportId] = interaction.customId.split("_");

            const modal = new ModalBuilder()
                .setCustomId(`report_modal_${userId}_${reportId}`)
                .setTitle(`Reply Report #${reportId}`);

            const input = new TextInputBuilder()
                .setCustomId("reply_content")
                .setLabel("Nội dung trả lời")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true);

            modal.addComponents(
                new ActionRowBuilder().addComponents(input)
            );

            return interaction.showModal(modal);
        }

        // ================= REPORT MODAL =================
        if (interaction.isModalSubmit() && interaction.customId.startsWith("report_modal_")) {

            const [, , userId, reportId] = interaction.customId.split("_");
            const content = interaction.fields.getTextInputValue("reply_content");

            const emoji = interaction.client.emoji || { cross: "<:disabled:1487783250452545616>", tick: "<:enable:1487783260565143614>" };

            try {
                const user = await interaction.client.users.fetch(userId).catch(() => null);

                if (!user) {
                    return interaction.reply({
                        content: `${emoji.cross} Không tìm thấy user`,
                        ephemeral: true
                    });
                }

                // 📩 gửi DM user
                await user.send({
                    embeds: [
                        new EmbedBuilder()
                            .setColor("#26272F")
                            .setTitle(`<:search:1492132251608158338> Phản hồi báo cáo #${reportId}`)
                            .setDescription(content)
                            .setFooter({ text: `Dev: ${interaction.user.tag}` })
                            .setTimestamp()
                    ]
                });

                // 📌 log lại trong channel
                await interaction.message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor("#26272F")
                            .setDescription(
                                `<:search:1492132251608158338> **Đã trả lời report #${reportId}**\n` +
                                `<:andanh:1491797990015238254> <@${userId}>\n\n` +
                                `<:content:1492082065699508414> ${content}`
                            )
                    ]
                });

                return interaction.reply({
                    content: `${emoji.tick} Đã gửi phản hồi`,
                    ephemeral: true
                });

            } catch (err) {
                console.error(err);
                return interaction.reply({
                    content: `${emoji.cross} User tắt DM hoặc lỗi`,
                    ephemeral: true
                });
            }
        }

        // ================= BUTTON ONLY =================
        if (!interaction.isButton()) return;

        // ================= GIVEAWAY =================
        if (interaction.customId === "giveaway_enter") {
            const giveaway = await client.db.get(`giveaway_${interaction.message.id}`);
            const arrow = client.emoji?.arrow || "▸";
            
            if (!giveaway) {
                return interaction.reply({ 
                    content: "<:disabled:1487783250452545616> Giveaway này không còn tồn tại!", 
                    flags: 64 
                });
            }

            if (!giveaway.status || giveaway.ended) {
                return interaction.reply({ 
                    content: "<:disabled:1487783250452545616> Giveaway đó đã kết thúc rồi!", 
                    flags: 64 
                });
            }

            // REMOVE
            if (giveaway.entries.includes(interaction.user.id)) {
                giveaway.entries = giveaway.entries.filter(id => id !== interaction.user.id);
                await client.db.set(`giveaway_${interaction.message.id}`, giveaway);

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("giveaway_enter")
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji("<:discordnole:1438114578830725201>")
                        .setLabel("Tham gia"),
                    new ButtonBuilder()
                        .setCustomId("giveaway_entries_display")
                        .setStyle(ButtonStyle.Secondary)
                        .setLabel(`Lượt tham gia: ${giveaway.entries.length}`)
                        .setDisabled(true)
                );

                await interaction.message.edit({ components: [row] }).catch(() => {});

                return interaction.reply({ 
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#26272F')
                            .setDescription(`${arrow} Bạn đã rời khỏi giveaway cho **${giveaway.prize}**`)
                    ],
                    flags: 64 
                });
            }

            // ADD
            giveaway.entries.push(interaction.user.id);
            await client.db.set(`giveaway_${interaction.message.id}`, giveaway);

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId("giveaway_enter")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<:discordnole:1438114578830725201>")
                    .setLabel("Tham gia"),
                new ButtonBuilder()
                    .setCustomId("giveaway_entries_display")
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel(`Lượt tham gia: ${giveaway.entries.length}`)
                    .setDisabled(true)
            );

            await interaction.message.edit({ components: [row] }).catch(() => {});

            const endTimestamp = Math.floor(giveaway.endTime / 1000);
            
            return interaction.reply({ 
                embeds: [
                    new EmbedBuilder()
                        .setColor('#26272F')
                        .setDescription(
                            `<:enable:1487783260565143614> **Bạn đã tham gia giveaway!**\n\n` +
                            `${arrow} **Giải thưởng:** ${giveaway.prize}\n` +
                            `${arrow} **Kết thúc:** <t:${endTimestamp}:R>`
                        )
                ],
                flags: 64 
            });
        }

        // ================= IGNORE =================
        if (
            interaction.customId === "giveaway_entries_display" || 
            interaction.customId === "giveaway_entries_ended" ||
            interaction.customId === "giveaway_ended"
        ) return;

        // ================= DELETE BUTTON =================
        if (interaction.customId === "cmd_delete") {
            if (interaction.message.interaction?.user?.id !== interaction.user.id) {
                return interaction.reply({ 
                    content: "Bạn không thể xóa tin nhắn này!", 
                    flags: 64 
                });
            }
            await interaction.message.delete().catch(() => {});
        }
    });
};